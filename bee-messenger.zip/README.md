# BEE Messenger v5

Private chat for people you know. Text goes end-to-end encrypted through Gmail. **Instant mode** is a direct phone-to-phone
connection (also encrypted) for photos, videos, files and voice notes. Files never go through Gmail.

## What changed in v5
- **Time:** every message shows the receiving phone's own clock and timezone.
- **People / Chat / Me** pages. Names, bio and status instead of email addresses.
- **Add person** sends a request; the other person must accept. Strangers cannot message you.
- **Talk now (⚡):** asks the other person to join Instant mode. They get a notification. If they are not online,
  you see "[Name] is not online right now" with a button to message by Gmail.
- **Shield:** plain-language "Is this really them?" check with a safety number.
- **Reply** to a message (quote); **formatting** `*bold* _italic_ ~strike~ \`code\``.
- **Outbox:** texts are saved on the phone first and sent when Gmail/internet is back.
- **App lock (optional):** a PIN that also encrypts chats stored on the phone.
- **Android background listener:** checks Gmail about every minute while the app is closed and notifies you
  (it sees only sender + type of mail, never the message). Tap "Keep BEE listening when closed" once.

## v6
- **Connect nearby (QR icon on People):** no internet needed. Same Wi-Fi or one phone's hotspot. Phone A: *Show my code*;
  phone B: *Scan their code*, then shows a reply code; phone A: *Next: scan their reply code*. You become verified contacts
  and connect in Instant mode. Android app only.
- **Profile photo:** tap your picture on *Me*. It is shared only in Instant mode, never through Gmail.
- WhatsApp-style lists, search, swipe-right-to-reply, full-screen photos, clean contact profile page.
- The launcher icon is now generated from `icon.png` (put it in the repo root next to the zip).

## Build (GitHub Actions)
1. Put `bee-messenger.zip`, `icon.png` (optional) in the repo root and `build-apk.yml` in `.github/workflows/`.
2. Secrets: `ANDROID_CLIENT_ID`, `KEYSTORE_PASSWORD`, `KEYSTORE_BASE64` (as before).
3. Optional secret `TURN_JSON`, for example:
   `[{"urls":"turn:global.relay.metered.ca:80","username":"YOUR_USER","credential":"YOUR_PASS"},{"urls":"turn:global.relay.metered.ca:443?transport=tcp","username":"YOUR_USER","credential":"YOUR_PASS"}]`
   (get the username/credential from your free Metered account).

## Google: stop the 7-day sign-out
Google Cloud Console -> your project -> Google Auth Platform -> Audience -> **Publish app** -> Confirm.
Free. The app stays "unverified": people see a warning once (Advanced -> Go to BEE) and you are limited to 100 users.
Everyone must sign in once more after you publish.

## Tip: keep your inbox clean
In Gmail create a filter: Subject has `"BEE Messenger"` -> Skip the Inbox, Mark as read. Do NOT delete them.
