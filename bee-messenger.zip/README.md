# BEE Messenger v2

Serverless 1:1 chat. Gmail API = relay + signaling, WebRTC = direct P2P, E2E encryption in the browser.

## One-time Google setup
1. console.cloud.google.com -> new project -> enable **Gmail API**.
2. OAuth consent screen: External, add yourself AND your contact as **Test users**.
3. Credentials -> Create **OAuth client ID** -> Web application.
   Authorized JavaScript origin: your Pages origin, e.g. `https://USER.github.io` (no path, no trailing slash).
4. Open the site, paste the Client ID, sign in (tick ALL permission boxes).
5. Type your contact's Gmail, tap **Connect**. They must open the site too.
6. Compare the safety number (🔓 button) over a call, then tap "Numbers match".
