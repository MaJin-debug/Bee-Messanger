'use strict';
// ============================================================
// BEE Messenger v5 — private chat for people you know.
// Text: end-to-end encrypted over Gmail. Instant mode: direct P2P (WebRTC), also end-to-end encrypted.
// Files, photos, videos and voice notes NEVER touch Gmail: Instant mode only.
// ============================================================

const SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/userinfo.email'
];
const GM = 'https://gmail.googleapis.com/gmail/v1/users/me';
const TAG_SIG = '[BEE:v2:sig]';
const TAG_ENC = '[BEE:v2:enc]';
// Subject tells the Android background service WHAT arrived without reading anything private
const SUBJ = { msg: 'BEE Messenger', talk: 'BEE Messenger Talk', req: 'BEE Messenger Req', sys: 'BEE Messenger Sys' };
const MAX_P2P_MB = 25;
const POLL_VISIBLE = 15000;
const POLL_HIDDEN = 60000;
const SIGNAL_TTL = 10 * 60 * 1000;   // ignore old Instant requests
const TALK_WAIT = 60000;             // how long we wait for "Talk now" before offering Gmail
const CHUNK = 16 * 1024;
const EMAIL_RE = /^[^\s@<>,;"']+@[^\s@<>,;"']+\.[^\s@<>,;"']+$/;
const SAFE_MEDIA = /^(image\/(png|jpe?g|gif|webp|avif|bmp)|video\/(mp4|webm|quicktime|ogg)|audio\/(webm|ogg|mp4|mpeg|wav|aac|x-m4a))$/i;
const ECDH = { name: 'ECDH', namedCurve: 'P-256' };
const NATIVE = !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
const CAP = () => (window.Capacitor && window.Capacitor.Plugins) || {};
const STATUSES = ['Available', 'Busy', 'In a meeting', 'At work', 'Away'];

const $ = (id) => document.getElementById(id);
const utf8 = new TextEncoder();
const dec = new TextDecoder();

// ---------------- STATE ----------------
const state = {
  token: null, tokenExp: 0, expired: false, pending: null,
  myEmail: null, keyPair: null, myPubB64: null,
  profile: { name: '', bio: '', status: 'Available' },
  contacts: {},            // email -> { pub, verified, name, bio, status, nick, incoming, seen }
  contact: null,           // chat currently open
  keyCache: {},
  peer: null, peerEmail: null, peerConnected: false, rx: null, hb: 0, lastPong: 0,
  calling: null, callTimer: 0, incoming: null,
  processed: new Set(),
  pollTimer: null, polling: false, pulling: false,
  recording: null, recStarting: false, lastDay: null, menuBubble: null, menuAt: 0,
  unread: {}, urls: [], renderSeq: 0, sendChain: Promise.resolve(),
  dbKey: null, lock: null, replyTo: null, view: 'people', outboxBusy: false, nativeSvc: false, lastTs: 0,
  lastMsg: {}              // email -> {text, ts, side}
};
let tokenClient = null;

// ---------------- UI HELPERS ----------------
function toast(msg, type = 'info', ms = 4000) {
  const d = document.createElement('div');
  d.className = 'toast ' + type;
  d.textContent = msg;
  $('toasts').appendChild(d);
  setTimeout(() => d.remove(), ms);
  if (type === 'error') console.error(msg);
}
function showBanner(text, btnText, fn) {
  $('banner-text').textContent = text;
  const b = $('banner-btn');
  b.textContent = btnText;
  b.onclick = fn;
  $('banner').classList.remove('hidden');
}
function hideBanner() { $('banner').classList.add('hidden'); }
function fmtSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}
function cleanName(n) { return String(n || 'file').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 100) || 'file'; }
function safeMime(m) { return SAFE_MEDIA.test(m || '') ? m : 'application/octet-stream'; }
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join(''));
const convKey = (contact) => `${state.myEmail}|${contact}`;
const K = (n) => `${state.myEmail}:${n}`;
const nameOf = (e) => { const c = state.contacts[e]; return (c && (c.name || c.nick)) || (e ? e.split('@')[0] : 'Unknown'); };
const isOnline = (e) => state.peerConnected && state.peerEmail === e;
const clip = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
// receiver's own clock, always increasing, so order on THIS phone is stable
function nowTs() { state.lastTs = Math.max(Date.now(), state.lastTs + 1); return state.lastTs; }
function hue(s) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }
function avatarEl(name, big) {
  const d = document.createElement('div');
  d.className = 'av' + (big ? ' big' : '');
  d.textContent = (name || '?').trim().charAt(0).toUpperCase() || '?';
  d.style.background = `hsl(${hue(name || '?')} 55% 42%)`;
  return d;
}
// ---------------- BASE64 ----------------
function toB64(buf) {
  const b = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(s);
}
function fromB64(s) {
  const bin = atob(s);
  const b = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
  return b;
}
const b64url = (bytes) => toB64(bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return fromB64(s);
}
const wrap76 = (s) => (s.match(/.{1,76}/g) || ['']).join('\r\n');


// ---------------- LOCAL DB (IndexedDB) + optional PIN encryption at rest ----------------
async function sealMsg(m) {
  if (!state.dbKey) return m;
  const body = { ...m }; delete body.blob;
  const json = utf8.encode(JSON.stringify(body));
  const bl = m.blob ? new Uint8Array(await m.blob.arrayBuffer()) : new Uint8Array(0);
  const pt = new Uint8Array(4 + json.length + bl.length);
  new DataView(pt.buffer).setUint32(0, json.length);
  pt.set(json, 4); pt.set(bl, 4 + json.length);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, state.dbKey, pt));
  const d = new Uint8Array(12 + ct.length); d.set(iv, 0); d.set(ct, 12);
  return { id: m.id, conv: m.conv, ts: m.ts, status: m.status, side: m.side, sealed: true, d };
}
async function openMsg(r) {
  if (!r || !r.sealed) return r;
  if (!state.dbKey) return null;
  const pt = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: r.d.slice(0, 12) }, state.dbKey, r.d.slice(12)));
  const hl = new DataView(pt.buffer).getUint32(0);
  const body = JSON.parse(dec.decode(pt.subarray(4, 4 + hl)));
  if (body.kind === 'file') body.blob = new Blob([pt.slice(4 + hl)], { type: body.mime });
  return body;
}
const DB = {
  db: null,
  open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('bee', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('kv');
        const m = d.createObjectStore('messages', { keyPath: 'id' });
        m.createIndex('conv', 'conv');
      };
      r.onsuccess = () => { this.db = r.result; res(); };
      r.onerror = () => rej(r.error);
    });
  },
  tx(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = this.db.transaction(store, mode);
      const rq = fn(t.objectStore(store));
      t.oncomplete = () => res(rq && rq.result);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  },
  get(k) { return this.tx('kv', 'readonly', s => s.get(k)); },
  set(k, v) { return this.tx('kv', 'readwrite', s => s.put(v, k)); },
  del(k) { return this.tx('kv', 'readwrite', s => s.delete(k)); },
  async putMsg(m) { const rec = await sealMsg(m); return this.tx('messages', 'readwrite', s => s.put(rec)); },
  async getMsg(id) { return openMsg(await this.tx('messages', 'readonly', s => s.get(id))); },
  delMsg(id) { return this.tx('messages', 'readwrite', s => s.delete(id)); },
  async msgsFor(conv) {
    const rows = await this.tx('messages', 'readonly', s => s.index('conv').getAll(conv));
    return (await Promise.all(rows.map(openMsg))).filter(Boolean);
  },
  allRaw() { return this.tx('messages', 'readonly', s => s.getAll()); },
  clearConv(conv) {
    return this.tx('messages', 'readwrite', s => {
      const r = s.index('conv').openKeyCursor(IDBKeyRange.only(conv));
      r.onsuccess = () => { const c = r.result; if (c) { s.delete(c.primaryKey); c.continue(); } };
      return r;
    });
  }
};

// ---- PIN lock ----
async function pinKey(pin, salt) {
  const base = await crypto.subtle.importKey('raw', utf8.encode(pin), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 250000 },
    base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function rewriteAllMessages(fromKey, toKey) {
  const rows = await DB.allRaw();
  for (const r of rows) {
    state.dbKey = fromKey;
    const m = await openMsg(r);
    state.dbKey = toKey;
    if (m) await DB.putMsg(m);
  }
  state.dbKey = toKey;
}
async function enablePin(pin) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await pinKey(pin, salt);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, utf8.encode('bee-ok')));
  await rewriteAllMessages(null, key);
  await DB.set('lock', { salt, iv, ct });
  state.lock = true;
}
async function tryUnlock(pin) {
  const l = await DB.get('lock');
  if (!l) return true;
  try {
    const key = await pinKey(pin, l.salt);
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: l.iv }, key, l.ct);
    if (dec.decode(pt) !== 'bee-ok') return false;
    state.dbKey = key;
    return true;
  } catch { return false; }
}
async function disablePin() {
  await rewriteAllMessages(state.dbKey, null);
  await DB.del('lock');
  state.lock = false;
}

// ---------------- CRYPTO ----------------
async function createKeys() {
  // private key is NON-extractable: JS (or an XSS) can use it but never read it
  const kp = await crypto.subtle.generateKey(ECDH, false, ['deriveBits']);
  await DB.set(K('keypair'), kp);
  return kp;
}
async function deriveKeyFor(peerPubB64) {
  const peerPub = await crypto.subtle.importKey('raw', fromB64(peerPubB64), ECDH, true, []);
  const bits = await crypto.subtle.deriveBits({ name: 'ECDH', public: peerPub }, state.keyPair.privateKey, 256);
  const hk = await crypto.subtle.importKey('raw', bits, 'HKDF', false, ['deriveKey']);
  const [a, b] = [state.myPubB64, peerPubB64].sort();
  const salt = await crypto.subtle.digest('SHA-256', utf8.encode(a + '|' + b));
  return crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info: utf8.encode('BEE-Messenger-v2') },
    hk, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']
  );
}
async function getKey(email) {
  const c = state.contacts[email];
  if (!c) return null;
  const hit = state.keyCache[email];
  if (hit && hit.pub === c.pub) return hit.key;
  const key = await deriveKeyFor(c.pub);
  state.keyCache[email] = { pub: c.pub, key };
  return key;
}
async function safetyNumber(peerPubB64) {
  const [a, b] = [state.myPubB64, peerPubB64].sort();
  const h = new Uint8Array(await crypto.subtle.digest('SHA-256', utf8.encode(a + '|' + b)));
  const digits = Array.from(h.slice(0, 15)).map(x => String(x).padStart(3, '0')).join('');
  return digits.match(/.{1,5}/g).join(' ');
}
// AAD binds ciphertext to sender -> recipient so it can't be re-targeted
const aad = (from, to) => utf8.encode(`${from.toLowerCase()}>${to.toLowerCase()}`);

// Instant-mode frames are encrypted again with the contact key (so a tampered handshake can't read them)
async function aesEnc(key, pt, aadStr) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: utf8.encode(aadStr) }, key, pt));
  const out = new Uint8Array(12 + ct.length); out.set(iv, 0); out.set(ct, 12);
  return out;
}
async function aesDec(key, bytes, aadStr) {
  return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: bytes.slice(0, 12), additionalData: utf8.encode(aadStr) }, key, bytes.slice(12)));
}
// ---------------- GMAIL ----------------
function authError() { const e = new Error('Session expired'); e.code = 'AUTH'; return e; }
function expire() {
  state.expired = true;
  showBanner('Session expired — sign in again to keep receiving messages.', 'Sign in', startLogin);
  return authError();
}
let refreshing = null;
function refreshToken() {
  if (refreshing) return refreshing;
  if (NATIVE) {
    refreshing = nativeRefresh().finally(() => { refreshing = null; });
    return refreshing;
  }
  refreshing = new Promise((resolve, reject) => {
    if (!tokenClient) return reject(new Error('no auth'));
    state.pending = { resolve, reject };
    const t = setTimeout(() => reject(new Error('timeout')), 20000);
    const done = () => clearTimeout(t);
    state.pending.resolve = (v) => { done(); resolve(v); };
    state.pending.reject = (e) => { done(); reject(e); };
    try { tokenClient.requestAccessToken({ prompt: '', login_hint: state.myEmail || undefined }); }
    catch (e) { done(); reject(e); }
  }).finally(() => { refreshing = null; state.pending = null; });
  return refreshing;
}
async function gfetch(url, opts = {}, retry = true) {
  if (state.expired) throw authError();
  if (Date.now() > state.tokenExp - 60000) {
    try { await refreshToken(); } catch (e) { if (e instanceof TypeError) throw e; throw expire(); }
  }
  const res = await fetch(url, { ...opts, headers: { ...(opts.headers || {}), Authorization: `Bearer ${state.token}` } });
  if (res.status === 401 && retry) {
    try { await refreshToken(); } catch (e) { if (e instanceof TypeError) throw e; throw expire(); }
    return gfetch(url, opts, false);
  }
  if (!res.ok) {
    const e = new Error(`Gmail ${res.status}: ${(await res.text()).slice(0, 160)}`);
    e.status = res.status;
    throw e;
  }
  return res;
}
function buildRaw(to, tag, bytes, subject) {
  if (!EMAIL_RE.test(to)) throw new Error('Bad recipient');
  const body = tag + '\r\n' + wrap76(toB64(bytes));
  const msg = [
    `To: ${to}`, `Subject: ${subject || SUBJ.sys}`,
    'Content-Type: text/plain; charset="UTF-8"', 'Content-Transfer-Encoding: 7bit',
    'MIME-Version: 1.0', '', body
  ].join('\r\n');
  return b64url(utf8.encode(msg));
}
async function gmailSendRaw(raw) {
  await gfetch(`${GM}/messages/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ raw })
  });
}
const SIG_SUBJECT = { offer: SUBJ.talk, hello: SUBJ.req, answer: SUBJ.sys, decline: SUBJ.sys };
function relaySignal(to, obj) {
  const subj = obj.type === 'hello' && obj.ack ? SUBJ.sys : (SIG_SUBJECT[obj.type] || SUBJ.sys);
  return gmailSendRaw(buildRaw(to, TAG_SIG, utf8.encode(JSON.stringify(obj)), subj));
}
// Gmail relay carries TEXT ONLY (and tiny system messages). Files never go through Gmail.
async function relaySend(to, m, subject) {
  const key = await getKey(to);
  if (!key) throw new Error('No keys yet for this person.');
  const header = utf8.encode(JSON.stringify({
    mid: m.mid, ts: m.ts, type: m.type || 'text', text: m.text, reply: m.reply, profile: m.profile
  }));
  const pt = new Uint8Array(4 + header.length);
  new DataView(pt.buffer).setUint32(0, header.length);
  pt.set(header, 4);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: aad(state.myEmail, to) }, key, pt));
  const out = new Uint8Array(12 + ct.length);
  out.set(iv, 0); out.set(ct, 12);
  await gmailSendRaw(buildRaw(to, TAG_ENC, out, subject || SUBJ.msg));
}

async function extractBody(id, p) {
  if (p.parts) {
    for (const c of p.parts) { const b = await extractBody(id, c); if (b) return b; }
    return null;
  }
  if (p.body && p.body.data) return dec.decode(b64urlToBytes(p.body.data));
  if (p.body && p.body.attachmentId) {   // big bodies come as attachments
    const a = await (await gfetch(`${GM}/messages/${id}/attachments/${p.body.attachmentId}`)).json();
    return dec.decode(b64urlToBytes(a.data));
  }
  return null;
}
function parseBee(body) {
  if (!body) return null;
  const m = body.match(/\[BEE:v2:(sig|enc)\]\s*([A-Za-z0-9+/=\s]+)/);
  if (!m) return null;
  try {
    const bytes = fromB64(m[2].replace(/\s+/g, ''));
    return m[1] === 'sig'
      ? { kind: 'sig', json: JSON.parse(dec.decode(bytes)) }
      : { kind: 'enc', bytes };
  } catch { return null; }
}
const hdr = (gm, name) => (gm.payload.headers || []).find(h => h.name.toLowerCase() === name.toLowerCase())?.value || '';
function extractEmail(v) {
  const m = v.match(/<(.+?)>/);
  return (m ? m[1] : v).trim().toLowerCase();
}


// ---------------- INSTANT MODE (WebRTC) ----------------
function iceServers() {
  const list = [{ urls: 'stun:stun.l.google.com:19302' }];
  const add = (raw) => { try { const x = typeof raw === 'string' ? JSON.parse(raw || '[]') : raw; if (Array.isArray(x)) list.push(...x.filter(s => s && s.urls)); } catch { /* ignore */ } };
  if (window.BEE_NATIVE && window.BEE_NATIVE.turn) add(window.BEE_NATIVE.turn);
  add(localStorage.getItem('bee_turn'));
  return list;
}
class Peer {
  constructor(cb) {
    this.cb = cb; this.dead = false; this.ch = null;
    this.pc = new RTCPeerConnection({ iceServers: iceServers() });
    this.pc.ondatachannel = (e) => this._setup(e.channel);
    this.pc.onconnectionstatechange = () => {
      if (this.dead) return;
      const s = this.pc.connectionState;
      if (s === 'connected') cb.up();
      if (['disconnected', 'failed', 'closed'].includes(s)) cb.down(s);
    };
  }
  _setup(ch) {
    this.ch = ch;
    ch.binaryType = 'arraybuffer';
    ch.bufferedAmountLowThreshold = 256 * 1024;
    ch.onmessage = (e) => { if (!this.dead) this.cb.msg(e.data); };
    ch.onopen = () => { if (!this.dead) this.cb.up(); };
    ch.onclose = () => { if (!this.dead) this.cb.down('closed'); };
  }
  _ice() {
    const pc = this.pc;
    if (pc.iceGatheringState === 'complete') return Promise.resolve();
    return new Promise(res => {
      const done = () => { pc.removeEventListener('icegatheringstatechange', chk); clearTimeout(t); res(); };
      const chk = () => { if (pc.iceGatheringState === 'complete') done(); };
      const t = setTimeout(done, 5000);
      pc.addEventListener('icegatheringstatechange', chk);
    });
  }
  async createOffer() {
    this._setup(this.pc.createDataChannel('chat'));
    await this.pc.setLocalDescription(await this.pc.createOffer());
    await this._ice();
    return this.pc.localDescription;
  }
  async acceptOffer(offer) {
    await this.pc.setRemoteDescription(offer);
    await this.pc.setLocalDescription(await this.pc.createAnswer());
    await this._ice();
    return this.pc.localDescription;
  }
  acceptAnswer(a) { return this.pc.setRemoteDescription(a); }
  get open() { return this.ch && this.ch.readyState === 'open'; }
  async _wait() {
    while (this.ch.bufferedAmount > 1024 * 1024) {
      await new Promise(r => {
        this.ch.onbufferedamountlow = () => { this.ch.onbufferedamountlow = null; r(); };
        setTimeout(r, 500);
      });
      if (!this.open) throw new Error('P2P closed');
    }
  }
  async send(data) { await this._wait(); this.ch.send(data); }
  close() { this.dead = true; try { if (this.ch) this.ch.close(); this.pc.close(); } catch { /* ignore */ } }
}
let rxChain = Promise.resolve();
function newPeer() {
  const p = new Peer({
    up: () => { if (state.peer === p) onPeerUp(); },
    down: () => { if (state.peer === p) onPeerDown(); },
    msg: (d) => { if (state.peer === p) onPeerData(d); }
  });
  return p;
}
function closePeer() {
  clearInterval(state.hb);
  if (state.peer) { state.peer.close(); state.peer = null; }
  state.peerConnected = false;
  state.peerEmail = null;
  state.rx = null;
  refreshPresenceUI();
}
function clearCall() { state.calling = null; clearTimeout(state.callTimer); }
function onPeerUp() {
  if (state.peerConnected) return;
  state.peerConnected = true;
  clearCall();
  closeDlg($('offline-dialog'));
  state.lastPong = Date.now();
  clearInterval(state.hb);
  state.hb = setInterval(() => {
    if (Date.now() - state.lastPong > 35000) return onPeerDown();
    p2pCtl({ t: 'ping' }).catch(() => {});
  }, 10000);
  refreshPresenceUI();
  toast(`Instant mode with ${nameOf(state.peerEmail)} is on`);
  sendProfile(state.peerEmail);
  flushOutbox();
}
function onPeerDown() {
  if (!state.peer) return;
  const who = state.peerEmail, was = state.peerConnected;
  closePeer();
  clearCall();
  if (was) toast(`${nameOf(who)} left Instant mode`);
}

// Every Instant frame = [1 byte type][payload], AES-GCM encrypted with the shared contact key.
// type 0 = JSON control message, type 1 = file chunk
async function p2pFrame(type, payload) {
  const p = state.peer;
  if (!p || !p.open) throw new Error('Instant mode is not active');
  const key = await getKey(state.peerEmail);
  const pt = new Uint8Array(1 + payload.length);
  pt[0] = type; pt.set(payload, 1);
  await p.send(await aesEnc(key, pt, `p2p|${state.myEmail}>${state.peerEmail}`));
}
const p2pCtl = (o) => p2pFrame(0, utf8.encode(JSON.stringify(o)));
async function p2pSend(m, blob) {
  if (m.kind === 'text') {
    await p2pCtl({ t: 'text', mid: m.mid, ts: m.ts, text: m.text, reply: m.reply });
  } else {
    await p2pCtl({ t: 'file', mid: m.mid, ts: m.ts, mime: m.mime, name: m.name, size: blob.size, dur: m.dur });
    for (let o = 0; o < blob.size; o += CHUNK) await p2pFrame(1, new Uint8Array(await blob.slice(o, o + CHUNK).arrayBuffer()));
  }
}
function onPeerData(d) {
  const from = state.peerEmail;
  rxChain = rxChain.then(() => handleFrame(from, d)).catch(e => console.warn('frame', e));
}
async function handleFrame(from, d) {
  if (!from || !(d instanceof ArrayBuffer)) return;
  let pt;
  try { pt = await aesDec(await getKey(from), new Uint8Array(d), `p2p|${from}>${state.myEmail}`); }
  catch { return; }
  if (pt[0] === 0) {
    const o = JSON.parse(dec.decode(pt.subarray(1)));
    if (o.t === 'ping') { p2pCtl({ t: 'pong' }).catch(() => {}); state.lastPong = Date.now(); }
    else if (o.t === 'pong') state.lastPong = Date.now();
    else if (o.t === 'profile') applyProfile(from, o.profile);
    else if (o.t === 'text') await ingest(from, { mid: o.mid, ts: o.ts, type: 'text', text: o.text, reply: o.reply }, null, 'p2p');
    else if (o.t === 'file') {
      const size = Number(o.size);
      if (!(size >= 0) || size > MAX_P2P_MB * 1048576) { state.rx = null; return toast('Incoming file rejected (too large)', 'error'); }
      state.rx = { meta: o, parts: [], got: 0, size, from };
      if (size === 0) await finishRx();
    }
  } else if (pt[0] === 1 && state.rx) {
    const c = pt.slice(1);
    state.rx.parts.push(c);
    state.rx.got += c.byteLength;
    if (state.rx.got >= state.rx.size) await finishRx();
  }
}
async function finishRx() {
  const { meta, parts, from } = state.rx;
  state.rx = null;
  await ingest(from, { mid: meta.mid, ts: meta.ts, type: 'file', mime: meta.mime, name: meta.name, dur: meta.dur }, new Blob(parts), 'p2p');
}

// ---------------- TALK NOW (Instant request through Gmail) ----------------
async function talkNow(email) {
  const c = state.contacts[email];
  if (!c || !c.pub || c.incoming) return toast(`Waiting for ${nameOf(email)} to accept you first.`, 'error');
  ensureNotifPermission();
  if (isOnline(email)) return openChat(email);
  if (state.peerConnected && !confirm(`You are in Instant mode with ${nameOf(state.peerEmail)}. Switch to ${nameOf(email)}?`)) return;
  closePeer(); clearCall();
  const peer = newPeer();
  state.peer = peer; state.peerEmail = email; state.calling = email;
  refreshPresenceUI();
  try {
    const offer = await peer.createOffer();
    if (state.peer !== peer) return;
    await relaySignal(email, { type: 'offer', sdp: offer.sdp, pubkey: state.myPubB64 });
    toast(`Asking ${nameOf(email)} to join Instant mode…`);
    state.callTimer = setTimeout(() => {
      if (state.peer === peer && !state.peerConnected) { closePeer(); clearCall(); showOffline(email); }
    }, TALK_WAIT);
  } catch (e) {
    if (state.peer === peer) closePeer();
    clearCall();
    if (e.code !== 'AUTH') toast(e instanceof TypeError ? 'No internet. Check your connection.' : 'Could not reach Gmail: ' + e.message, 'error');
  }
}
function showOffline(email) {
  state.offlineFor = email;
  $('offline-title').textContent = `${nameOf(email)} is not online right now`;
  openDlg($('offline-dialog'));
}
async function joinTalk(sender, sig) {
  closePeer(); clearCall();
  const peer = newPeer();
  state.peer = peer; state.peerEmail = sender;
  refreshPresenceUI();
  try {
    const answer = await peer.acceptOffer({ type: 'offer', sdp: sig.sdp });
    await relaySignal(sender, { type: 'answer', sdp: answer.sdp, pubkey: state.myPubB64 });
    openChat(sender);
    setTimeout(() => { if (state.peer === peer && !state.peerConnected) { closePeer(); toast('Could not connect. Ask them to try again.', 'error'); } }, 45000);
  } catch (e) { if (state.peer === peer) closePeer(); if (e.code !== 'AUTH') toast('Join failed: ' + e.message, 'error'); }
}
async function handleOffer(sender, sig) {
  if (state.peerConnected && state.peerEmail !== sender) {
    await relaySignal(sender, { type: 'decline', reason: 'busy' });
    return true;
  }
  if (state.calling === sender) {            // both asked at once: smaller email keeps its own offer
    if (state.myEmail < sender) return true;
    closePeer(); clearCall();
  }
  if (!document.hidden && state.view === 'chat' && state.contact === sender) { await joinTalk(sender, sig); return true; }
  state.incoming = { sender, sig };
  $('talk-title').textContent = `${nameOf(sender)} wants to talk now`;
  openDlg($('talk-dialog'));
  showNotif(nameOf(sender), 'wants to talk now (Instant mode)', 'talk');
  return true;
}
async function handleSignal(sender, sig, age) {
  if (!sig || typeof sig.type !== 'string') return true;
  if (sig.type === 'hello') return handleHello(sender, sig);
  const c = state.contacts[sender];
  if (!c || !c.pub || c.incoming) return true;           // only people you approved can reach you
  if (age > SIGNAL_TTL) return true;
  if (sig.type === 'decline') {
    if (state.calling === sender) {
      closePeer(); clearCall();
      toast(sig.reason === 'busy' ? `${nameOf(sender)} is in another Instant chat.` : `${nameOf(sender)} can't talk right now.`);
      showOffline(sender);
    }
    return true;
  }
  if (typeof sig.sdp !== 'string' || typeof sig.pubkey !== 'string') return true;
  if (sig.type === 'offer') {
    if (!(await acceptKey(sender, sig.pubkey))) return true;
    return handleOffer(sender, sig);
  }
  if (sig.type === 'answer') {
    if (sender !== state.calling || !state.peer || state.peer.pc.signalingState !== 'have-local-offer') return true;
    if (!(await acceptKey(sender, sig.pubkey))) return true;
    await state.peer.acceptAnswer({ type: 'answer', sdp: sig.sdp });
  }
  return true;
}

// ---------------- CONTACTS & PROFILE ----------------
let syncTimer = 0;
async function saveContacts() { await DB.set(K('contacts'), state.contacts); clearTimeout(syncTimer); syncTimer = setTimeout(nativeSync, 1500); }
async function saveProfile() { await DB.set(K('profile'), state.profile); }
const cleanStr = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n);
async function acceptKey(email, pub) {
  try { await crypto.subtle.importKey('raw', fromB64(pub), ECDH, true, []); }
  catch { toast('Invalid key received from ' + nameOf(email), 'error'); return false; }
  const c = state.contacts[email];
  if (c && c.pub && c.pub !== pub) {
    if (!confirm(`Warning: the security key of ${nameOf(email)} has CHANGED.\n\nThis happens if they reinstalled the app — or if someone is intercepting. Check the shield (safety number) with them before trusting.\n\nAccept the new key?`)) return false;
    c.pub = pub; c.verified = false;
  } else if (c) { c.pub = pub; }
  else state.contacts[email] = { pub, verified: false };
  await saveContacts();
  delete state.keyCache[email];
  return true;
}
async function addPerson(email, nick) {
  email = email.trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return toast('Enter a valid Gmail address.', 'error');
  if (email === state.myEmail) return toast("That's you.", 'error');
  const c = state.contacts[email] || (state.contacts[email] = { pub: null, verified: false });
  if (nick) c.nick = cleanStr(nick, 40);
  c.mine = true;
  await saveContacts();
  renderPeople();
  try {
    await relaySignal(email, { type: 'hello', pubkey: state.myPubB64 });
    toast(`Invitation sent to ${nameOf(email)}. They will see it when they open BEE.`);
  } catch (e) { if (e.code !== 'AUTH') toast(e instanceof TypeError ? 'No internet — try again when online.' : 'Could not send: ' + e.message, 'error'); }
}
async function handleHello(sender, sig) {
  if (typeof sig.pubkey !== 'string') return true;
  try { await crypto.subtle.importKey('raw', fromB64(sig.pubkey), ECDH, true, []); } catch { return true; }
  let c = state.contacts[sender];
  if (!c) {                                    // a stranger: wait for approval, tell nothing
    state.contacts[sender] = { pub: sig.pubkey, verified: false, incoming: true, seen: Date.now() };
    await saveContacts();
    renderPeople();
    toast('New contact request. Open People to accept or decline.');
    showNotif('BEE Messenger', 'New contact request', 'req');
    return true;
  }
  if (c.pub && c.pub !== sig.pubkey) { if (!(await acceptKey(sender, sig.pubkey))) return true; }
  else if (!c.pub) { c.pub = sig.pubkey; delete state.keyCache[sender]; await saveContacts(); }
  c = state.contacts[sender];
  if (c.incoming) return true;
  if (!sig.ack) await relaySignal(sender, { type: 'hello', ack: true, pubkey: state.myPubB64 });
  await sendProfile(sender);
  renderPeople();
  return true;
}
async function acceptContact(email) {
  const c = state.contacts[email];
  if (!c) return;
  c.incoming = false;
  await saveContacts();
  renderPeople();
  try { await relaySignal(email, { type: 'hello', ack: true, pubkey: state.myPubB64 }); await sendProfile(email); }
  catch (e) { if (e.code !== 'AUTH') toast('Accepted. They will be notified when you are back online.', 'info'); }
}
async function declineContact(email) {
  delete state.contacts[email];
  await saveContacts();
  renderPeople();
}
async function sendProfile(to) {
  const c = state.contacts[to];
  if (!c || !c.pub || c.incoming) return;
  const profile = { name: state.profile.name, bio: state.profile.bio, status: state.profile.status };
  if (isOnline(to)) { try { await p2pCtl({ t: 'profile', profile }); return; } catch { /* fall back */ } }
  try { await relaySend(to, { type: 'profile', mid: uuid(), ts: Date.now(), profile }, SUBJ.sys); } catch (e) { console.warn('profile', e); }
}
async function broadcastProfile() {
  for (const e of Object.keys(state.contacts)) await sendProfile(e);
}
function applyProfile(from, p) {
  const c = state.contacts[from];
  if (!c || !p) return;
  c.name = cleanStr(p.name, 40) || c.name;
  c.bio = cleanStr(p.bio, 160);
  c.status = cleanStr(p.status, 40);
  saveContacts();
  renderPeople();
  if (state.contact === from) refreshChatHeader();
}

// ---------------- RECEIVE / POLL ----------------
async function listUnprocessed() {
  const q = encodeURIComponent('subject:"BEE Messenger" -from:me');
  const out = [];
  let page = null;
  for (let i = 0; i < 5; i++) {
    const r = await (await gfetch(`${GM}/messages?q=${q}&maxResults=50` + (page ? `&pageToken=${page}` : ''))).json();
    const fresh = (r.messages || []).map(m => m.id).filter(id => !state.processed.has(id));
    out.push(...fresh);
    if (!fresh.length || !r.nextPageToken) break;
    page = r.nextPageToken;
  }
  return out;
}
async function processMessage(meta) {
  const sender = extractEmail(hdr(meta, 'From'));
  if (!sender || sender === state.myEmail) return;
  const full = await (await gfetch(`${GM}/messages/${meta.id}?format=full`)).json();
  const parsed = parseBee(await extractBody(meta.id, full.payload));
  if (!parsed) return;
  if (parsed.kind === 'sig') await handleSignal(sender, parsed.json, Date.now() - Number(meta.internalDate));
  else await handleEncrypted(sender, parsed.bytes);
}
async function pullMessages(manual = false) {
  if (!state.token || !state.myEmail || state.pulling || state.expired) return;
  state.pulling = true;
  try {
    const ids = await listUnprocessed();
    const metas = [];
    for (const id of ids) {
      metas.push(await (await gfetch(`${GM}/messages/${id}?format=metadata&metadataHeaders=From`)).json());
    }
    metas.sort((a, b) => Number(a.internalDate) - Number(b.internalDate));   // oldest first
    for (const m of metas) {
      try { await processMessage(m); }
      catch (e) {
        // transient problems: stop and retry next poll; permanent ones: skip this message
        if (e instanceof TypeError || e.code === 'AUTH' || e.status >= 500 || e.status === 429) throw e;
        console.error('Skipping bad message', m.id, e);
      }
      markProcessed(m.id);
    }
    if (manual && !metas.length) toast('No new messages');
  } catch (e) {
    if (e.code !== 'AUTH' && (manual || navigator.onLine)) toast('Pull error: ' + e.message, 'error');
  } finally { state.pulling = false; flushOutbox(); }
}
function markProcessed(id) {
  state.processed.add(id);
  const arr = Array.from(state.processed).slice(-1000);
  state.processed = new Set(arr);
  DB.set(K('processed'), arr).catch(() => {});
}
function startPolling() { state.polling = true; schedulePoll(); }
function stopPolling() { state.polling = false; clearTimeout(state.pollTimer); }
function schedulePoll() {
  clearTimeout(state.pollTimer);
  if (!state.polling) return;
  if (NATIVE && state.nativeSvc && document.hidden) return;   // the Android service does the waiting
  state.pollTimer = setTimeout(async () => { await pullMessages(); schedulePoll(); },
    document.hidden ? POLL_HIDDEN : POLL_VISIBLE);
}

async function handleEncrypted(sender, bytes) {
  const c = state.contacts[sender];
  if (!c || !c.pub || c.incoming || bytes.length < 12 + 16 + 4) return true;
  const key = await getKey(sender);
  let pt;
  try {
    pt = new Uint8Array(await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: bytes.slice(0, 12), additionalData: aad(sender, state.myEmail) }, key, bytes.slice(12)));
  } catch {
    toast(`Could not decrypt a message from ${nameOf(sender)} (keys changed?)`, 'error');
    return true;
  }
  const hl = new DataView(pt.buffer).getUint32(0);
  if (hl > 8192 || hl > pt.length - 4) return true;
  const h = JSON.parse(dec.decode(pt.subarray(4, 4 + hl)));
  await ingest(sender, h, pt.subarray(4 + hl), 'relay');
  return true;
}

// ---------------- MESSAGES ----------------
function sanitizeReply(r, fromThem) {
  if (!r || typeof r.mid !== 'string') return undefined;
  return { mid: r.mid.slice(0, 64), text: cleanStr(r.text, 120), who: fromThem ? (r.mine ? 'them' : 'me') : (r.who || 'them') };
}
async function ingest(from, h, data, via) {
  if (h.type === 'profile') return applyProfile(from, h.profile);
  if (h.type !== 'text' && h.type !== 'file') return;
  if (h.type === 'file' && via !== 'p2p') return;          // privacy rule: files never arrive through Gmail
  const c = state.contacts[from];
  if (!c || c.incoming) return;
  const conv = convKey(from), id = `${conv}:${h.mid}`;
  if (await DB.getMsg(id)) return;
  // time = THIS phone's clock at arrival (the sender's clock is ignored, only kept as sentTs)
  const m = { id, mid: String(h.mid), conv, side: 'them', ts: nowTs(), sentTs: Number(h.ts) || 0, via, status: 'sent' };
  if (h.type === 'text') {
    m.kind = 'text'; m.text = String(h.text || '').slice(0, 4000);
    m.reply = sanitizeReply(h.reply, true);
  } else {
    m.kind = 'file'; m.mime = safeMime(h.mime); m.name = cleanName(h.name); m.dur = Number(h.dur) || 0;
    m.blob = new Blob([data], { type: m.mime }); m.size = m.blob.size;
  }
  await DB.putMsg(m);
  c.seen = Date.now();
  onIncoming(from, m);
}
function previewOf(m) {
  if (m.kind === 'file') return /^audio\//.test(m.mime) ? 'Voice note' : /^image\//.test(m.mime) ? 'Photo' : /^video\//.test(m.mime) ? 'Video' : 'File';
  return m.text.replace(/[*_~`]/g, '');
}
function setLast(email, m) { state.lastMsg[email] = { text: previewOf(m), ts: m.ts, side: m.side }; }
function onIncoming(from, m) {
  setLast(from, m);
  const watching = state.view === 'chat' && state.contact === from && !document.hidden;
  if (state.view === 'chat' && state.contact === from) renderMessage(m);
  if (!watching) {
    state.unread[from] = (state.unread[from] || 0) + 1;
    updateTitle();
    if (!document.hidden) toast(`${nameOf(from)}: new message`);
    else showNotif(nameOf(from), 'New message', 'msg:' + from);
  }
  renderPeople();
}
function updateTitle() {
  const n = Object.values(state.unread).reduce((a, b) => a + b, 0);
  document.title = (n ? `(${n}) ` : '') + 'BEE Messenger';
}
async function showNotif(title, body, tag) {
  if (NATIVE) {
    if (state.nativeSvc) return;      // the background service already notifies
    try {
      const LN = CAP().LocalNotifications;
      const perm = await LN.checkPermissions();
      if (perm.display !== 'granted') return;
      await LN.schedule({ notifications: [{ id: Math.floor(Math.random() * 2e9), title, body, extra: { tag } }] });
    } catch { /* ignore */ }
    return;
  }
  if (!document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
  const opts = { body, tag, icon: 'icon.png', badge: 'icon.png' };
  try {
    const reg = navigator.serviceWorker && await navigator.serviceWorker.getRegistration();
    if (reg) { await reg.showNotification(title, opts); return; }
  } catch { /* fall through */ }
  try { new Notification(title, opts); } catch { /* ignore */ }
}
function ensureNotifPermission() {
  if (NATIVE) {
    const LN = CAP().LocalNotifications;
    if (LN) LN.checkPermissions()
      .then(p => (p.display === 'prompt' || p.display === 'prompt-with-rationale') ? LN.requestPermissions() : null)
      .then(refreshNotifLabel).catch(() => {});
    return;
  }
  if ('Notification' in window && Notification.permission === 'default') {
    try { Notification.requestPermission().then(refreshNotifLabel); } catch { /* ignore */ }
  }
}
function refreshNotifLabel() {
  const l = $('notif-label');
  if (!l) return;
  const set = (p) => { l.textContent = p === 'granted' ? 'Notifications are on' : p === 'denied' ? 'Blocked — enable in system settings' : 'Turn on notifications'; };
  if (NATIVE) {
    const LN = CAP().LocalNotifications;
    if (!LN) { l.textContent = 'Notifications not supported here'; return; }
    LN.checkPermissions().then(p => set(p.display)).catch(() => {});
  } else if (!('Notification' in window)) l.textContent = 'Notifications not supported here';
  else set(Notification.permission);
}

// ---------------- SENDING + OUTBOX ----------------
function withLock(fn) {
  const p = state.sendChain.then(fn, fn);
  state.sendChain = p.catch(() => {});
  return p;
}
const toOf = (m) => m.conv.slice(state.myEmail.length + 1);
function requireContact() { return !!state.contact; }
function requireInstant() {
  if (!state.contact) return false;
  if (isOnline(state.contact)) return true;
  $('instant-title').textContent = `Start Instant mode with ${nameOf(state.contact)}`;
  openDlg($('instant-dialog'));
  return false;
}
async function deliverText(m) {
  const to = toOf(m);
  if (isOnline(to)) { try { await p2pSend(m, null); return 'p2p'; } catch { /* fall back to Gmail */ } }
  await relaySend(to, m, SUBJ.msg);
  return 'relay';
}
async function flushOutbox() {
  if (state.outboxBusy || !state.myEmail || !state.token || state.expired || !navigator.onLine) return;
  state.outboxBusy = true;
  try {
    const rows = (await DB.allRaw()).filter(r => r.status === 'queued').sort((a, b) => a.ts - b.ts);
    for (const r of rows) {
      const m = await openMsg(r);
      if (!m || !state.contacts[toOf(m)] || !state.contacts[toOf(m)].pub) continue;
      try {
        m.via = await withLock(() => deliverText(m));
        m.status = 'sent';
        await DB.putMsg(m);
        updateBubble(m);
      } catch (e) {
        if (e.code === 'AUTH' || e instanceof TypeError || e.status >= 500 || e.status === 429) break;
        m.status = 'failed';
        await DB.putMsg(m);
        updateBubble(m);
      }
    }
  } catch (e) { console.warn('outbox', e); }
  finally { state.outboxBusy = false; }
}
function baseMsg() {
  const conv = convKey(state.contact);
  const mid = uuid();
  return { id: `${conv}:${mid}`, mid, conv, side: 'me', ts: nowTs() };
}
async function sendText() {
  const input = $('text-input');
  const text = input.value.trim();
  if (!text || !state.contact) return;
  const c = state.contacts[state.contact];
  if (!c || !c.pub) return toast(`${nameOf(state.contact)} hasn't accepted yet. Your message will not be sent until they do.`, 'error', 5000);
  ensureNotifPermission();
  input.value = '';
  autosize();
  input.focus();
  const m = { ...baseMsg(), kind: 'text', text, status: 'queued' };
  if (state.replyTo) m.reply = { mid: state.replyTo.mid, text: state.replyTo.text, who: state.replyTo.who, mine: state.replyTo.who === 'me' };
  clearReply();
  await DB.putMsg(m);          // saved on this phone first: nothing is lost if Gmail or internet is down
  setLast(state.contact, m);
  renderMessage(m);
  renderPeople();
  flushOutbox();
}
async function sendFile(file, extra = {}) {
  if (!file || !state.contact) return;
  if (!requireInstant()) return;
  if (file.size > MAX_P2P_MB * 1048576) return toast(`File too large (max ${MAX_P2P_MB} MB).`, 'error');
  const mime = safeMime(file.type);
  const blob = new Blob([file], { type: mime });
  const m = { ...baseMsg(), kind: 'file', name: cleanName(file.name), mime, size: blob.size, blob, dur: extra.dur || 0, status: 'sent' };
  toast('Sending ' + m.name + ' (' + fmtSize(m.size) + ')…');
  try {
    await withLock(() => p2pSend(m, blob));
    m.via = 'p2p';
    await DB.putMsg(m);
    setLast(state.contact, m);
    renderMessage(m);
    renderPeople();
  } catch (e) { toast('Not sent: ' + e.message + '. Files only travel in Instant mode.', 'error', 6000); }
}
function setReply(m) {
  state.replyTo = { mid: m.mid, text: clip(previewOf(m), 100), who: m.side === 'me' ? 'me' : 'them' };
  $('reply-who').textContent = m.side === 'me' ? 'You' : nameOf(state.contact);
  $('reply-text').textContent = state.replyTo.text;
  $('reply-bar').classList.remove('hidden');
  $('text-input').focus();
}
function clearReply() { state.replyTo = null; $('reply-bar').classList.add('hidden'); }

// ---------------- ICONS ----------------
const SVGNS = 'http://www.w3.org/2000/svg';
function icon(name, cls = 'ic') {
  const s = document.createElementNS(SVGNS, 'svg');
  s.setAttribute('class', cls);
  const u = document.createElementNS(SVGNS, 'use');
  u.setAttribute('href', '#i-' + name);
  s.append(u);
  return s;
}
function fmtDur(s) {
  s = Math.max(0, Math.round(s));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}
function fmtTime(ts) { return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
function dayLabel(ts) {
  const d = new Date(ts), t = new Date(), y = new Date();
  y.setDate(t.getDate() - 1);
  if (d.toDateString() === t.toDateString()) return 'Today';
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { day: 'numeric', month: 'short', year: d.getFullYear() === t.getFullYear() ? undefined : 'numeric' });
}
function listTime(ts) {
  const d = new Date(ts);
  return d.toDateString() === new Date().toDateString() ? fmtTime(ts) : dayLabel(ts);
}
function emptyEl(iconName, text) {
  const d = document.createElement('div');
  d.className = 'empty';
  const b = document.createElement('div'); b.className = 'big'; b.append(icon(iconName, 'ic ic-xl'));
  const p = document.createElement('div'); p.textContent = text;
  d.append(b, p);
  return d;
}
function revokeUrls() { state.urls.forEach(u => URL.revokeObjectURL(u)); state.urls = []; }

// ---------------- TEXT FORMATTING: *bold* _italic_ ~strike~ `code` ```block``` ----------------
const INLINE_RE = /`([^`\n]+)`|(?<![\w*])\*(?!\s)([^*\n]*?[^*\s])\*(?![\w*])|(?<![\w])_(?!\s)([^_\n]*?[^_\s])_(?![\w])|(?<![\w~])~(?!\s)([^~\n]*?[^~\s])~(?![\w~])/g;
function fmtInline(parent, t, depth = 0) {
  INLINE_RE.lastIndex = 0;
  const re = new RegExp(INLINE_RE.source, 'g');
  let last = 0, m;
  while ((m = re.exec(t))) {
    if (m.index > last) parent.append(t.slice(last, m.index));
    let el;
    if (m[1] != null) { el = document.createElement('code'); el.textContent = m[1]; }
    else {
      const tag = m[2] != null ? 'b' : m[3] != null ? 'i' : 's';
      el = document.createElement(tag);
      const inner = m[2] ?? m[3] ?? m[4];
      if (depth < 2) fmtInline(el, inner, depth + 1); else el.textContent = inner;
    }
    parent.append(el);
    last = re.lastIndex;
  }
  if (last < t.length) parent.append(t.slice(last));
}
function fmtInto(parent, text) {
  for (const p of text.split(/(```[\s\S]+?```)/)) {
    if (p.length > 6 && p.startsWith('```') && p.endsWith('```')) {
      const pre = document.createElement('pre');
      pre.textContent = p.slice(3, -3).replace(/^\n/, '');
      parent.append(pre);
    } else fmtInline(parent, p);
  }
}
function wrapSel(open, close = open) {
  const ta = $('text-input');
  const a = ta.selectionStart, b = ta.selectionEnd, v = ta.value;
  const sel = v.slice(a, b) || 'text';
  ta.value = v.slice(0, a) + open + sel + close + v.slice(b);
  ta.focus();
  ta.setSelectionRange(a + open.length, a + open.length + sel.length);
  autosize();
}

// ---------------- NAVIGATION ----------------
const SCREENS = ['login', 'welcome', 'people', 'me', 'chat'];
function show(view) {
  state.view = view;
  for (const s of SCREENS) $(s + '-screen').classList.toggle('hidden', s !== view);
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('on', b.dataset.go === view));
  if (view !== 'chat') closeMenu(true);
}
async function openChat(email) {
  const c = state.contacts[email];
  if (!c || c.incoming) return;
  state.contact = email;
  state.unread[email] = 0;
  updateTitle();
  clearReply();
  show('chat');
  refreshChatHeader();
  renderPeople();
  await renderAll();
}
function backToPeople() {
  state.contact = null;
  stopRecording(false);
  show('people');
  renderPeople();
}
function refreshPresenceUI() {
  renderPeople();
  if (state.view === 'chat') refreshChatHeader();
}
function refreshChatHeader() {
  const e = state.contact;
  if (!e) return;
  const c = state.contacts[e] || {};
  const online = isOnline(e), calling = state.calling === e;
  $('chat-name').textContent = nameOf(e);
  $('chat-av').replaceChildren(avatarEl(nameOf(e)));
  const sub = $('chat-sub');
  sub.textContent = online ? 'Online · Instant mode' : calling ? 'Waiting for them to join…' : 'Offline' + (c.status ? ' · ' + c.status : '');
  sub.className = 'sub-line' + (online ? ' online' : calling ? ' connecting' : '');
  const sb = $('shield-btn');
  sb.replaceChildren(icon(c.verified ? 'shield-check' : 'shield'));
  sb.classList.toggle('verified', !!c.verified);
  sb.title = c.verified ? 'Verified' : 'Not verified yet';
  $('instant-btn').classList.toggle('on', online);
  const st = $('peer-status');
  st.className = 'status ' + (online ? 'online' : calling ? 'connecting' : 'offline');
  $('peer-status-text').textContent = online
    ? 'Instant mode · direct and private. Photos, videos, files and voice notes are allowed.'
    : calling ? `Asking ${nameOf(e)} to join Instant mode…`
    : `${nameOf(e)} is offline. Text goes by encrypted Gmail; tap ⚡ to talk now.`;
  $('text-input').placeholder = c.pub ? 'Message' : 'Waiting for them to accept…';
}

// ---------------- PEOPLE LIST ----------------
function renderPeople() {
  const box = $('people-list');
  if (!box || !state.myEmail) return;
  const emails = Object.keys(state.contacts);
  const rank = (e) => (state.contacts[e].incoming ? 2e15 : 0) + ((state.lastMsg[e] && state.lastMsg[e].ts) || 0);
  emails.sort((a, b) => rank(b) - rank(a) || nameOf(a).localeCompare(nameOf(b)));
  if (!emails.length) {
    box.replaceChildren(emptyEl('user', 'No one here yet. Tap + and add a friend’s Gmail. Only people you add (and who accept) can talk to you.'));
    return;
  }
  box.replaceChildren(...emails.map(e => {
    const c = state.contacts[e], online = isOnline(e), last = state.lastMsg[e], un = state.unread[e] || 0;
    const row = document.createElement('div');
    row.className = 'person';
    const avWrap = document.createElement('div'); avWrap.className = 'av-wrap';
    avWrap.append(avatarEl(c.incoming ? e : nameOf(e)));
    const dot = document.createElement('span'); dot.className = 'pdot' + (online ? ' on' : '');
    avWrap.append(dot);
    const mid = document.createElement('div'); mid.className = 'p-mid';
    const nm = document.createElement('div'); nm.className = 'p-name'; nm.textContent = c.incoming ? e : nameOf(e);
    const sub = document.createElement('div'); sub.className = 'p-sub';
    if (c.incoming) sub.textContent = 'wants to connect with you';
    else if (!c.pub) sub.textContent = 'Waiting for them to accept';
    else if (state.calling === e) sub.textContent = 'Asking to join Instant…';
    else if (online) sub.textContent = 'Online · Instant mode';
    else sub.textContent = last ? (last.side === 'me' ? 'You: ' : '') + last.text : (c.status || 'Offline');
    mid.append(nm, sub);
    const end = document.createElement('div'); end.className = 'p-end';
    if (c.incoming) {
      const ok = document.createElement('button'); ok.className = 'primary small'; ok.textContent = 'Accept';
      ok.onclick = () => acceptContact(e);
      const no = document.createElement('button'); no.className = 'small'; no.textContent = 'Decline';
      no.onclick = () => declineContact(e);
      end.append(ok, no);
    } else {
      const meta = document.createElement('div'); meta.className = 'p-meta';
      if (last) { const t = document.createElement('span'); t.textContent = listTime(last.ts); meta.append(t); }
      if (un) { const b = document.createElement('span'); b.className = 'badge'; b.textContent = un > 99 ? '99+' : un; meta.append(b); }
      const z = document.createElement('button');
      z.className = 'icon instant' + (online ? ' on' : '');
      z.title = 'Instant mode'; z.setAttribute('aria-label', 'Instant mode with ' + nameOf(e));
      z.append(icon('zap'));
      z.onclick = (ev) => { ev.stopPropagation(); talkNow(e); };
      end.append(meta, z);
      row.onclick = () => openChat(e);
    }
    row.append(avWrap, mid, end);
    return row;
  }));
}

// ---------------- CHAT RENDERING ----------------
async function renderAll() {
  const seq = ++state.renderSeq;
  const box = $('messages');
  closeMenu(true);
  if (curAudio) { curAudio.pause(); curAudio = null; }
  revokeUrls();
  state.lastDay = null;
  box.replaceChildren();
  if (!state.contact) return;
  const msgs = (await DB.msgsFor(convKey(state.contact))).sort((a, b) => a.ts - b.ts);
  if (seq !== state.renderSeq) return;
  if (!msgs.length) { box.append(emptyEl('lock', `Say hello to ${nameOf(state.contact)}. Everything here is end-to-end encrypted.`)); return; }
  msgs.forEach(m => renderMessage(m, false));
  box.style.scrollBehavior = 'auto';
  box.scrollTop = box.scrollHeight;
  box.style.scrollBehavior = '';
}
let curAudio = null;
function buildVoice(m, url) {
  const wrap = document.createElement('div');
  wrap.className = 'voice';
  const btn = document.createElement('button');
  btn.className = 'vbtn';
  btn.setAttribute('aria-label', 'Play voice note');
  btn.append(icon('play'));
  const track = document.createElement('div'); track.className = 'vtrack';
  const fill = document.createElement('div'); fill.className = 'vfill';
  track.append(fill);
  const time = document.createElement('span'); time.className = 'vtime';
  const audio = new Audio(url);
  audio.preload = 'metadata';
  const total = () => (Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : (m.dur || 0));
  time.textContent = fmtDur(total());
  btn.onclick = () => {
    if (audio.paused) {
      if (curAudio && curAudio !== audio) curAudio.pause();
      curAudio = audio;
      audio.play().catch(() => {});
    } else audio.pause();
  };
  audio.onplay = () => btn.replaceChildren(icon('pause'));
  audio.onpause = () => btn.replaceChildren(icon('play'));
  audio.onended = () => { fill.style.width = '0%'; time.textContent = fmtDur(total()); btn.replaceChildren(icon('play')); };
  audio.ontimeupdate = () => {
    const t = total();
    fill.style.width = t ? Math.min(100, audio.currentTime / t * 100) + '%' : '0%';
    time.textContent = fmtDur(audio.currentTime > 0 ? audio.currentTime : t);
  };
  track.onclick = (e) => {
    const t = total();
    if (!t) return;
    const r = track.getBoundingClientRect();
    audio.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * t;
  };
  wrap.append(btn, track, time);
  return wrap;
}

function statusIcon(m) {
  if (m.status === 'queued') return icon('clock', 'ic ic-sm');
  if (m.status === 'failed') return icon('alert', 'ic ic-sm');
  return icon(m.via === 'p2p' ? 'zap' : 'mail', 'ic ic-sm');
}
function buildMeta(m, withMore) {
  const meta = document.createElement('div');
  meta.className = 'meta';
  if (withMore) {
    const b = document.createElement('button');
    b.className = 'more-btn';
    b.setAttribute('aria-label', 'Options');
    b.append(icon('more'));
    meta.append(b);
  }
  if (m.status === 'queued') { const w = document.createElement('span'); w.textContent = 'Waiting to send ·'; meta.append(w); }
  if (m.status === 'failed') { const w = document.createElement('span'); w.textContent = 'Not sent · tap to retry ·'; meta.append(w); }
  const tm = document.createElement('span');
  tm.textContent = fmtTime(m.ts);
  meta.append(tm, statusIcon(m));
  return meta;
}
function buildBubble(m, live) {
  const div = document.createElement('div');
  div.className = 'msg ' + m.side + (live ? ' pop' : '');
  div.dataset.mid = m.mid;
  div._m = m;
  let withMore = false;
  if (m.reply) {
    const q = document.createElement('div');
    q.className = 'quote';
    q.dataset.target = m.reply.mid;
    const w = document.createElement('b'); w.textContent = m.reply.who === 'me' ? 'You' : nameOf(state.contact);
    const t = document.createElement('span'); t.textContent = m.reply.text;
    q.append(w, t);
    div.append(q);
  }
  if (m.kind === 'text') {
    fmtInto(div, m.text);
  } else if (m.blob) {
    const url = URL.createObjectURL(m.blob);
    state.urls.push(url);
    if (/^image\//.test(m.mime)) {
      div.classList.add('media');
      const i = document.createElement('img');
      i.src = url; i.alt = m.name; i.draggable = false; i.decoding = 'async';
      div.append(i);
    } else if (/^video\//.test(m.mime)) {
      div.classList.add('media');
      const v = document.createElement('video');
      v.src = url; v.controls = true; v.preload = 'metadata'; v.playsInline = true;
      div.append(v);
      withMore = true;
    } else if (/^audio\//.test(m.mime)) {
      div.append(buildVoice(m, url));
    } else {
      const f = document.createElement('div'); f.className = 'filebox';
      f.append(icon('file'));
      const t = document.createElement('div');
      const n = document.createElement('div'); n.className = 'fname'; n.textContent = m.name;
      const sz = document.createElement('div'); sz.className = 'fsize'; sz.textContent = fmtSize(m.size || 0);
      t.append(n, sz);
      f.append(t);
      div.append(f);
    }
  }
  div.append(buildMeta(m, withMore));
  return div;
}
function renderMessage(m, live = true) {
  const box = $('messages');
  const em = box.querySelector('.empty');
  if (em) em.remove();
  const near = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  const day = new Date(m.ts).toDateString();
  if (day !== state.lastDay) {
    state.lastDay = day;
    const d = document.createElement('div');
    d.className = 'day';
    d.textContent = dayLabel(m.ts);
    box.append(d);
  }
  box.append(buildBubble(m, live));
  if (live && (near || m.side === 'me')) box.scrollTop = box.scrollHeight;
}
function updateBubble(m) {
  if (state.contact !== toOf(m)) return;
  const el = [...$('messages').querySelectorAll('.msg')].find(e => e._m && e._m.id === m.id);
  if (!el) return;
  el._m = m;
  el.querySelector('.meta').replaceWith(buildMeta(m, !!el.querySelector('video')));
}
function jumpTo(mid) {
  const el = [...$('messages').querySelectorAll('.msg')].find(e => e.dataset.mid === mid);
  if (!el) return toast('That message is no longer on this phone.');
  el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  el.classList.add('flash');
  setTimeout(() => el.classList.remove('flash'), 1200);
}

// ---------------- MESSAGE MENU ----------------
function saveName(m) {
  if (/^voice-note\./.test(m.name)) {
    const d = new Date(m.ts), p = n => String(n).padStart(2, '0');
    return `voice-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${m.name.slice(m.name.lastIndexOf('.'))}`;
  }
  return m.name;
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const t = document.createElement('textarea');
    t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
    document.body.append(t); t.select();
    try { document.execCommand('copy'); } catch { /* ignore */ }
    t.remove();
  }
  toast('Copied');
}
function saveFile(m) {
  if (NATIVE) return nativeSave(m);
  const url = URL.createObjectURL(m.blob);
  const a = document.createElement('a');
  a.href = url; a.download = saveName(m);
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15000);
  toast('Saved to your Downloads');
}
async function nativeSave(m) {
  const { Filesystem } = CAP();
  try {
    await Filesystem.writeFile({ path: 'BEE/' + saveName(m), data: toB64(await m.blob.arrayBuffer()), directory: 'DOCUMENTS', recursive: true });
    toast('Saved to Documents/BEE');
  } catch {
    await nativeShare(m);   // Android refused: use the share sheet ("Save to device", Files, Drive...)
  }
}
async function nativeShare(m) {
  const { Filesystem, Share } = CAP();
  try {
    const w = await Filesystem.writeFile({ path: saveName(m), data: toB64(await m.blob.arrayBuffer()), directory: 'CACHE' });
    await Share.share({ title: saveName(m), files: [w.uri] });
  } catch (e) {
    if (!/cancel/i.test(String(e && e.message))) toast('Could not share: ' + (e && e.message || e), 'error');
  }
}
function shareable(m) {
  try { return !!(navigator.canShare && navigator.canShare({ files: [new File([m.blob], saveName(m), { type: m.mime })] })); }
  catch { return false; }
}
async function shareFile(m) {
  if (NATIVE) return nativeShare(m);
  try { await navigator.share({ files: [new File([m.blob], saveName(m), { type: m.mime })] }); } catch { /* cancelled */ }
}
async function deleteMsg(m) {
  if (!confirm('Delete this message from this device?')) return;
  await DB.delMsg(m.id);
  const el = [...$('messages').querySelectorAll('.msg')].find(e => e._m && e._m.id === m.id);
  if (el) el.remove();
  if (!$('messages').querySelector('.msg')) renderAll();
}
function menuItems(m) {
  const it = [];
  it.push({ icon: 'reply', label: 'Reply', fn: () => setReply(m) });
  if (m.status === 'failed') it.push({ icon: 'refresh', label: 'Try sending again', fn: async () => { m.status = 'queued'; await DB.putMsg(m); updateBubble(m); flushOutbox(); } });
  if (m.kind === 'text') it.push({ icon: 'copy', label: 'Copy text', fn: () => copyText(m.text) });
  else if (m.blob) {
    it.push({ icon: 'download', label: 'Save to device', fn: () => saveFile(m) });
    if (NATIVE || shareable(m)) it.push({ icon: 'share', label: 'Share…', fn: () => shareFile(m) });
  }
  it.push({ icon: 'trash', label: 'Delete for me', danger: true, fn: () => deleteMsg(m) });
  return it;
}
function openMenuFor(div) {
  const m = div._m;
  if (!m) return;
  closeMenu(true);
  const menu = $('msg-menu');
  menu.replaceChildren();
  for (const it of menuItems(m)) {
    const b = document.createElement('button');
    b.className = 'menu-item' + (it.danger ? ' danger' : '');
    b.setAttribute('role', 'menuitem');
    b.append(icon(it.icon), document.createTextNode(it.label));
    b.addEventListener('click', () => { closeMenu(); it.fn(); });
    menu.append(b);
  }
  state.menuBubble = div;
  state.menuAt = Date.now();
  div.classList.add('active');
  $('menu-scrim').classList.remove('hidden');
  menu.classList.remove('hidden', 'show');
  const r = div.getBoundingClientRect();
  const mw = menu.offsetWidth, mh = menu.offsetHeight;
  let top = r.top - mh - 8, originY = 'bottom';
  if (top < 60) { top = r.bottom + 8; originY = 'top'; }
  if (top + mh > innerHeight - 8) top = Math.max(8, innerHeight - mh - 8);
  let left = m.side === 'me' ? r.right - mw : r.left;
  left = Math.max(8, Math.min(left, innerWidth - mw - 8));
  menu.style.top = top + 'px';
  menu.style.left = left + 'px';
  menu.style.transformOrigin = `${m.side === 'me' ? 'right' : 'left'} ${originY}`;
  requestAnimationFrame(() => menu.classList.add('show'));
}
function closeMenu(instant) {
  const menu = $('msg-menu');
  if (menu.classList.contains('hidden') && !state.menuBubble) return;
  if (state.menuBubble) { state.menuBubble.classList.remove('active'); state.menuBubble = null; }
  $('menu-scrim').classList.add('hidden');
  menu.classList.remove('show');
  if (instant) { menu.classList.add('hidden'); return; }
  setTimeout(() => { if (!menu.classList.contains('show')) menu.classList.add('hidden'); }, 170);
}

// ---------------- COMPOSER / VOICE NOTES ----------------
const BARS = 36;
function autosize() {
  const ta = $('text-input');
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 140) + 'px';
  updateAction();
}
function updateAction() {
  const has = $('text-input').value.trim().length > 0;
  const b = $('action-btn');
  b.classList.toggle('send-mode', has || !!state.recording);
  b.setAttribute('aria-label', has ? 'Send message' : state.recording ? 'Send voice note' : 'Record voice note');
}
function onAction() {
  if (state.recording) return stopRecording(true);
  if ($('text-input').value.trim()) return sendText();
  ensureNotifPermission();
  startRecording();
}
function createBars() {
  $('rec-bars').replaceChildren(...Array.from({ length: BARS }, () => document.createElement('span')));
}
function drawBars(levels) {
  const spans = $('rec-bars').children;
  for (let i = 0; i < spans.length; i++) spans[i].style.height = Math.max(4, Math.round((levels[i] || 0) * 30)) + 'px';
}
async function startRecording() {
  if (state.recording || state.recStarting || !requireInstant()) return;
  state.recStarting = true;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mt = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm', 'audio/ogg'].find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t)) || '';
    const rec = new MediaRecorder(stream, mt ? { mimeType: mt } : {});
    const chunks = [];
    const r = { rec, stream, start: Date.now(), cancel: false, levels: new Array(BARS).fill(0.05), raf: 0, ac: null, timer: 0, fake: 0, auto: 0 };
    state.recording = r;
    rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
    rec.onstop = async () => {
      const dur = (Date.now() - r.start) / 1000;
      cleanupRecording(r);
      if (r.cancel || !chunks.length) return;
      if (dur < 0.7) return toast('Voice note too short');
      const type = (rec.mimeType || mt || 'audio/webm').split(';')[0];
      const ext = type.includes('mp4') ? 'm4a' : type.includes('ogg') ? 'ogg' : 'webm';
      await sendFile(new File([new Blob(chunks, { type })], `voice-note.${ext}`, { type }), { dur });
    };
    rec.start();
    $('input-pill').classList.add('hidden');
    $('rec-bar').classList.remove('hidden');
    $('rec-time').textContent = '0:00';
    drawBars(r.levels);
    updateAction();
    r.timer = setInterval(() => { $('rec-time').textContent = fmtDur((Date.now() - r.start) / 1000); }, 250);
    r.auto = setTimeout(() => stopRecording(true), 120000);
    try {   // live level meter
      const ac = new (window.AudioContext || window.webkitAudioContext)();
      r.ac = ac;
      if (ac.resume) ac.resume();
      const an = ac.createAnalyser();
      an.fftSize = 256;
      ac.createMediaStreamSource(stream).connect(an);
      const buf = new Uint8Array(an.fftSize);
      let last = 0;
      const loop = (t) => {
        if (state.recording !== r) return;
        if (t - last > 70) {
          last = t;
          an.getByteTimeDomainData(buf);
          let sum = 0;
          for (const v of buf) { const x = (v - 128) / 128; sum += x * x; }
          r.levels.push(Math.max(0.06, Math.min(1, Math.sqrt(sum / buf.length) * 4)));
          r.levels.shift();
          drawBars(r.levels);
        }
        r.raf = requestAnimationFrame(loop);
      };
      r.raf = requestAnimationFrame(loop);
    } catch {
      r.fake = setInterval(() => { r.levels.push(0.15 + Math.random() * 0.6); r.levels.shift(); drawBars(r.levels); }, 90);
    }
  } catch (e) {
    toast('Microphone error: ' + e.message, 'error');
  } finally { state.recStarting = false; }
}
function stopRecording(send) {
  const r = state.recording;
  if (!r) return;
  r.cancel = !send;
  if (r.rec.state === 'recording') r.rec.stop(); else cleanupRecording(r);
}
function cleanupRecording(r) {
  clearInterval(r.timer); clearInterval(r.fake); clearTimeout(r.auto); cancelAnimationFrame(r.raf);
  r.stream.getTracks().forEach(t => t.stop());
  try { if (r.ac) r.ac.close(); } catch { /* ignore */ }
  if (state.recording === r) state.recording = null;
  $('rec-bar').classList.add('hidden');
  $('input-pill').classList.remove('hidden');
  updateAction();
}

// ---------------- SETUP (web build only; the Android app has these baked in) ----------------
function showSetup() {
  $('setup-area').classList.remove('hidden');
  $('login-btn').classList.add('hidden');
  $('client-id-input').value = localStorage.getItem('bee_clientId') || '';
  $('turn-input').value = localStorage.getItem('bee_turn') || '';
}
function saveSetup() {
  const val = $('client-id-input').value.trim();
  if (!val.endsWith('.apps.googleusercontent.com')) return toast('Invalid Client ID format.', 'error');
  const turn = $('turn-input').value.trim();
  if (turn) {
    try { if (!Array.isArray(JSON.parse(turn))) throw 0; }
    catch { return toast('TURN must be a JSON array.', 'error'); }
  }
  localStorage.setItem('bee_clientId', val);
  if (turn) localStorage.setItem('bee_turn', turn); else localStorage.removeItem('bee_turn');
  $('setup-area').classList.add('hidden');
  initAuth();
}

// ---------------- AUTH ----------------
async function initAuth() {
  const preset = NATIVE && window.BEE_NATIVE && window.BEE_NATIVE.clientId;
  if (preset) localStorage.setItem('bee_clientId', preset);
  const cid = localStorage.getItem('bee_clientId');
  if (!cid) return showSetup();
  if (NATIVE) return initNativeAuth();
  tokenClient = google.accounts.oauth2.initTokenClient({
    client_id: cid,
    scope: SCOPES.join(' '),
    callback: onToken,
    error_callback: (e) => {
      if (state.pending) state.pending.reject(e);
      else if (e.type !== 'popup_closed') toast('Sign-in failed: ' + (e.type || 'unknown'), 'error');
    }
  });
  try {   // restore a still-valid token for this browser tab session
    const s = JSON.parse(sessionStorage.getItem('bee_tok') || 'null');
    if (s && s.e > Date.now() + 60000) { state.token = s.t; state.tokenExp = s.e; onLoggedIn(); return; }
  } catch { /* ignore */ }
  $('login-btn').classList.remove('hidden');
}
// ---- Android app sign-in: system browser + PKCE (Google blocks web sign-in inside WebViews) ----
const nativeRedirect = (cid) => 'com.googleusercontent.apps.' + cid.replace(/\.apps\.googleusercontent\.com$/, '') + ':/oauth2redirect';
function setTokenFields(access, expiresIn) {
  state.token = access;
  state.tokenExp = Date.now() + Number(expiresIn || 3600) * 1000;
  try { sessionStorage.setItem('bee_tok', JSON.stringify({ t: state.token, e: state.tokenExp })); } catch { /* ignore */ }
  state.expired = false;
  hideBanner();
}
let nativeFlowActive = false;
// If the phone (e.g. MIUI) killed the app while the browser was open, finish the sign-in after the app restarts
async function resumeNativeSignIn(url) {
  try {
    if (nativeFlowActive) return;
    const cid = localStorage.getItem('bee_clientId');
    if (!cid || !url || !url.startsWith(nativeRedirect(cid).split(':')[0] + ':')) return;
    const p = JSON.parse(localStorage.getItem('bee_pkce') || 'null');
    const q = new URLSearchParams(url.split('?')[1] || '');
    if (!p || p.s !== q.get('state') || !q.get('code') || Date.now() - p.t > 600000) return;
    localStorage.removeItem('bee_pkce');
    try { CAP().Browser.close(); } catch { /* ignore */ }
    const r = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: cid, code: q.get('code'), code_verifier: p.v, redirect_uri: nativeRedirect(cid), grant_type: 'authorization_code' })
    });
    const t = await r.json();
    if (!t.access_token) throw new Error(t.error_description || t.error || 'Token exchange failed');
    setTokenFields(t.access_token, t.expires_in);
    if (t.refresh_token) localStorage.setItem('bee_refresh', t.refresh_token);
    onLoggedIn();
  } catch (e) { toast('Sign-in failed: ' + e.message, 'error', 7000); }
}
async function initNativeAuth() {
  const { App: CapApp } = CAP();
  if (CapApp && !window.__beeUrlHook) {
    window.__beeUrlHook = true;
    CapApp.addListener('appUrlOpen', (ev) => resumeNativeSignIn(ev.url));
    try { const l = await CapApp.getLaunchUrl(); if (l && l.url) resumeNativeSignIn(l.url); } catch { /* ignore */ }
  }
  try {
    const s = JSON.parse(sessionStorage.getItem('bee_tok') || 'null');
    if (s && s.e > Date.now() + 60000) { state.token = s.t; state.tokenExp = s.e; return onLoggedIn(); }
  } catch { /* ignore */ }
  if (localStorage.getItem('bee_refresh')) {   // stay signed in across app restarts
    try { await refreshToken(); return onLoggedIn(); } catch (e) { console.warn('Silent sign-in failed', e); }
  }
  $('login-btn').classList.remove('hidden');
}
async function nativeSignIn() {
  const { Browser, App } = CAP();
  if (!Browser || !App) throw new Error('Native plugins missing');
  const cid = localStorage.getItem('bee_clientId');
  const redirect = nativeRedirect(cid);
  const scheme = redirect.split(':')[0] + ':';
  const verifier = b64url(crypto.getRandomValues(new Uint8Array(48)));
  const challenge = b64url(new Uint8Array(await crypto.subtle.digest('SHA-256', utf8.encode(verifier))));
  const st = b64url(crypto.getRandomValues(new Uint8Array(16)));
  try { localStorage.setItem('bee_pkce', JSON.stringify({ v: verifier, s: st, t: Date.now() })); } catch { /* ignore */ }
  nativeFlowActive = true;
  const params = {
    client_id: cid, redirect_uri: redirect, response_type: 'code', scope: SCOPES.join(' '),
    code_challenge: challenge, code_challenge_method: 'S256', access_type: 'offline', prompt: 'consent', state: st
  };
  if (state.myEmail) params.login_hint = state.myEmail;

  let resolveCode, rejectCode, done = false;
  const codeP = new Promise((res, rej) => { resolveCode = res; rejectCode = rej; });
  const subs = [];
  const finish = (ok, v) => { if (done) return; done = true; nativeFlowActive = false; subs.forEach(h => { try { h.remove(); } catch { /* ignore */ } }); ok ? resolveCode(v) : rejectCode(v); };
  subs.push(await App.addListener('appUrlOpen', (ev) => {
    if (!ev.url || !ev.url.startsWith(scheme)) return;
    const q = new URLSearchParams(ev.url.split('?')[1] || '');
    if (q.get('state') !== st) return;   // stale redirect from an earlier attempt: ignore it
    try { localStorage.removeItem('bee_pkce'); } catch { /* ignore */ }
    try { Browser.close(); } catch { /* ignore */ }
    if (q.get('error')) return finish(false, new Error(q.get('error')));
    finish(true, q.get('code'));
  }));
  subs.push(await Browser.addListener('browserFinished', () => setTimeout(() => finish(false, new Error('Sign-in cancelled')), 4000)));
  await Browser.open({ url: 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams(params) });
  const code = await codeP;

  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: cid, code, code_verifier: verifier, redirect_uri: redirect, grant_type: 'authorization_code' })
  });
  const t = await r.json();
  if (!t.access_token) throw new Error(t.error_description || t.error || 'Token exchange failed');
  return t;
}
async function nativeLogin() {
  try {
    const t = await nativeSignIn();
    setTokenFields(t.access_token, t.expires_in);
    if (t.refresh_token) localStorage.setItem('bee_refresh', t.refresh_token);
    if (!state.myEmail) onLoggedIn(); else pullMessages();
  } catch (e) { toast('Sign-in failed: ' + e.message, 'error', 7000); }
}
async function nativeRefresh() {
  const rt = localStorage.getItem('bee_refresh');
  if (!rt) throw new Error('No saved session');
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: localStorage.getItem('bee_clientId'), refresh_token: rt, grant_type: 'refresh_token' })
  });
  const t = await r.json();
  if (!t.access_token) {
    if (t.error === 'invalid_grant') localStorage.removeItem('bee_refresh');
    throw new Error(t.error_description || t.error || 'Refresh failed');
  }
  setTokenFields(t.access_token, t.expires_in);
}
function startLogin() {
  if (NATIVE) return nativeLogin();
  if (!tokenClient) return initAuth();
  tokenClient.requestAccessToken(state.myEmail ? { prompt: '', login_hint: state.myEmail } : {});
}
function onToken(resp) {
  if (resp.error) {
    if (state.pending) state.pending.reject(new Error(resp.error));
    return toast('Auth error: ' + resp.error, 'error');
  }
  if (!google.accounts.oauth2.hasGrantedAllScopes(resp, ...SCOPES)) {
    return toast('Please tick ALL permission boxes on the Google consent screen.', 'error', 6000);
  }
  state.token = resp.access_token;
  state.tokenExp = Date.now() + Number(resp.expires_in || 3600) * 1000;
  try { sessionStorage.setItem('bee_tok', JSON.stringify({ t: state.token, e: state.tokenExp })); } catch { /* ignore */ }
  state.expired = false;
  hideBanner();
  if (state.pending) state.pending.resolve();
  if (!state.myEmail) onLoggedIn();
  else { pullMessages(); }
}

async function loadLastMsgs() {
  const rows = await DB.allRaw(), best = {}, p = state.myEmail + '|';
  for (const r of rows) {
    if (!r.conv.startsWith(p)) continue;
    const e = r.conv.slice(p.length);
    if (!best[e] || r.ts > best[e].ts) best[e] = r;
  }
  for (const e of Object.keys(best)) { try { const m = await openMsg(best[e]); if (m) setLast(e, m); } catch { /* ignore */ } }
}
async function onLoggedIn() {
  if (state.myEmail) return;
  try {
    const info = await (await gfetch('https://www.googleapis.com/oauth2/v3/userinfo')).json();
    state.myEmail = String(info.email).toLowerCase();
    state.keyPair = (await DB.get(K('keypair'))) || await createKeys();
    state.myPubB64 = toB64(await crypto.subtle.exportKey('raw', state.keyPair.publicKey));
    state.contacts = (await DB.get(K('contacts'))) || {};
    state.profile = { ...state.profile, ...((await DB.get(K('profile'))) || {}) };
    state.processed = new Set((await DB.get(K('processed'))) || []);
    await loadLastMsgs();
    $('login-screen').classList.add('hidden');
    if (!state.profile.name) { $('wl-status').value = 'Available'; show('welcome'); }
    else enterApp();
  } catch (e) {
    state.myEmail = null; state.token = null;
    sessionStorage.removeItem('bee_tok');
    show('login');
    $('login-btn').classList.remove('hidden');
    toast('Login failed: ' + e.message, 'error');
  }
}
function enterApp() {
  show('people');
  renderPeople();
  renderMe();
  startPolling();
  pullMessages();
  refreshNotifLabel();
  nativeSync().then(maybeAskBattery);
  nativeFg(true);
}
async function commitProfile(name, bio, status) {
  name = cleanStr(name, 40);
  if (!name) { toast('Please enter your name.', 'error'); return false; }
  state.profile = { name, bio: cleanStr(bio, 160), status: cleanStr(status, 40) || 'Available' };
  await saveProfile();
  return true;
}
function renderMe() {
  $('me-name').value = state.profile.name;
  $('me-bio').value = state.profile.bio;
  $('me-status').value = state.profile.status;
  $('me-av').replaceChildren(avatarEl(state.profile.name || '?', true));
  $('bg-btn').classList.toggle('hidden', !NATIVE);
  refreshLockLabel();
  refreshNotifLabel();
}
function refreshLockLabel() { $('lock-label').textContent = state.lock ? 'App lock is ON (tap to turn off)' : 'Lock the app with a PIN and encrypt chats on this phone'; }

function logout() {
  try { if (state.token) google.accounts.oauth2.revoke(state.token); } catch { /* ignore */ }
  sessionStorage.removeItem('bee_tok');
  localStorage.removeItem('bee_refresh');
  nativeClear();
  stopRecording(false);
  stopPolling();
  closePeer(); clearCall();
  Object.assign(state, { token: null, myEmail: null, contact: null, keyPair: null, contacts: {}, keyCache: {}, expired: false, unread: {}, lastMsg: {}, nativeSvc: false });
  hideBanner();
  document.querySelectorAll('dialog[open]').forEach(d => d.close());
  $('messages').replaceChildren();
  show('login');
  $('login-btn').classList.remove('hidden');
}
async function wipeAll() {
  if (!confirm('Delete ALL messages, contacts and your encryption keys from this device?\nYour contacts will see a "key changed" warning if you chat again.')) return;
  try { google.accounts.oauth2.revoke(state.token); } catch { /* ignore */ }
  nativeClear();
  if (DB.db) DB.db.close();
  indexedDB.deleteDatabase('bee');
  Object.keys(localStorage).filter(k => k.startsWith('bee_')).forEach(k => localStorage.removeItem(k));
  sessionStorage.clear();
  location.reload();
}

// ---------------- ANDROID BACKGROUND SERVICE BRIDGE ----------------
const BEE = () => CAP().BeeBridge;
async function nativeSync() {
  if (!NATIVE || !BEE() || !state.myEmail) return;
  const names = {};
  for (const e of Object.keys(state.contacts)) names[e] = nameOf(e);
  try {
    await BEE().configure({ clientId: localStorage.getItem('bee_clientId') || '', refreshToken: localStorage.getItem('bee_refresh') || '', email: state.myEmail, names: JSON.stringify(names) });
    await BEE().start();
    state.nativeSvc = true;
  } catch (e) { state.nativeSvc = false; console.warn('service', e); }
}
function nativeFg(fg) { try { if (NATIVE && BEE()) BEE().setForeground({ fg }); } catch { /* ignore */ } }
function nativeClear() { try { if (NATIVE && BEE()) BEE().clear(); } catch { /* ignore */ } }
async function askBattery() {
  try { await BEE().requestBatteryExemption(); } catch (e) { toast('Open Android Settings > Battery and allow BEE to run unrestricted.', 'info', 7000); }
}
function maybeAskBattery() {
  if (!NATIVE || !BEE() || localStorage.getItem('bee_battery_asked')) return;
  localStorage.setItem('bee_battery_asked', '1');
  if (confirm('To tell you about new messages while BEE is closed, Android must let BEE run in the background.\n\nBEE will show a small "listening" notification. Allow it on the next screen?')) askBattery();
}

// ---------------- DIALOG ACTIONS ----------------
async function openVerify() {
  const e = state.contact, c = e && state.contacts[e];
  if (!c || !c.pub) return toast('Available once they accept you.');
  $('verify-title').textContent = `Is this really ${nameOf(e)}?`;
  $('safety').textContent = await safetyNumber(c.pub);
  $('verify-state').textContent = c.verified ? '✓ Verified. You confirmed this number together.' : 'Not verified yet';
  $('verify-state').className = 'verify-state' + (c.verified ? ' ok' : '');
  $('verify-ok').classList.toggle('hidden', !!c.verified);
  openDlg($('verify-dialog'));
}
async function markVerified() {
  const c = state.contacts[state.contact];
  if (c) { c.verified = true; await saveContacts(); refreshChatHeader(); renderPeople(); toast('Marked as verified'); }
  closeDlg($('verify-dialog'));
}
function openContactInfo() {
  const e = state.contact, c = e && state.contacts[e];
  if (!c) return;
  $('ci-av').replaceChildren(avatarEl(nameOf(e), true));
  $('ci-name').textContent = nameOf(e);
  $('ci-status').textContent = c.status || 'No status';
  $('ci-bio').textContent = c.bio || 'No bio yet';
  $('ci-nick').value = c.nick || '';
  openDlg($('contact-dialog'));
}
async function togglePin() {
  if (state.lock) {
    if (!confirm('Turn off app lock? Chats will be stored on this phone without a PIN.')) return;
    await disablePin(); toast('App lock is off'); refreshLockLabel();
  } else { $('pin-new').value = ''; $('pin-new2').value = ''; openDlg($('pin-dialog')); }
}
async function savePin() {
  const a = $('pin-new').value, b = $('pin-new2').value;
  if (!/^\d{4,12}$/.test(a)) return toast('PIN must be 4 to 12 digits.', 'error');
  if (a !== b) return toast('The two PINs do not match.', 'error');
  $('pin-save').disabled = true;
  toast('Encrypting your chats…');
  try { await enablePin(a); closeDlg($('pin-dialog')); refreshLockLabel(); toast('App lock is on. Remember your PIN: it cannot be recovered.', 'info', 7000); }
  catch (e) { toast('Could not enable lock: ' + e.message, 'error'); }
  $('pin-save').disabled = false;
}
let lockCb = null, lockFails = 0;
function showLock(cb) {
  lockCb = cb;
  $('lock-screen').classList.remove('hidden');
  $('pin-input').value = ''; $('lock-err').textContent = '';
  setTimeout(() => $('pin-input').focus(), 120);
}
async function submitLock() {
  const btn = $('unlock-btn');
  btn.disabled = true;
  const ok = await tryUnlock($('pin-input').value);
  if (!ok) {
    lockFails++;
    $('lock-err').textContent = 'Wrong PIN';
    $('pin-input').value = '';
    setTimeout(() => { btn.disabled = false; }, lockFails >= 5 ? 30000 : 600);
    if (lockFails >= 5) $('lock-err').textContent = 'Too many tries. Wait 30 seconds.';
    return;
  }
  lockFails = 0; btn.disabled = false;
  $('lock-screen').classList.add('hidden');
  const cb = lockCb; lockCb = null;
  if (cb) cb();
}

// ---------------- WIRING ----------------
const THEME_COLORS = { bee: '#0a1634', dark: '#0f1115', light: '#eef1f7' };
function applyTheme(t) {
  if (!THEME_COLORS[t]) t = 'bee';
  document.documentElement.setAttribute('data-theme', t);
  try { localStorage.setItem('bee_theme', t); } catch { /* ignore */ }
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', THEME_COLORS[t]);
  document.querySelectorAll('.theme-opt').forEach(b => {
    const on = b.dataset.theme === t;
    b.classList.toggle('on', on);
    b.setAttribute('aria-checked', String(on));
  });
}
function openDlg(d) { d.classList.remove('closing'); if (!d.open) d.showModal(); }
function closeDlg(d) {
  if (!d || !d.open || d.classList.contains('closing')) return;
  d.classList.add('closing');
  setTimeout(() => { d.close(); d.classList.remove('closing'); }, 170);
}
// shown if icon.png is missing from the site
const BRAND_FALLBACK = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='22' fill='%230a1634'/%3E%3Cpath d='M24 30h52a6 6 0 0 1 6 6v26a6 6 0 0 1-6 6H48L34 80V68h-10a6 6 0 0 1-6-6V36a6 6 0 0 1 6-6z' fill='%23ffc933'/%3E%3C/svg%3E";

let verTaps = 0, hiddenAt = 0;
function bindUI() {
  applyTheme(localStorage.getItem('bee_theme') || 'bee');
  createBars();
  $('origin-hint').textContent = location.origin;
  if (!NATIVE && 'serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
  document.querySelectorAll('img.brand').forEach(img => {
    const fb = () => { img.src = BRAND_FALLBACK; };
    if (img.complete && img.naturalWidth === 0) fb(); else img.addEventListener('error', fb, { once: true });
  });

  // sign-in
  $('save-client-btn').addEventListener('click', saveSetup);
  $('login-btn').addEventListener('click', startLogin);

  // welcome (first run) + profile
  $('wl-go').addEventListener('click', async () => {
    if (await commitProfile($('wl-name').value, $('wl-bio').value, $('wl-status').value)) { renderMe(); ensureNotifPermission(); enterApp(); }
  });
  document.querySelectorAll('.chip').forEach(c => c.addEventListener('click', () => { const t = c.closest('.chips').dataset.target; $(t).value = c.textContent; }));
  $('me-save').addEventListener('click', async () => {
    if (await commitProfile($('me-name').value, $('me-bio').value, $('me-status').value)) {
      renderMe(); toast('Profile saved. Your people will see it.'); broadcastProfile();
    }
  });

  // navigation
  document.querySelectorAll('.nav-btn').forEach(b => b.addEventListener('click', () => { show(b.dataset.go); if (b.dataset.go === 'people') renderPeople(); else renderMe(); }));
  $('pull-btn').addEventListener('click', () => pullMessages(true));
  $('add-btn').addEventListener('click', () => { $('add-email').value = ''; $('add-nick').value = ''; openDlg($('add-dialog')); });
  $('add-go').addEventListener('click', async () => { const e = $('add-email').value, n = $('add-nick').value; closeDlg($('add-dialog')); await addPerson(e, n); });
  $('back-btn').addEventListener('click', backToPeople);
  $('chat-head').addEventListener('click', openContactInfo);
  $('instant-btn').addEventListener('click', () => state.contact && talkNow(state.contact));
  $('shield-btn').addEventListener('click', openVerify);
  $('verify-ok').addEventListener('click', markVerified);

  // composer
  const ta = $('text-input');
  ta.addEventListener('input', autosize);
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !matchMedia('(pointer:coarse)').matches) { e.preventDefault(); sendText(); }
    if ((e.ctrlKey || e.metaKey) && ['b', 'i'].includes(e.key.toLowerCase())) { e.preventDefault(); e.key.toLowerCase() === 'b' ? wrapSel('*') : wrapSel('_'); }
  });
  $('action-btn').addEventListener('click', onAction);
  $('rec-cancel').addEventListener('click', () => stopRecording(false));
  $('attach-btn').addEventListener('click', () => { if (requireInstant()) $('file-input').click(); });
  $('file-input').addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; e.target.value = ''; sendFile(f); });
  $('fmt-toggle').addEventListener('click', () => $('fmt-bar').classList.toggle('hidden'));
  $('fmt-b').addEventListener('click', () => wrapSel('*'));
  $('fmt-i').addEventListener('click', () => wrapSel('_'));
  $('fmt-s').addEventListener('click', () => wrapSel('~'));
  $('fmt-c').addEventListener('click', () => wrapSel('`'));
  $('reply-cancel').addEventListener('click', clearReply);
  updateAction();

  // bubbles
  const box = $('messages');
  box.addEventListener('click', (e) => {
    const q = e.target.closest('.quote');
    if (q) return jumpTo(q.dataset.target);
    if (Date.now() - state.menuAt < 450) return;
    const b = e.target.closest('.msg');
    if (!b || e.target.closest('.vbtn,.vtrack,video')) return;
    openMenuFor(b);
  });
  box.addEventListener('contextmenu', (e) => { const b = e.target.closest('.msg'); if (!b) return; e.preventDefault(); openMenuFor(b); });
  box.addEventListener('scroll', () => closeMenu(true), { passive: true });
  $('menu-scrim').addEventListener('click', () => closeMenu());
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });
  window.addEventListener('resize', () => closeMenu(true));

  // dialogs
  document.querySelectorAll('dialog').forEach(d => {
    d.addEventListener('click', (e) => { if (e.target === d) closeDlg(d); });
    d.addEventListener('cancel', (e) => { e.preventDefault(); closeDlg(d); });
  });
  document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => closeDlg(b.closest('dialog'))));
  $('talk-join').addEventListener('click', () => { closeDlg($('talk-dialog')); const i = state.incoming; state.incoming = null; if (i) joinTalk(i.sender, i.sig); });
  $('talk-no').addEventListener('click', () => { closeDlg($('talk-dialog')); const i = state.incoming; state.incoming = null; if (i) relaySignal(i.sender, { type: 'decline' }).catch(() => {}); });
  $('offline-msg').addEventListener('click', () => { closeDlg($('offline-dialog')); const e = state.offlineFor; if (e) openChat(e).then(() => $('text-input').focus()); });
  $('offline-retry').addEventListener('click', () => { closeDlg($('offline-dialog')); if (state.offlineFor) talkNow(state.offlineFor); });
  $('instant-start').addEventListener('click', () => { closeDlg($('instant-dialog')); if (state.contact) talkNow(state.contact); });
  $('ci-shield').addEventListener('click', () => { closeDlg($('contact-dialog')); openVerify(); });
  $('ci-nick-save').addEventListener('click', async () => {
    const c = state.contacts[state.contact];
    if (!c) return;
    c.nick = cleanStr($('ci-nick').value, 40);
    await saveContacts(); refreshChatHeader(); renderPeople(); renderAll(); closeDlg($('contact-dialog'));
  });
  $('ci-clear').addEventListener('click', async () => {
    if (!state.contact || !confirm(`Clear this chat with ${nameOf(state.contact)} on this phone?`)) return;
    await DB.clearConv(convKey(state.contact));
    delete state.lastMsg[state.contact];
    closeDlg($('contact-dialog')); renderAll(); renderPeople();
  });
  $('ci-remove').addEventListener('click', async () => {
    const e = state.contact;
    if (!e || !confirm(`Remove ${nameOf(e)} and delete this chat from this phone?`)) return;
    if (state.peerEmail === e) closePeer();
    await DB.clearConv(convKey(e));
    delete state.lastMsg[e];
    await declineContact(e);
    closeDlg($('contact-dialog'));
    backToPeople();
  });

  // me
  document.querySelectorAll('.theme-opt').forEach(b => b.addEventListener('click', () => applyTheme(b.dataset.theme)));
  $('notif-btn').addEventListener('click', async () => {
    if (NATIVE) {
      const r = await CAP().LocalNotifications.requestPermissions();
      refreshNotifLabel();
      return toast(r.display === 'granted' ? 'Notifications enabled' : 'Blocked. Enable them in Android settings.', r.display === 'granted' ? 'info' : 'error', 5000);
    }
    if (!('Notification' in window)) return toast('Notifications are not supported in this browser.', 'error');
    if (Notification.permission === 'denied') return toast('Notifications are blocked in your browser’s site settings.', 'error', 6000);
    const p = await Notification.requestPermission();
    refreshNotifLabel();
    toast(p === 'granted' ? 'Notifications enabled' : 'Notifications not enabled');
  });
  $('bg-btn').addEventListener('click', askBattery);
  $('lock-btn').addEventListener('click', togglePin);
  $('pin-save').addEventListener('click', savePin);
  $('ver-label').addEventListener('click', () => { if (++verTaps >= 7) { verTaps = 0; $('adv-btn').classList.remove('hidden'); toast('Admin options unlocked'); } });
  $('adv-btn').addEventListener('click', () => { $('adv-turn').value = localStorage.getItem('bee_turn') || ''; openDlg($('adv-dialog')); });
  $('adv-turn-save').addEventListener('click', () => {
    const v = $('adv-turn').value.trim();
    if (v) { try { if (!Array.isArray(JSON.parse(v))) throw 0; } catch { return toast('TURN must be a JSON array.', 'error'); } localStorage.setItem('bee_turn', v); }
    else localStorage.removeItem('bee_turn');
    closeDlg($('adv-dialog')); toast('Saved. Applies to the next Instant chat.');
  });
  $('adv-client').addEventListener('click', () => { closeDlg($('adv-dialog')); logout(); showSetup(); });
  $('logout-btn').addEventListener('click', logout);
  $('wipe-btn').addEventListener('click', wipeAll);

  // lock screen
  $('unlock-btn').addEventListener('click', submitLock);
  $('pin-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitLock(); });

  // Android back button
  if (NATIVE && CAP().App) {
    CAP().App.addListener('backButton', () => {
      const dlg = document.querySelector('dialog[open]');
      if (dlg) return closeDlg(dlg);
      if (state.view === 'chat') return backToPeople();
      if (state.view === 'me') return show('people');
      try { CAP().App.minimizeApp(); } catch { /* ignore */ }
    });
  }
}
window.addEventListener('online', () => { toast('Back online'); pullMessages(); flushOutbox(); });
document.addEventListener('visibilitychange', () => {
  nativeFg(!document.hidden);
  if (document.hidden) hiddenAt = Date.now();
  else {
    if (state.lock && state.myEmail !== null && Date.now() - hiddenAt > 60000) showLock(null);
    if (state.view === 'chat' && state.contact) { state.unread[state.contact] = 0; renderPeople(); }
    updateTitle();
    pullMessages();
  }
  schedulePoll();
});
window.addEventListener('load', async () => {
  bindUI();
  try { await DB.open(); }
  catch { return toast('Local storage (IndexedDB) is unavailable — private/incognito mode?', 'error', 10000); }
  const go = () => {
    if (NATIVE) { initAuth(); return; }
    let tries = 0;
    const wait = setInterval(() => {
      if (window.google && google.accounts && google.accounts.oauth2) { clearInterval(wait); initAuth(); }
      else if (++tries > 50) { clearInterval(wait); toast('Google sign-in library failed to load. Check your connection.', 'error', 8000); }
    }, 200);
  };
  state.lock = !!(await DB.get('lock'));
  if (state.lock) showLock(go); else go();
});
