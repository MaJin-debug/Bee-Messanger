'use strict';
// ============================================================
// 🐝 BEE Messenger v2 — serverless E2E-encrypted chat over Gmail + WebRTC
// ============================================================

const SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/userinfo.email'
];
const GM = 'https://gmail.googleapis.com/gmail/v1/users/me';
const TAG_SIG = '[BEE:v2:sig]';
const TAG_ENC = '[BEE:v2:enc]';
const MAX_RELAY_MB = 5;      // Gmail relay (base64 overhead + 25MB mail limit)
const MAX_P2P_MB = 25;       // direct WebRTC transfer
const POLL_VISIBLE = 15000;
const POLL_HIDDEN = 60000;
const SIGNAL_TTL = 10 * 60 * 1000;   // ignore offers/answers older than this
const CHUNK = 16 * 1024;
const EMAIL_RE = /^[^\s@<>,;"']+@[^\s@<>,;"']+\.[^\s@<>,;"']+$/;
const SAFE_MEDIA = /^(image\/(png|jpe?g|gif|webp|avif|bmp)|video\/(mp4|webm|quicktime|ogg)|audio\/(webm|ogg|mp4|mpeg|wav|aac|x-m4a))$/i;
const ECDH = { name: 'ECDH', namedCurve: 'P-256' };

const $ = (id) => document.getElementById(id);
const utf8 = new TextEncoder();
const dec = new TextDecoder();

// ---------------- STATE ----------------
const state = {
  token: null, tokenExp: 0, expired: false, pending: null,
  myEmail: null, keyPair: null, myPubB64: null,
  contacts: {},            // email -> { pub, verified }
  contact: null,
  keyCache: {},            // email -> { pub, key }
  peer: null, peerConnected: false, rx: null,
  processed: new Set(),
  pollTimer: null, polling: false, pulling: false,
  recorder: null, recTimer: null,
  unread: 0, urls: [], renderSeq: 0,
  sendChain: Promise.resolve()
};
let tokenClient = null;

// ---------------- UI HELPERS ----------------
function toast(msg, type = 'info', ms = 4000) {
  const d = document.createElement('div');
  d.className = 'toast ' + type;
  d.textContent = msg;
  $('toasts').appendChild(d);
  setTimeout(() => d.remove(), ms);
  if (type === 'error') console.error(msg);
}
function showBanner(text, btnText, fn) {
  $('banner-text').textContent = text;
  const b = $('banner-btn');
  b.textContent = btnText;
  b.onclick = fn;
  $('banner').classList.remove('hidden');
}
function hideBanner() { $('banner').classList.add('hidden'); }
function setPeerStatus(s) {
  const el = $('peer-status');
  const c = state.contact && state.contacts[state.contact];
  if (s === 'online') { el.textContent = '● P2P connected (direct, fast)'; el.className = 'status online'; }
  else if (s === 'connecting') { el.textContent = '◌ Connecting…'; el.className = 'status connecting'; }
  else {
    el.textContent = c ? '● Offline — messages go via encrypted Gmail relay' : '● No keys yet — tap Connect and wait for your contact';
    el.className = 'status offline';
  }
}
function fmtSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}
function cleanName(n) {
  return String(n || 'file').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 100) || 'file';
}
function safeMime(m) { return SAFE_MEDIA.test(m || '') ? m : 'application/octet-stream'; }
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join(''));
const convKey = (contact) => `${state.myEmail}|${contact}`;
const K = (n) => `${state.myEmail}:${n}`;

// ---------------- BASE64 ----------------
function toB64(buf) {
  const b = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(s);
}
function fromB64(s) {
  const bin = atob(s);
  const b = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
  return b;
}
const b64url = (bytes) => toB64(bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return fromB64(s);
}
const wrap76 = (s) => (s.match(/.{1,76}/g) || ['']).join('\r\n');

// ---------------- LOCAL DB (IndexedDB) ----------------
const DB = {
  db: null,
  open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('bee', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('kv');
        const m = d.createObjectStore('messages', { keyPath: 'id' });
        m.createIndex('conv', 'conv');
      };
      r.onsuccess = () => { this.db = r.result; res(); };
      r.onerror = () => rej(r.error);
    });
  },
  tx(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = this.db.transaction(store, mode);
      const rq = fn(t.objectStore(store));
      t.oncomplete = () => res(rq && rq.result);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  },
  get(k) { return this.tx('kv', 'readonly', s => s.get(k)); },
  set(k, v) { return this.tx('kv', 'readwrite', s => s.put(v, k)); },
  putMsg(m) { return this.tx('messages', 'readwrite', s => s.put(m)); },
  getMsg(id) { return this.tx('messages', 'readonly', s => s.get(id)); },
  msgsFor(conv) { return this.tx('messages', 'readonly', s => s.index('conv').getAll(conv)); },
  clearConv(conv) {
    return this.tx('messages', 'readwrite', s => {
      const r = s.index('conv').openKeyCursor(IDBKeyRange.only(conv));
      r.onsuccess = () => { const c = r.result; if (c) { s.delete(c.primaryKey); c.continue(); } };
      return r;
    });
  }
};

// ---------------- CRYPTO ----------------
async function createKeys() {
  // private key is NON-extractable: JS (or an XSS) can use it but never read it
  const kp = await crypto.subtle.generateKey(ECDH, false, ['deriveBits']);
  await DB.set(K('keypair'), kp);
  return kp;
}
async function deriveKeyFor(peerPubB64) {
  const peerPub = await crypto.subtle.importKey('raw', fromB64(peerPubB64), ECDH, true, []);
  const bits = await crypto.subtle.deriveBits({ name: 'ECDH', public: peerPub }, state.keyPair.privateKey, 256);
  const hk = await crypto.subtle.importKey('raw', bits, 'HKDF', false, ['deriveKey']);
  const [a, b] = [state.myPubB64, peerPubB64].sort();
  const salt = await crypto.subtle.digest('SHA-256', utf8.encode(a + '|' + b));
  return crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info: utf8.encode('BEE-Messenger-v2') },
    hk, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']
  );
}
async function getKey(email) {
  const c = state.contacts[email];
  if (!c) return null;
  const hit = state.keyCache[email];
  if (hit && hit.pub === c.pub) return hit.key;
  const key = await deriveKeyFor(c.pub);
  state.keyCache[email] = { pub: c.pub, key };
  return key;
}
async function safetyNumber(peerPubB64) {
  const [a, b] = [state.myPubB64, peerPubB64].sort();
  const h = new Uint8Array(await crypto.subtle.digest('SHA-256', utf8.encode(a + '|' + b)));
  const digits = Array.from(h.slice(0, 15)).map(x => String(x).padStart(3, '0')).join('');
  return digits.match(/.{1,5}/g).join(' ');
}
// AAD binds ciphertext to sender -> recipient so it can't be re-targeted
const aad = (from, to) => utf8.encode(`${from.toLowerCase()}>${to.toLowerCase()}`);

// ---------------- GMAIL ----------------
function authError() { const e = new Error('Session expired'); e.code = 'AUTH'; return e; }
function expire() {
  state.expired = true;
  showBanner('Session expired — sign in again to keep receiving messages.', 'Sign in', startLogin);
  return authError();
}
let refreshing = null;
function refreshToken() {
  if (refreshing) return refreshing;
  refreshing = new Promise((resolve, reject) => {
    if (!tokenClient) return reject(new Error('no auth'));
    state.pending = { resolve, reject };
    const t = setTimeout(() => reject(new Error('timeout')), 20000);
    const done = () => clearTimeout(t);
    state.pending.resolve = (v) => { done(); resolve(v); };
    state.pending.reject = (e) => { done(); reject(e); };
    try { tokenClient.requestAccessToken({ prompt: '', login_hint: state.myEmail || undefined }); }
    catch (e) { done(); reject(e); }
  }).finally(() => { refreshing = null; state.pending = null; });
  return refreshing;
}
async function gfetch(url, opts = {}, retry = true) {
  if (state.expired) throw authError();
  if (Date.now() > state.tokenExp - 60000) {
    try { await refreshToken(); } catch { throw expire(); }
  }
  const res = await fetch(url, { ...opts, headers: { ...(opts.headers || {}), Authorization: `Bearer ${state.token}` } });
  if (res.status === 401 && retry) {
    try { await refreshToken(); } catch { throw expire(); }
    return gfetch(url, opts, false);
  }
  if (!res.ok) {
    const e = new Error(`Gmail ${res.status}: ${(await res.text()).slice(0, 160)}`);
    e.status = res.status;
    throw e;
  }
  return res;
}
function buildRaw(to, tag, bytes) {
  if (!EMAIL_RE.test(to)) throw new Error('Bad recipient');
  const body = tag + '\r\n' + wrap76(toB64(bytes));
  const msg = [
    `To: ${to}`, 'Subject: BEE Messenger',
    'Content-Type: text/plain; charset="UTF-8"', 'Content-Transfer-Encoding: 7bit',
    'MIME-Version: 1.0', '', body
  ].join('\r\n');
  return b64url(utf8.encode(msg));
}
async function gmailSendRaw(raw) {
  await gfetch(`${GM}/messages/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ raw })
  });
}
const relaySignal = (to, obj) => gmailSendRaw(buildRaw(to, TAG_SIG, utf8.encode(JSON.stringify(obj))));

async function relaySend(to, m, blob) {
  const key = await getKey(to);
  if (!key) throw new Error('No keys yet — tap Connect and wait for your contact to be online.');
  const header = utf8.encode(JSON.stringify({
    mid: m.mid, ts: m.ts, type: m.kind === 'file' ? 'file' : 'text',
    text: m.text, mime: m.mime, name: m.name
  }));
  const data = blob ? new Uint8Array(await blob.arrayBuffer()) : new Uint8Array(0);
  const pt = new Uint8Array(4 + header.length + data.length);
  new DataView(pt.buffer).setUint32(0, header.length);
  pt.set(header, 4);
  pt.set(data, 4 + header.length);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: aad(state.myEmail, to) }, key, pt));
  const out = new Uint8Array(12 + ct.length);
  out.set(iv, 0); out.set(ct, 12);
  await gmailSendRaw(buildRaw(to, TAG_ENC, out));
}

async function extractBody(id, p) {
  if (p.parts) {
    for (const c of p.parts) { const b = await extractBody(id, c); if (b) return b; }
    return null;
  }
  if (p.body && p.body.data) return dec.decode(b64urlToBytes(p.body.data));
  if (p.body && p.body.attachmentId) {   // big bodies come as attachments
    const a = await (await gfetch(`${GM}/messages/${id}/attachments/${p.body.attachmentId}`)).json();
    return dec.decode(b64urlToBytes(a.data));
  }
  return null;
}
function parseBee(body) {
  if (!body) return null;
  const m = body.match(/\[BEE:v2:(sig|enc)\]\s*([A-Za-z0-9+/=\s]+)/);
  if (!m) return null;
  try {
    const bytes = fromB64(m[2].replace(/\s+/g, ''));
    return m[1] === 'sig'
      ? { kind: 'sig', json: JSON.parse(dec.decode(bytes)) }
      : { kind: 'enc', bytes };
  } catch { return null; }
}
const hdr = (gm, name) => (gm.payload.headers || []).find(h => h.name.toLowerCase() === name.toLowerCase())?.value || '';
function extractEmail(v) {
  const m = v.match(/<(.+?)>/);
  return (m ? m[1] : v).trim().toLowerCase();
}

// ---------------- WEBRTC ----------------
function iceServers() {
  const list = [{ urls: 'stun:stun.l.google.com:19302' }];
  try {
    const extra = JSON.parse(localStorage.getItem('bee_turn') || '[]');
    if (Array.isArray(extra)) list.push(...extra.filter(s => s && s.urls));
  } catch { /* ignore */ }
  return list;
}
class Peer {
  constructor(cb) {
    this.cb = cb; this.dead = false; this.ch = null;
    this.pc = new RTCPeerConnection({ iceServers: iceServers() });
    this.pc.ondatachannel = (e) => this._setup(e.channel);
    this.pc.onconnectionstatechange = () => {
      if (this.dead) return;
      const s = this.pc.connectionState;
      if (s === 'connected') cb.up();
      if (['disconnected', 'failed', 'closed'].includes(s)) cb.down(s);
    };
  }
  _setup(ch) {
    this.ch = ch;
    ch.binaryType = 'arraybuffer';
    ch.bufferedAmountLowThreshold = 256 * 1024;
    ch.onmessage = (e) => { if (!this.dead) this.cb.msg(e.data); };
    ch.onopen = () => { if (!this.dead) this.cb.up(); };
    ch.onclose = () => { if (!this.dead) this.cb.down('closed'); };
  }
  _ice() {
    const pc = this.pc;
    if (pc.iceGatheringState === 'complete') return Promise.resolve();
    return new Promise(res => {
      const done = () => { pc.removeEventListener('icegatheringstatechange', chk); clearTimeout(t); res(); };
      const chk = () => { if (pc.iceGatheringState === 'complete') done(); };
      const t = setTimeout(done, 5000);
      pc.addEventListener('icegatheringstatechange', chk);
    });
  }
  async createOffer() {
    this._setup(this.pc.createDataChannel('chat'));
    await this.pc.setLocalDescription(await this.pc.createOffer());
    await this._ice();
    return this.pc.localDescription;
  }
  async acceptOffer(offer) {
    await this.pc.setRemoteDescription(offer);
    await this.pc.setLocalDescription(await this.pc.createAnswer());
    await this._ice();
    return this.pc.localDescription;
  }
  acceptAnswer(a) { return this.pc.setRemoteDescription(a); }
  get open() { return this.ch && this.ch.readyState === 'open'; }
  async _wait() {
    while (this.ch.bufferedAmount > 1024 * 1024) {
      await new Promise(r => {
        this.ch.onbufferedamountlow = () => { this.ch.onbufferedamountlow = null; r(); };
        setTimeout(r, 500);
      });
      if (!this.open) throw new Error('P2P closed');
    }
  }
  async send(data) { await this._wait(); this.ch.send(data); }
  close() { this.dead = true; try { if (this.ch) this.ch.close(); this.pc.close(); } catch { /* ignore */ } }
}
function newPeer() {
  const p = new Peer({
    up: () => { if (state.peer === p) onPeerUp(); },
    down: () => { if (state.peer === p) onPeerDown(); },
    msg: (d) => { if (state.peer === p) onPeerData(d); }
  });
  return p;
}
function closePeer() {
  if (state.peer) { state.peer.close(); state.peer = null; }
  state.peerConnected = false;
  state.rx = null;
  setPeerStatus('offline');
}
function onPeerUp() {
  if (state.peerConnected) return;
  state.peerConnected = true;
  setPeerStatus('online');
  toast('✅ Direct P2P channel open');
}
function onPeerDown() {
  if (!state.peerConnected && !state.peer) return;
  state.peerConnected = false;
  state.rx = null;
  setPeerStatus('offline');
}

// P2P wire format: JSON string control messages + raw binary chunks for files
function onPeerData(d) {
  try {
    if (typeof d === 'string') {
      const o = JSON.parse(d);
      if (o.t === 'text') {
        ingest(state.contact, { mid: o.mid, ts: o.ts, type: 'text', text: o.text }, null, 'p2p');
      } else if (o.t === 'file') {
        const size = Number(o.size);
        if (!(size >= 0) || size > MAX_P2P_MB * 1048576) { state.rx = null; toast('Incoming file rejected (too large)', 'error'); return; }
        state.rx = { meta: o, parts: [], got: 0, size };
        if (size === 0) finishRx();
      }
    } else if (state.rx) {
      state.rx.parts.push(d);
      state.rx.got += d.byteLength;
      if (state.rx.got >= state.rx.size) finishRx();
    }
  } catch { toast('Bad P2P message', 'error'); }
}
function finishRx() {
  const { meta, parts } = state.rx;
  state.rx = null;
  ingest(state.contact, { mid: meta.mid, ts: meta.ts, type: 'file', mime: meta.mime, name: meta.name }, new Blob(parts), 'p2p');
}
async function p2pSend(m, blob) {
  const p = state.peer;
  if (!p || !p.open) throw new Error('P2P closed');
  if (m.kind === 'text') {
    await p.send(JSON.stringify({ t: 'text', mid: m.mid, ts: m.ts, text: m.text }));
  } else {
    await p.send(JSON.stringify({ t: 'file', mid: m.mid, ts: m.ts, mime: m.mime, name: m.name, size: blob.size }));
    for (let o = 0; o < blob.size; o += CHUNK) await p.send(await blob.slice(o, o + CHUNK).arrayBuffer());
  }
}

// ---------------- AUTH ----------------
function showSetup() {
  $('setup-area').classList.remove('hidden');
  $('login-btn').classList.add('hidden');
  $('edit-setup-btn').classList.add('hidden');
  $('client-id-input').value = localStorage.getItem('bee_clientId') || '';
  $('turn-input').value = localStorage.getItem('bee_turn') || '';
}
function saveSetup() {
  const val = $('client-id-input').value.trim();
  if (!val.endsWith('.apps.googleusercontent.com')) return toast('Invalid Client ID format.', 'error');
  const turn = $('turn-input').value.trim();
  if (turn) {
    try { if (!Array.isArray(JSON.parse(turn))) throw 0; }
    catch { return toast('TURN must be a JSON array.', 'error'); }
  }
  localStorage.setItem('bee_clientId', val);
  if (turn) localStorage.setItem('bee_turn', turn); else localStorage.removeItem('bee_turn');
  $('setup-area').classList.add('hidden');
  initAuth();
}
function initAuth() {
  const cid = localStorage.getItem('bee_clientId');
  if (!cid) return showSetup();
  tokenClient = google.accounts.oauth2.initTokenClient({
    client_id: cid,
    scope: SCOPES.join(' '),
    callback: onToken,
    error_callback: (e) => {
      if (state.pending) state.pending.reject(e);
      else if (e.type !== 'popup_closed') toast('Sign-in failed: ' + (e.type || 'unknown'), 'error');
    }
  });
  $('edit-setup-btn').classList.remove('hidden');
  try {   // restore a still-valid token for this browser tab session
    const s = JSON.parse(sessionStorage.getItem('bee_tok') || 'null');
    if (s && s.e > Date.now() + 60000) { state.token = s.t; state.tokenExp = s.e; onLoggedIn(); return; }
  } catch { /* ignore */ }
  $('login-btn').classList.remove('hidden');
}
function startLogin() {
  if (!tokenClient) return initAuth();
  tokenClient.requestAccessToken(state.myEmail ? { prompt: '', login_hint: state.myEmail } : {});
}
function onToken(resp) {
  if (resp.error) {
    if (state.pending) state.pending.reject(new Error(resp.error));
    return toast('Auth error: ' + resp.error, 'error');
  }
  if (!google.accounts.oauth2.hasGrantedAllScopes(resp, ...SCOPES)) {
    return toast('Please tick ALL permission boxes on the Google consent screen.', 'error', 6000);
  }
  state.token = resp.access_token;
  state.tokenExp = Date.now() + Number(resp.expires_in || 3600) * 1000;
  try { sessionStorage.setItem('bee_tok', JSON.stringify({ t: state.token, e: state.tokenExp })); } catch { /* ignore */ }
  state.expired = false;
  hideBanner();
  if (state.pending) state.pending.resolve();
  if (!state.myEmail) onLoggedIn();
  else { pullMessages(); }
}
async function onLoggedIn() {
  if (state.myEmail) return;
  try {
    const info = await (await gfetch('https://www.googleapis.com/oauth2/v3/userinfo')).json();
    state.myEmail = String(info.email).toLowerCase();
    state.keyPair = (await DB.get(K('keypair'))) || await createKeys();
    state.myPubB64 = toB64(await crypto.subtle.exportKey('raw', state.keyPair.publicKey));
    state.contacts = (await DB.get(K('contacts'))) || {};
    state.processed = new Set((await DB.get(K('processed'))) || []);
    state.contact = (await DB.get(K('contact'))) || null;

    $('login-screen').classList.add('hidden');
    $('chat-screen').classList.remove('hidden');
    $('my-email').textContent = state.myEmail;
    $('contact-input').value = state.contact || '';
    refreshContactUI();
    await renderAll();
    startPolling();
    pullMessages();
  } catch (e) {
    state.myEmail = null; state.token = null;
    sessionStorage.removeItem('bee_tok');
    $('login-btn').classList.remove('hidden');
    toast('Login failed: ' + e.message, 'error');
  }
}
function logout() {
  try { if (state.token) google.accounts.oauth2.revoke(state.token); } catch { /* ignore */ }
  sessionStorage.removeItem('bee_tok');
  stopPolling();
  closePeer();
  Object.assign(state, { token: null, myEmail: null, contact: null, keyPair: null, contacts: {}, keyCache: {}, expired: false });
  hideBanner();
  $('settings-dialog').close();
  $('chat-screen').classList.add('hidden');
  $('login-screen').classList.remove('hidden');
  $('login-btn').classList.remove('hidden');
}
async function wipeAll() {
  if (!confirm('Delete ALL messages, contacts and your encryption keys from this device?\nYour contacts will see a "key changed" warning if you chat again.')) return;
  try { google.accounts.oauth2.revoke(state.token); } catch { /* ignore */ }
  if (DB.db) DB.db.close();
  indexedDB.deleteDatabase('bee');
  Object.keys(localStorage).filter(k => k.startsWith('bee_')).forEach(k => localStorage.removeItem(k));
  sessionStorage.clear();
  location.reload();
}

// ---------------- CONTACTS ----------------
async function saveContacts() { await DB.set(K('contacts'), state.contacts); }
async function setContact(email) {
  state.contact = email;
  await DB.set(K('contact'), email);
  $('contact-input').value = email;
  refreshContactUI();
  await renderAll();
}
function refreshContactUI() {
  const dl = $('contact-list');
  dl.replaceChildren(...Object.keys(state.contacts).map(e => { const o = document.createElement('option'); o.value = e; return o; }));
  const c = state.contact && state.contacts[state.contact];
  const vb = $('verify-btn');
  vb.classList.toggle('hidden', !c);
  if (c) {
    vb.textContent = c.verified ? '🔒' : '🔓';
    vb.title = c.verified ? 'Verified — tap to view safety number' : 'Not verified — tap to verify';
  }
  if (!state.peerConnected) setPeerStatus(state.peer ? 'connecting' : 'offline');
}
async function acceptKey(email, pub) {
  try { await crypto.subtle.importKey('raw', fromB64(pub), ECDH, true, []); }
  catch { toast('Invalid key received from ' + email, 'error'); return false; }
  const c = state.contacts[email];
  if (c && c.pub !== pub) {
    if (!confirm(`⚠️ The security key of ${email} has CHANGED.\n\nThis happens if they reinstalled or cleared data — or if someone is intercepting. Compare the new safety number with them before trusting.\n\nAccept the new key?`)) return false;
    state.contacts[email] = { pub, verified: false };
  } else if (!c) {
    state.contacts[email] = { pub, verified: false };
  }
  await saveContacts();
  delete state.keyCache[email];
  refreshContactUI();
  return true;
}
async function openVerify() {
  const c = state.contact && state.contacts[state.contact];
  if (!c) return;
  $('verify-who').textContent = `Safety number for you and ${state.contact}`;
  $('safety').textContent = await safetyNumber(c.pub);
  $('verify-ok').classList.toggle('hidden', !!c.verified);
  $('verify-dialog').showModal();
}
async function markVerified() {
  const c = state.contacts[state.contact];
  if (c) { c.verified = true; await saveContacts(); refreshContactUI(); toast('Contact marked as verified 🔒'); }
  $('verify-dialog').close();
}

// ---------------- CONNECT (signaling over Gmail) ----------------
async function connectContact() {
  const email = $('contact-input').value.trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return toast('Enter a valid email.', 'error');
  if (email === state.myEmail) return toast("You can't connect to yourself.", 'error');
  closePeer();
  if (email !== state.contact) await setContact(email);
  const peer = newPeer();
  state.peer = peer;
  setPeerStatus('connecting');
  try {
    const offer = await peer.createOffer();
    if (state.peer !== peer) return;
    await relaySignal(email, { type: 'offer', sdp: offer.sdp, pubkey: state.myPubB64 });
    toast('Request sent to ' + email + ' — waiting for them to open BEE…');
    setTimeout(() => {
      if (state.peer === peer && !state.peerConnected) {
        setPeerStatus('offline');
        toast('No answer yet. Your contact must have BEE open (checks every ~15s).', 'info', 6000);
      }
    }, 90000);
  } catch (e) {
    if (state.peer === peer) { closePeer(); }
    if (e.code !== 'AUTH') toast('Connect failed: ' + e.message, 'error');
  }
}
async function handleSignal(sender, sig, age) {
  if (!sig || typeof sig.sdp !== 'string' || typeof sig.pubkey !== 'string') return true;
  if (age > SIGNAL_TTL) return true;   // stale handshake
  if (sig.type === 'offer') {
    // both sides offered at once: the lexicographically smaller email keeps its offer
    if (sender === state.contact && state.peer && state.peer.pc.signalingState === 'have-local-offer' && state.myEmail < sender) return true;
    if (sender !== state.contact) {
      if (!confirm(`${sender} wants to start a secure chat with you.\n\nSwitch to this contact?`)) return true;
      closePeer();
      await setContact(sender);
    }
    if (!(await acceptKey(sender, sig.pubkey))) return true;
    closePeer();
    const peer = newPeer();
    state.peer = peer;
    setPeerStatus('connecting');
    const answer = await peer.acceptOffer({ type: 'offer', sdp: sig.sdp });
    await relaySignal(sender, { type: 'answer', sdp: answer.sdp, pubkey: state.myPubB64 });
    toast('Answer sent — connecting…');
    return true;
  }
  if (sig.type === 'answer') {
    if (sender !== state.contact || !state.peer || state.peer.pc.signalingState !== 'have-local-offer') return true;
    if (!(await acceptKey(sender, sig.pubkey))) return true;
    await state.peer.acceptAnswer({ type: 'answer', sdp: sig.sdp });
    return true;
  }
  return true;
}
async function handleEncrypted(sender, bytes) {
  if (!state.contacts[sender] || bytes.length < 12 + 16 + 4) return true;
  const key = await getKey(sender);
  let pt;
  try {
    pt = new Uint8Array(await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: bytes.slice(0, 12), additionalData: aad(sender, state.myEmail) }, key, bytes.slice(12)));
  } catch {
    toast(`Could not decrypt a message from ${sender} (keys changed?)`, 'error');
    return true;
  }
  const hl = new DataView(pt.buffer).getUint32(0);
  if (hl > 8192 || hl > pt.length - 4) return true;
  const h = JSON.parse(dec.decode(pt.subarray(4, 4 + hl)));
  await ingest(sender, h, pt.subarray(4 + hl), 'relay');
  return true;
}

// ---------------- RECEIVE / POLL ----------------
async function listUnprocessed() {
  const q = encodeURIComponent('subject:"BEE Messenger" -from:me');
  const out = [];
  let page = null;
  for (let i = 0; i < 5; i++) {
    const r = await (await gfetch(`${GM}/messages?q=${q}&maxResults=50` + (page ? `&pageToken=${page}` : ''))).json();
    const fresh = (r.messages || []).map(m => m.id).filter(id => !state.processed.has(id));
    out.push(...fresh);
    if (!fresh.length || !r.nextPageToken) break;
    page = r.nextPageToken;
  }
  return out;
}
async function processMessage(meta) {
  const sender = extractEmail(hdr(meta, 'From'));
  if (!sender || sender === state.myEmail) return;
  const full = await (await gfetch(`${GM}/messages/${meta.id}?format=full`)).json();
  const parsed = parseBee(await extractBody(meta.id, full.payload));
  if (!parsed) return;
  if (parsed.kind === 'sig') await handleSignal(sender, parsed.json, Date.now() - Number(meta.internalDate));
  else await handleEncrypted(sender, parsed.bytes);
}
async function pullMessages(manual = false) {
  if (!state.token || !state.myEmail || state.pulling || state.expired) return;
  state.pulling = true;
  try {
    const ids = await listUnprocessed();
    const metas = [];
    for (const id of ids) {
      metas.push(await (await gfetch(`${GM}/messages/${id}?format=metadata&metadataHeaders=From`)).json());
    }
    metas.sort((a, b) => Number(a.internalDate) - Number(b.internalDate));   // oldest first
    for (const m of metas) {
      try { await processMessage(m); }
      catch (e) {
        // transient problems: stop and retry next poll; permanent ones: skip this message
        if (e instanceof TypeError || e.code === 'AUTH' || e.status >= 500 || e.status === 429) throw e;
        console.error('Skipping bad message', m.id, e);
      }
      markProcessed(m.id);
    }
    if (manual && !metas.length) toast('No new messages');
  } catch (e) {
    if (e.code !== 'AUTH' && (manual || navigator.onLine)) toast('Pull error: ' + e.message, 'error');
  } finally { state.pulling = false; }
}
function markProcessed(id) {
  state.processed.add(id);
  const arr = Array.from(state.processed).slice(-1000);
  state.processed = new Set(arr);
  DB.set(K('processed'), arr).catch(() => {});
}
function startPolling() { state.polling = true; schedulePoll(); }
function stopPolling() { state.polling = false; clearTimeout(state.pollTimer); }
function schedulePoll() {
  clearTimeout(state.pollTimer);
  if (!state.polling) return;
  state.pollTimer = setTimeout(async () => { await pullMessages(); schedulePoll(); },
    document.hidden ? POLL_HIDDEN : POLL_VISIBLE);
}

// ---------------- MESSAGES ----------------
async function ingest(from, h, data, via) {
  if (!from) return;
  const conv = convKey(from);
  const mid = String(h.mid || '').slice(0, 64);
  if (!mid) return;
  const id = `${conv}:${mid}`;
  if (await DB.getMsg(id)) return;   // de-duplicate (replays, relay + P2P)
  const ts = Math.min(Number(h.ts) || Date.now(), Date.now() + 60000);
  const m = { id, mid, conv, side: 'them', ts, via, kind: h.type === 'file' ? 'file' : 'text' };
  if (m.kind === 'text') m.text = String(h.text ?? '').slice(0, 20000);
  else {
    m.name = cleanName(h.name);
    m.mime = safeMime(h.mime);
    m.blob = new Blob([data], { type: m.mime });
    m.size = m.blob.size;
  }
  await DB.putMsg(m);
  if (from === state.contact) renderMessage(m);
  notifyIncoming(from, m);
}
function notifyIncoming(from, m) {
  if (document.hidden || from !== state.contact) {
    state.unread++;
    updateTitle();
    if ('Notification' in window && Notification.permission === 'granted') {
      try { new Notification('🐝 ' + from, { body: m.kind === 'text' ? m.text.slice(0, 80) : '📎 ' + m.name, tag: 'bee-' + from }); } catch { /* ignore */ }
    }
  }
  if (from !== state.contact) toast('New message from ' + from);
}
function updateTitle() { document.title = (state.unread ? `(${state.unread}) ` : '') + '🐝 BEE Messenger'; }

function withLock(fn) {
  const p = state.sendChain.then(fn, fn);
  state.sendChain = p.catch(() => {});
  return p;
}
function requireContact() {
  if (!state.contact) { toast('Enter a contact email and tap Connect first.', 'error'); $('contact-input').focus(); return false; }
  return true;
}
async function deliver(m, blob) {
  if (state.peerConnected && state.peer && state.peer.open) {
    try { await p2pSend(m, blob); return 'p2p'; } catch { /* fall back to relay */ }
  }
  if (blob && blob.size > MAX_RELAY_MB * 1048576) {
    throw new Error(`Too big for Gmail relay (max ${MAX_RELAY_MB} MB). Connect P2P to send up to ${MAX_P2P_MB} MB.`);
  }
  await relaySend(state.contact, m, blob);
  return 'relay';
}
function baseMsg() {
  const conv = convKey(state.contact);
  const mid = uuid();
  return { id: `${conv}:${mid}`, mid, conv, side: 'me', ts: Date.now() };
}
async function sendText() {
  const input = $('text-input');
  const text = input.value.trim();
  if (!text || !requireContact()) return;
  input.value = '';
  const m = { ...baseMsg(), kind: 'text', text };
  try {
    m.via = await withLock(() => deliver(m, null));
    await DB.putMsg(m);
    renderMessage(m);
  } catch (e) {
    input.value = text;   // don't lose the draft
    if (e.code !== 'AUTH') toast('Send failed: ' + e.message, 'error', 6000);
  }
}
async function sendFile(file) {
  if (!file || !requireContact()) return;
  if (file.size > MAX_P2P_MB * 1048576) return toast(`File too large (max ${MAX_P2P_MB} MB).`, 'error');
  const mime = safeMime(file.type);
  const blob = new Blob([file], { type: mime });
  const m = { ...baseMsg(), kind: 'file', name: cleanName(file.name), mime, size: blob.size, blob };
  toast('Sending ' + m.name + ' (' + fmtSize(m.size) + ')…');
  try {
    m.via = await withLock(() => deliver(m, blob));
    await DB.putMsg(m);
    renderMessage(m);
  } catch (e) {
    if (e.code !== 'AUTH') toast('Send failed: ' + e.message, 'error', 6000);
  }
}

// ---------------- RENDERING ----------------
function revokeUrls() { state.urls.forEach(u => URL.revokeObjectURL(u)); state.urls = []; }
function emptyEl(icon, text) {
  const d = document.createElement('div');
  d.className = 'empty';
  const b = document.createElement('div'); b.className = 'big'; b.textContent = icon;
  const p = document.createElement('div'); p.textContent = text;
  d.append(b, p);
  return d;
}
async function renderAll() {
  const seq = ++state.renderSeq;
  const box = $('messages');
  revokeUrls();
  box.replaceChildren();
  if (!state.contact) { box.append(emptyEl('👋', 'Enter your contact’s Gmail above and tap Connect.')); return; }
  const msgs = (await DB.msgsFor(convKey(state.contact))).sort((a, b) => a.ts - b.ts);
  if (seq !== state.renderSeq) return;
  if (!msgs.length) { box.append(emptyEl('🔒', 'No messages yet. Everything here is end-to-end encrypted.')); return; }
  msgs.forEach(m => renderMessage(m, false));
  box.scrollTop = box.scrollHeight;
}
function fmtTime(ts) {
  const d = new Date(ts);
  const t = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return d.toDateString() === new Date().toDateString() ? t : d.toLocaleDateString([], { day: 'numeric', month: 'short' }) + ' ' + t;
}
function renderMessage(m, scroll = true) {
  const box = $('messages');
  const e = box.querySelector('.empty');
  if (e) e.remove();
  const near = box.scrollHeight - box.scrollTop - box.clientHeight < 120;
  const div = document.createElement('div');
  div.className = 'msg ' + m.side;
  if (m.kind === 'text') {
    div.append(document.createTextNode(m.text));
  } else if (m.blob) {
    const url = URL.createObjectURL(m.blob);
    state.urls.push(url);
    if (/^image\//.test(m.mime)) { const i = document.createElement('img'); i.src = url; i.alt = m.name; div.append(i); }
    else if (/^video\//.test(m.mime)) { const v = document.createElement('video'); v.src = url; v.controls = true; v.preload = 'metadata'; v.playsInline = true; div.append(v); }
    else if (/^audio\//.test(m.mime)) { const a = document.createElement('audio'); a.src = url; a.controls = true; div.append(a); }
    else { const a = document.createElement('a'); a.href = url; a.download = m.name; a.textContent = `📎 ${m.name} (${fmtSize(m.size || 0)})`; div.append(a); }
  }
  const meta = document.createElement('div');
  meta.className = 'meta';
  meta.textContent = `${fmtTime(m.ts)} ${m.via === 'p2p' ? '⚡' : '✉️'}`;
  div.append(meta);
  box.append(div);
  if (scroll && (near || m.side === 'me')) box.scrollTop = box.scrollHeight;
}

// ---------------- VOICE NOTES ----------------
async function toggleRecording() {
  const btn = $('rec-btn');
  if (state.recorder && state.recorder.state === 'recording') { state.recorder.stop(); return; }
  if (!requireContact()) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mt = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm', 'audio/ogg'].find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t)) || '';
    const rec = new MediaRecorder(stream, mt ? { mimeType: mt } : {});
    const chunks = [];
    rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
    rec.onstop = async () => {
      clearTimeout(state.recTimer);
      stream.getTracks().forEach(t => t.stop());
      btn.classList.remove('recording'); btn.textContent = '🎤';
      const type = (rec.mimeType || mt || 'audio/webm').split(';')[0];
      const ext = type.includes('mp4') ? 'm4a' : type.includes('ogg') ? 'ogg' : 'webm';
      await sendFile(new File([new Blob(chunks, { type })], `voice-note.${ext}`, { type }));
    };
    state.recorder = rec;
    rec.start();
    btn.classList.add('recording'); btn.textContent = '⏹';
    state.recTimer = setTimeout(() => { if (rec.state === 'recording') rec.stop(); }, 120000);
  } catch (e) { toast('Microphone error: ' + e.message, 'error'); }
}

// ---------------- WIRING ----------------
function bindUI() {
  $('origin-hint').textContent = location.origin;
  $('save-client-btn').addEventListener('click', saveSetup);
  $('login-btn').addEventListener('click', startLogin);
  $('edit-setup-btn').addEventListener('click', showSetup);
  $('logout-btn').addEventListener('click', logout);
  $('connect-btn').addEventListener('click', connectContact);
  $('contact-input').addEventListener('keydown', e => { if (e.key === 'Enter') connectContact(); });
  $('pull-btn').addEventListener('click', () => pullMessages(true));
  $('send-btn').addEventListener('click', sendText);
  $('rec-btn').addEventListener('click', toggleRecording);
  $('verify-btn').addEventListener('click', openVerify);
  $('verify-ok').addEventListener('click', markVerified);
  $('verify-close').addEventListener('click', () => $('verify-dialog').close());
  $('settings-btn').addEventListener('click', () => $('settings-dialog').showModal());
  $('settings-close').addEventListener('click', () => $('settings-dialog').close());
  $('file-input').addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; e.target.value = ''; sendFile(f); });
  $('text-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendText(); }
  });
  $('notif-btn').addEventListener('click', async () => {
    if (!('Notification' in window)) return toast('Notifications not supported here.', 'error');
    const p = await Notification.requestPermission();
    toast(p === 'granted' ? 'Notifications enabled' : 'Notifications blocked');
  });
  $('clear-chat-btn').addEventListener('click', async () => {
    if (!state.contact || !confirm('Clear this chat on this device?')) return;
    await DB.clearConv(convKey(state.contact));
    $('settings-dialog').close();
    renderAll();
  });
  $('edit-setup2-btn').addEventListener('click', () => { logout(); showSetup(); });
  $('wipe-btn').addEventListener('click', wipeAll);
}
window.addEventListener('online', () => { toast('Back online'); pullMessages(); });
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) { state.unread = 0; updateTitle(); pullMessages(); }
  schedulePoll();
});
window.addEventListener('load', async () => {
  bindUI();
  try { await DB.open(); }
  catch { return toast('Local storage (IndexedDB) is unavailable — private/incognito mode?', 'error', 10000); }
  let tries = 0;
  const wait = setInterval(() => {
    if (window.google && google.accounts && google.accounts.oauth2) { clearInterval(wait); initAuth(); }
    else if (++tries > 50) { clearInterval(wait); toast('Google sign-in library failed to load. Check your connection.', 'error', 8000); }
  }, 200);
});
