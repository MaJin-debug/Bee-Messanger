package com.bee.messenger;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Checks Gmail for new BEE mail and shows a notification. It can NOT read messages:
 *  it only sees the sender and the subject ("BEE Messenger", "... Talk", "... Req", "... Sys"). */
final class Poller {
    private static final String TAG = "BeePoller";
    private static String access;
    private static long accessExp;
    private static long lastRun;

    private Poller() {}

    static synchronized void pollOnce(Context ctx) {
        long now = System.currentTimeMillis();
        if (now - lastRun < 20000) return;
        lastRun = now;
        SharedPreferences p = BeeBridge.prefs(ctx);
        String cid = p.getString("clientId", "");
        String rt = p.getString("refresh", "");
        if (cid.isEmpty() || rt.isEmpty()) return;
        try {
            String tok = token(ctx, cid, rt);
            if (tok == null) return;
            long since = p.getLong("since", now);
            String q = "subject:\"BEE Messenger\" -from:me after:" + (since / 1000 - 120);
            JSONObject list = getJson("https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=20&q="
                    + URLEncoder.encode(q, "UTF-8"), tok);
            JSONArray arr = list.optJSONArray("messages");
            if (arr == null) return;
            Set<String> seen = new HashSet<String>(p.getStringSet("seen", new HashSet<String>()));
            boolean fg = p.getBoolean("fg", false);
            JSONObject names = new JSONObject(p.getString("names", "{}"));
            long maxDate = since;
            for (int i = 0; i < arr.length(); i++) {
                String id = arr.getJSONObject(i).getString("id");
                if (seen.contains(id)) continue;
                JSONObject m = getJson("https://gmail.googleapis.com/gmail/v1/users/me/messages/" + id
                        + "?format=metadata&metadataHeaders=From&metadataHeaders=Subject", tok);
                long date = Long.parseLong(m.optString("internalDate", "0"));
                seen.add(id);
                if (date < since - 120000) continue;
                if (date > maxDate) maxDate = date;
                if (fg) continue;                      // app is open: it shows its own in-app alert
                String from = "", subj = "";
                JSONArray hs = m.getJSONObject("payload").optJSONArray("headers");
                if (hs != null) for (int h = 0; h < hs.length(); h++) {
                    JSONObject hh = hs.getJSONObject(h);
                    String n = hh.optString("name", "");
                    if (n.equalsIgnoreCase("From")) from = hh.optString("value", "");
                    if (n.equalsIgnoreCase("Subject")) subj = hh.optString("value", "").trim();
                }
                notifyFor(ctx, email(from), subj, date, names);
            }
            List<String> keep = new ArrayList<String>(seen);
            if (keep.size() > 300) keep = keep.subList(keep.size() - 300, keep.size());
            p.edit().putStringSet("seen", new HashSet<String>(keep)).putLong("since", maxDate).apply();
        } catch (Exception e) {
            Log.w(TAG, "poll failed: " + e);
        }
    }

    private static String email(String from) {
        int a = from.indexOf('<'), b = from.indexOf('>');
        String e = (a >= 0 && b > a) ? from.substring(a + 1, b) : from;
        return e.trim().toLowerCase();
    }

    private static void notifyFor(Context ctx, String from, String subj, long date, JSONObject names) {
        BeeService.ensureChannels(ctx);
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        String name = names.optString(from, "");
        String title, text, channel;
        int id = 100 + Math.abs(from.hashCode() % 100000);
        if (subj.endsWith(" Talk")) {
            if (name.isEmpty() || System.currentTimeMillis() - date > 10 * 60 * 1000) return;
            title = name; text = "wants to talk now. Tap to join Instant mode."; channel = BeeService.CH_TALK;
        } else if (subj.endsWith(" Req")) {
            title = "BEE Messenger"; text = "You have a new contact request."; channel = BeeService.CH_MSG; id = 99;
        } else if (subj.endsWith(" Sys")) {
            return;
        } else {
            if (name.isEmpty()) return;                 // not one of your people
            title = name; text = "New message"; channel = BeeService.CH_MSG;
        }
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, channel)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(channel.equals(BeeService.CH_TALK) ? NotificationCompat.CATEGORY_CALL : NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(BeeService.openApp(ctx));
        if (channel.equals(BeeService.CH_TALK)) b.setTimeoutAfter(10 * 60 * 1000);
        nm.notify(id, b.build());
    }

    private static String token(Context ctx, String cid, String rt) throws Exception {
        long now = System.currentTimeMillis();
        if (access != null && now < accessExp - 60000) return access;
        String body = "client_id=" + URLEncoder.encode(cid, "UTF-8")
                + "&refresh_token=" + URLEncoder.encode(rt, "UTF-8")
                + "&grant_type=refresh_token";
        HttpURLConnection c = (HttpURLConnection) new URL("https://oauth2.googleapis.com/token").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        OutputStream os = c.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.close();
        int code = c.getResponseCode();
        String res = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
        JSONObject j = new JSONObject(res);
        if (code >= 400) {
            if ("invalid_grant".equals(j.optString("error"))) BeeBridge.prefs(ctx).edit().remove("refresh").apply();
            return null;
        }
        access = j.getString("access_token");
        accessExp = now + j.optLong("expires_in", 3600) * 1000;
        return access;
    }

    private static JSONObject getJson(String url, String tok) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Authorization", "Bearer " + tok);
        int code = c.getResponseCode();
        String res = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
        if (code == 401) access = null;
        if (code >= 400) throw new Exception("HTTP " + code);
        return new JSONObject(res);
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "{}";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }
}
