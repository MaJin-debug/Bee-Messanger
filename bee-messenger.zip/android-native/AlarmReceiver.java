package com.bee.messenger;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;

/** Wakes the phone about once a minute (when Android allows) to check for new BEE mail. */
public class AlarmReceiver extends BroadcastReceiver {

    private static PendingIntent pi(Context c) {
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, 7, new Intent(c, AlarmReceiver.class), fl);
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = System.currentTimeMillis() + 60000;
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c));
        else am.set(AlarmManager.RTC_WAKEUP, at, pi(c));
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi(c));
    }

    @Override
    public void onReceive(final Context context, Intent intent) {
        final Context app = context.getApplicationContext();
        if (BeeBridge.prefs(app).getString("refresh", "").isEmpty()) return;   // signed out: stop
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                PowerManager.WakeLock wl = null;
                try {
                    PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
                    if (pm != null) { wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bee:poll"); wl.acquire(30000); }
                    Poller.pollOnce(app);
                    try { BeeService.start(app); } catch (Throwable t) { /* background start not allowed: alarm keeps us going */ }
                } catch (Throwable t) {
                    /* ignore */
                } finally {
                    if (wl != null && wl.isHeld()) wl.release();
                    schedule(app);
                    pr.finish();
                }
            }
        }).start();
    }
}
