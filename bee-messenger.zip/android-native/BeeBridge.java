package com.bee.messenger;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

/** Lets the web app configure the background listener. Nothing private is stored here:
 *  no messages, no encryption keys. Only the Google sign-in token and contact display names. */
@CapacitorPlugin(name = "BeeBridge")
public class BeeBridge extends Plugin {

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("bee", Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void configure(PluginCall call) {
        SharedPreferences p = prefs(getContext());
        SharedPreferences.Editor e = p.edit();
        e.putString("clientId", call.getString("clientId", ""));
        String rt = call.getString("refreshToken", "");
        if (rt != null && !rt.isEmpty()) e.putString("refresh", rt);
        e.putString("email", call.getString("email", ""));
        e.putString("names", call.getString("names", "{}"));
        if (!p.contains("since")) e.putLong("since", System.currentTimeMillis());
        e.apply();
        call.resolve();
    }

    @PluginMethod
    public void start(PluginCall call) {
        try {
            SharedPreferences p = prefs(getContext());
            if (p.getString("refresh", "").isEmpty()) { call.reject("not signed in"); return; }
            BeeService.start(getContext());
            call.resolve();
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void setForeground(PluginCall call) {
        Boolean fg = call.getBoolean("fg", false);
        prefs(getContext()).edit().putBoolean("fg", fg != null && fg).apply();
        call.resolve();
    }

    @PluginMethod
    public void clear(PluginCall call) {
        prefs(getContext()).edit().clear().apply();
        BeeService.stop(getContext());
        call.resolve();
    }

    @PluginMethod
    public void requestBatteryExemption(PluginCall call) {
        try {
            Context c = getContext();
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName())) { call.resolve(); return; }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + c.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            call.resolve();
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    /** Draws a QR code: returns the module matrix as a "0101..." string for the web layer to paint. */
    @PluginMethod
    public void qr(PluginCall call) {
        try {
            String text = call.getString("text", "");
            Map<EncodeHintType, Object> hints = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
            hints.put(EncodeHintType.MARGIN, 0);
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints);
            StringBuilder sb = new StringBuilder();
            for (int y = 0; y < m.getHeight(); y++)
                for (int x = 0; x < m.getWidth(); x++) sb.append(m.get(x, y) ? '1' : '0');
            JSObject o = new JSObject();
            o.put("size", m.getWidth());
            o.put("bits", sb.toString());
            call.resolve(o);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    /** Wi-Fi / hotspot addresses of this phone (WebView hides them behind .local names). */
    @PluginMethod
    public void localIps(PluginCall call) {
        try {
            List<String> wifi = new ArrayList<String>();
            List<String> other = new ArrayList<String>();
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName().toLowerCase();
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || !a.isSiteLocalAddress()) continue;
                    if (n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth")) wifi.add(a.getHostAddress());
                    else other.add(a.getHostAddress());
                }
            }
            wifi.addAll(other);
            JSArray arr = new JSArray();
            for (String s : wifi) arr.put(s);
            JSObject o = new JSObject();
            o.put("ips", arr);
            call.resolve(o);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }
}
