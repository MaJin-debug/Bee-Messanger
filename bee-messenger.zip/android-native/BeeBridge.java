package com.bee.messenger;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

/** Lets the web app configure the background listener. Nothing private is stored here:
 *  no messages, no encryption keys. Only the Google sign-in token and contact display names. */
@CapacitorPlugin(name = "BeeBridge")
public class BeeBridge extends Plugin {

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("bee", Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void configure(PluginCall call) {
        SharedPreferences p = prefs(getContext());
        SharedPreferences.Editor e = p.edit();
        e.putString("clientId", call.getString("clientId", ""));
        String rt = call.getString("refreshToken", "");
        if (rt != null && !rt.isEmpty()) e.putString("refresh", rt);
        e.putString("email", call.getString("email", ""));
        e.putString("names", call.getString("names", "{}"));
        if (!p.contains("since")) e.putLong("since", System.currentTimeMillis());
        e.apply();
        call.resolve();
    }

    @PluginMethod
    public void start(PluginCall call) {
        try {
            SharedPreferences p = prefs(getContext());
            if (p.getString("refresh", "").isEmpty()) { call.reject("not signed in"); return; }
            BeeService.start(getContext());
            call.resolve();
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void setForeground(PluginCall call) {
        Boolean fg = call.getBoolean("fg", false);
        prefs(getContext()).edit().putBoolean("fg", fg != null && fg).apply();
        call.resolve();
    }

    @PluginMethod
    public void clear(PluginCall call) {
        prefs(getContext()).edit().clear().apply();
        BeeService.stop(getContext());
        call.resolve();
    }

    @PluginMethod
    public void requestBatteryExemption(PluginCall call) {
        try {
            Context c = getContext();
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName())) { call.resolve(); return; }
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + c.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            call.resolve();
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }
}
