package com.bee.messenger;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the listener after the phone reboots or BEE is updated. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Context app = context.getApplicationContext();
            if (!BeeBridge.prefs(app).getString("refresh", "").isEmpty()) {
                BeeService.start(app);
                AlarmReceiver.schedule(app);
            }
        } catch (Throwable t) { /* ignore */ }
    }
}
