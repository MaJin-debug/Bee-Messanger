package com.bee.messenger;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

import androidx.core.app.NotificationCompat;

/** Foreground service: keeps BEE alive so it can check Gmail for new BEE mail while the app is closed. */
public class BeeService extends Service {
    static final String CH_SVC = "bee_service";
    static final String CH_MSG = "bee_messages";
    static final String CH_TALK = "bee_talk";
    private volatile boolean running = false;
    private Thread loop;

    static void start(Context c) {
        Intent i = new Intent(c, BeeService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, BeeService.class));
        AlarmReceiver.cancel(c);
    }

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel svc = new NotificationChannel(CH_SVC, "BEE is listening", NotificationManager.IMPORTANCE_MIN);
        svc.setDescription("Keeps BEE able to tell you about new messages. You can hide this one.");
        NotificationChannel msg = new NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_HIGH);
        NotificationChannel talk = new NotificationChannel(CH_TALK, "Talk now requests", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(svc);
        nm.createNotificationChannel(msg);
        nm.createNotificationChannel(talk);
    }

    static PendingIntent openApp(Context c) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (i != null) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(c, 0, i, fl);
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CH_SVC)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("BEE is listening")
                .setContentText("Waiting for new messages")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setContentIntent(openApp(this))
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ensureChannels(this);
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        if (!running) {
            running = true;
            loop = new Thread(new Runnable() {
                @Override public void run() {
                    while (running) {
                        try { Poller.pollOnce(getApplicationContext()); } catch (Throwable t) { /* keep going */ }
                        SystemClock.sleep(45000);
                    }
                }
            }, "bee-poll");
            loop.start();
        }
        AlarmReceiver.schedule(this);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
