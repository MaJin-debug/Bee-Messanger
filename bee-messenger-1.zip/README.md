# BEE Messenger v3

Serverless 1:1 chat. Gmail API = relay + signaling, WebRTC = direct P2P, E2E encryption in the browser.

## Your icon
Put your `icon.png` (square, 512x512 or bigger) next to `index.html` when testing locally,
and next to `bee-messenger.zip` in the GitHub repo (the workflow copies it into the site).
It is used for the login logo, header, browser tab, home-screen icon and notifications.
If it is missing, a plain fallback logo is shown.

## One-time Google setup
1. console.cloud.google.com -> new project -> enable **Gmail API**.
2. OAuth consent screen: External, add yourself AND your contact as **Test users**.
3. Credentials -> Create **OAuth client ID** -> Web application.
   Authorized JavaScript origin: your Pages origin, e.g. `https://USER.github.io` (no path, no trailing slash).
4. Open the site, paste the Client ID, sign in (tick ALL permission boxes).
5. Type your contact's Gmail, tap **Connect**. They must open the site too.
6. Compare the safety number (shield button) over a call, then tap "Numbers match".

## Using it
- Tap (or long-press) any bubble: Copy text / Save to device / Share / Delete for me.
- Mic button: tap to record, tap again to send, trash icon to cancel.
- Settings: Dark, Light or Bee theme, notifications, clear chat.
- Notifications only work while the page is open (even in a background tab); there is no server to push to a closed browser.

## Android APK
The same code runs as an Android app. Use the GitHub Actions workflow `build-apk.yml`
(see the chat instructions): it wraps this site with Capacitor, signs the APK and publishes it under Releases.
The APK signs in with a Google **Android** OAuth client (not the Web client) and stays signed in using a refresh token.
