(function () {
  try { document.documentElement.setAttribute('data-theme', localStorage.getItem('bee_theme') || 'bee'); } catch (e) {}
})();
