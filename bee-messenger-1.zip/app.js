'use strict';
// ============================================================
// BEE Messenger v4 (web + Android APK) — serverless E2E-encrypted chat over Gmail + WebRTC
// ============================================================

const SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/userinfo.email'
];
const GM = 'https://gmail.googleapis.com/gmail/v1/users/me';
const TAG_SIG = '[BEE:v2:sig]';
const TAG_ENC = '[BEE:v2:enc]';
const MAX_RELAY_MB = 5;      // Gmail relay (base64 overhead + 25MB mail limit)
const MAX_P2P_MB = 25;       // direct WebRTC transfer
const POLL_VISIBLE = 15000;
const POLL_HIDDEN = 60000;
const SIGNAL_TTL = 10 * 60 * 1000;   // ignore offers/answers older than this
const CHUNK = 16 * 1024;
const EMAIL_RE = /^[^\s@<>,;"']+@[^\s@<>,;"']+\.[^\s@<>,;"']+$/;
const SAFE_MEDIA = /^(image\/(png|jpe?g|gif|webp|avif|bmp)|video\/(mp4|webm|quicktime|ogg)|audio\/(webm|ogg|mp4|mpeg|wav|aac|x-m4a))$/i;
const ECDH = { name: 'ECDH', namedCurve: 'P-256' };
// Running inside the Capacitor Android app?
const NATIVE = !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
const CAP = () => (window.Capacitor && window.Capacitor.Plugins) || {};

const $ = (id) => document.getElementById(id);
const utf8 = new TextEncoder();
const dec = new TextDecoder();

// ---------------- STATE ----------------
const state = {
  token: null, tokenExp: 0, expired: false, pending: null,
  myEmail: null, keyPair: null, myPubB64: null,
  contacts: {},            // email -> { pub, verified }
  contact: null,
  keyCache: {},            // email -> { pub, key }
  peer: null, peerConnected: false, rx: null,
  processed: new Set(),
  pollTimer: null, polling: false, pulling: false,
  recording: null, recStarting: false, lastDay: null, menuBubble: null, menuAt: 0,
  unread: 0, urls: [], renderSeq: 0,
  sendChain: Promise.resolve()
};
let tokenClient = null;

// ---------------- UI HELPERS ----------------
function toast(msg, type = 'info', ms = 4000) {
  const d = document.createElement('div');
  d.className = 'toast ' + type;
  d.textContent = msg;
  $('toasts').appendChild(d);
  setTimeout(() => d.remove(), ms);
  if (type === 'error') console.error(msg);
}
function showBanner(text, btnText, fn) {
  $('banner-text').textContent = text;
  const b = $('banner-btn');
  b.textContent = btnText;
  b.onclick = fn;
  $('banner').classList.remove('hidden');
}
function hideBanner() { $('banner').classList.add('hidden'); }
function setPeerStatus(s) {
  const el = $('peer-status');
  const c = state.contact && state.contacts[state.contact];
  el.className = 'status ' + (s === 'online' ? 'online' : s === 'connecting' ? 'connecting' : 'offline');
  $('peer-status-text').textContent =
    s === 'online' ? 'Direct P2P connection' :
    s === 'connecting' ? 'Connecting…' :
    c ? 'Offline · using encrypted Gmail relay' : 'Not connected · tap Connect';
}
function fmtSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}
function cleanName(n) {
  return String(n || 'file').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 100) || 'file';
}
function safeMime(m) { return SAFE_MEDIA.test(m || '') ? m : 'application/octet-stream'; }
const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join(''));
const convKey = (contact) => `${state.myEmail}|${contact}`;
const K = (n) => `${state.myEmail}:${n}`;

// ---------------- BASE64 ----------------
function toB64(buf) {
  const b = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(s);
}
function fromB64(s) {
  const bin = atob(s);
  const b = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
  return b;
}
const b64url = (bytes) => toB64(bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return fromB64(s);
}
const wrap76 = (s) => (s.match(/.{1,76}/g) || ['']).join('\r\n');

// ---------------- LOCAL DB (IndexedDB) ----------------
const DB = {
  db: null,
  open() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('bee', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('kv');
        const m = d.createObjectStore('messages', { keyPath: 'id' });
        m.createIndex('conv', 'conv');
      };
      r.onsuccess = () => { this.db = r.result; res(); };
      r.onerror = () => rej(r.error);
    });
  },
  tx(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = this.db.transaction(store, mode);
      const rq = fn(t.objectStore(store));
      t.oncomplete = () => res(rq && rq.result);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  },
  get(k) { return this.tx('kv', 'readonly', s => s.get(k)); },
  set(k, v) { return this.tx('kv', 'readwrite', s => s.put(v, k)); },
  putMsg(m) { return this.tx('messages', 'readwrite', s => s.put(m)); },
  getMsg(id) { return this.tx('messages', 'readonly', s => s.get(id)); },
  delMsg(id) { return this.tx('messages', 'readwrite', s => s.delete(id)); },
  msgsFor(conv) { return this.tx('messages', 'readonly', s => s.index('conv').getAll(conv)); },
  clearConv(conv) {
    return this.tx('messages', 'readwrite', s => {
      const r = s.index('conv').openKeyCursor(IDBKeyRange.only(conv));
      r.onsuccess = () => { const c = r.result; if (c) { s.delete(c.primaryKey); c.continue(); } };
      return r;
    });
  }
};

// ---------------- CRYPTO ----------------
async function createKeys() {
  // private key is NON-extractable: JS (or an XSS) can use it but never read it
  const kp = await crypto.subtle.generateKey(ECDH, false, ['deriveBits']);
  await DB.set(K('keypair'), kp);
  return kp;
}
async function deriveKeyFor(peerPubB64) {
  const peerPub = await crypto.subtle.importKey('raw', fromB64(peerPubB64), ECDH, true, []);
  const bits = await crypto.subtle.deriveBits({ name: 'ECDH', public: peerPub }, state.keyPair.privateKey, 256);
  const hk = await crypto.subtle.importKey('raw', bits, 'HKDF', false, ['deriveKey']);
  const [a, b] = [state.myPubB64, peerPubB64].sort();
  const salt = await crypto.subtle.digest('SHA-256', utf8.encode(a + '|' + b));
  return crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info: utf8.encode('BEE-Messenger-v2') },
    hk, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']
  );
}
async function getKey(email) {
  const c = state.contacts[email];
  if (!c) return null;
  const hit = state.keyCache[email];
  if (hit && hit.pub === c.pub) return hit.key;
  const key = await deriveKeyFor(c.pub);
  state.keyCache[email] = { pub: c.pub, key };
  return key;
}
async function safetyNumber(peerPubB64) {
  const [a, b] = [state.myPubB64, peerPubB64].sort();
  const h = new Uint8Array(await crypto.subtle.digest('SHA-256', utf8.encode(a + '|' + b)));
  const digits = Array.from(h.slice(0, 15)).map(x => String(x).padStart(3, '0')).join('');
  return digits.match(/.{1,5}/g).join(' ');
}
// AAD binds ciphertext to sender -> recipient so it can't be re-targeted
const aad = (from, to) => utf8.encode(`${from.toLowerCase()}>${to.toLowerCase()}`);

// ---------------- GMAIL ----------------
function authError() { const e = new Error('Session expired'); e.code = 'AUTH'; return e; }
function expire() {
  state.expired = true;
  showBanner('Session expired — sign in again to keep receiving messages.', 'Sign in', startLogin);
  return authError();
}
let refreshing = null;
function refreshToken() {
  if (refreshing) return refreshing;
  if (NATIVE) {
    refreshing = nativeRefresh().finally(() => { refreshing = null; });
    return refreshing;
  }
  refreshing = new Promise((resolve, reject) => {
    if (!tokenClient) return reject(new Error('no auth'));
    state.pending = { resolve, reject };
    const t = setTimeout(() => reject(new Error('timeout')), 20000);
    const done = () => clearTimeout(t);
    state.pending.resolve = (v) => { done(); resolve(v); };
    state.pending.reject = (e) => { done(); reject(e); };
    try { tokenClient.requestAccessToken({ prompt: '', login_hint: state.myEmail || undefined }); }
    catch (e) { done(); reject(e); }
  }).finally(() => { refreshing = null; state.pending = null; });
  return refreshing;
}
async function gfetch(url, opts = {}, retry = true) {
  if (state.expired) throw authError();
  if (Date.now() > state.tokenExp - 60000) {
    try { await refreshToken(); } catch (e) { if (e instanceof TypeError) throw e; throw expire(); }
  }
  const res = await fetch(url, { ...opts, headers: { ...(opts.headers || {}), Authorization: `Bearer ${state.token}` } });
  if (res.status === 401 && retry) {
    try { await refreshToken(); } catch (e) { if (e instanceof TypeError) throw e; throw expire(); }
    return gfetch(url, opts, false);
  }
  if (!res.ok) {
    const e = new Error(`Gmail ${res.status}: ${(await res.text()).slice(0, 160)}`);
    e.status = res.status;
    throw e;
  }
  return res;
}
function buildRaw(to, tag, bytes) {
  if (!EMAIL_RE.test(to)) throw new Error('Bad recipient');
  const body = tag + '\r\n' + wrap76(toB64(bytes));
  const msg = [
    `To: ${to}`, 'Subject: BEE Messenger',
    'Content-Type: text/plain; charset="UTF-8"', 'Content-Transfer-Encoding: 7bit',
    'MIME-Version: 1.0', '', body
  ].join('\r\n');
  return b64url(utf8.encode(msg));
}
async function gmailSendRaw(raw) {
  await gfetch(`${GM}/messages/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ raw })
  });
}
const relaySignal = (to, obj) => gmailSendRaw(buildRaw(to, TAG_SIG, utf8.encode(JSON.stringify(obj))));

async function relaySend(to, m, blob) {
  const key = await getKey(to);
  if (!key) throw new Error('No keys yet — tap Connect and wait for your contact to be online.');
  const header = utf8.encode(JSON.stringify({
    mid: m.mid, ts: m.ts, type: m.kind === 'file' ? 'file' : 'text',
    text: m.text, mime: m.mime, name: m.name, dur: m.dur
  }));
  const data = blob ? new Uint8Array(await blob.arrayBuffer()) : new Uint8Array(0);
  const pt = new Uint8Array(4 + header.length + data.length);
  new DataView(pt.buffer).setUint32(0, header.length);
  pt.set(header, 4);
  pt.set(data, 4 + header.length);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: aad(state.myEmail, to) }, key, pt));
  const out = new Uint8Array(12 + ct.length);
  out.set(iv, 0); out.set(ct, 12);
  await gmailSendRaw(buildRaw(to, TAG_ENC, out));
}

async function extractBody(id, p) {
  if (p.parts) {
    for (const c of p.parts) { const b = await extractBody(id, c); if (b) return b; }
    return null;
  }
  if (p.body && p.body.data) return dec.decode(b64urlToBytes(p.body.data));
  if (p.body && p.body.attachmentId) {   // big bodies come as attachments
    const a = await (await gfetch(`${GM}/messages/${id}/attachments/${p.body.attachmentId}`)).json();
    return dec.decode(b64urlToBytes(a.data));
  }
  return null;
}
function parseBee(body) {
  if (!body) return null;
  const m = body.match(/\[BEE:v2:(sig|enc)\]\s*([A-Za-z0-9+/=\s]+)/);
  if (!m) return null;
  try {
    const bytes = fromB64(m[2].replace(/\s+/g, ''));
    return m[1] === 'sig'
      ? { kind: 'sig', json: JSON.parse(dec.decode(bytes)) }
      : { kind: 'enc', bytes };
  } catch { return null; }
}
const hdr = (gm, name) => (gm.payload.headers || []).find(h => h.name.toLowerCase() === name.toLowerCase())?.value || '';
function extractEmail(v) {
  const m = v.match(/<(.+?)>/);
  return (m ? m[1] : v).trim().toLowerCase();
}

// ---------------- WEBRTC ----------------
function iceServers() {
  const list = [{ urls: 'stun:stun.l.google.com:19302' }];
  try {
    const extra = JSON.parse(localStorage.getItem('bee_turn') || '[]');
    if (Array.isArray(extra)) list.push(...extra.filter(s => s && s.urls));
  } catch { /* ignore */ }
  return list;
}
class Peer {
  constructor(cb) {
    this.cb = cb; this.dead = false; this.ch = null;
    this.pc = new RTCPeerConnection({ iceServers: iceServers() });
    this.pc.ondatachannel = (e) => this._setup(e.channel);
    this.pc.onconnectionstatechange = () => {
      if (this.dead) return;
      const s = this.pc.connectionState;
      if (s === 'connected') cb.up();
      if (['disconnected', 'failed', 'closed'].includes(s)) cb.down(s);
    };
  }
  _setup(ch) {
    this.ch = ch;
    ch.binaryType = 'arraybuffer';
    ch.bufferedAmountLowThreshold = 256 * 1024;
    ch.onmessage = (e) => { if (!this.dead) this.cb.msg(e.data); };
    ch.onopen = () => { if (!this.dead) this.cb.up(); };
    ch.onclose = () => { if (!this.dead) this.cb.down('closed'); };
  }
  _ice() {
    const pc = this.pc;
    if (pc.iceGatheringState === 'complete') return Promise.resolve();
    return new Promise(res => {
      const done = () => { pc.removeEventListener('icegatheringstatechange', chk); clearTimeout(t); res(); };
      const chk = () => { if (pc.iceGatheringState === 'complete') done(); };
      const t = setTimeout(done, 5000);
      pc.addEventListener('icegatheringstatechange', chk);
    });
  }
  async createOffer() {
    this._setup(this.pc.createDataChannel('chat'));
    await this.pc.setLocalDescription(await this.pc.createOffer());
    await this._ice();
    return this.pc.localDescription;
  }
  async acceptOffer(offer) {
    await this.pc.setRemoteDescription(offer);
    await this.pc.setLocalDescription(await this.pc.createAnswer());
    await this._ice();
    return this.pc.localDescription;
  }
  acceptAnswer(a) { return this.pc.setRemoteDescription(a); }
  get open() { return this.ch && this.ch.readyState === 'open'; }
  async _wait() {
    while (this.ch.bufferedAmount > 1024 * 1024) {
      await new Promise(r => {
        this.ch.onbufferedamountlow = () => { this.ch.onbufferedamountlow = null; r(); };
        setTimeout(r, 500);
      });
      if (!this.open) throw new Error('P2P closed');
    }
  }
  async send(data) { await this._wait(); this.ch.send(data); }
  close() { this.dead = true; try { if (this.ch) this.ch.close(); this.pc.close(); } catch { /* ignore */ } }
}
function newPeer() {
  const p = new Peer({
    up: () => { if (state.peer === p) onPeerUp(); },
    down: () => { if (state.peer === p) onPeerDown(); },
    msg: (d) => { if (state.peer === p) onPeerData(d); }
  });
  return p;
}
function closePeer() {
  if (state.peer) { state.peer.close(); state.peer = null; }
  state.peerConnected = false;
  state.rx = null;
  setPeerStatus('offline');
}
function onPeerUp() {
  if (state.peerConnected) return;
  state.peerConnected = true;
  setPeerStatus('online');
  toast('Direct P2P channel open');
}
function onPeerDown() {
  if (!state.peerConnected && !state.peer) return;
  state.peerConnected = false;
  state.rx = null;
  setPeerStatus('offline');
}

// P2P wire format: JSON string control messages + raw binary chunks for files
function onPeerData(d) {
  try {
    if (typeof d === 'string') {
      const o = JSON.parse(d);
      if (o.t === 'text') {
        ingest(state.contact, { mid: o.mid, ts: o.ts, type: 'text', text: o.text }, null, 'p2p');
      } else if (o.t === 'file') {
        const size = Number(o.size);
        if (!(size >= 0) || size > MAX_P2P_MB * 1048576) { state.rx = null; toast('Incoming file rejected (too large)', 'error'); return; }
        state.rx = { meta: o, parts: [], got: 0, size };
        if (size === 0) finishRx();
      }
    } else if (state.rx) {
      state.rx.parts.push(d);
      state.rx.got += d.byteLength;
      if (state.rx.got >= state.rx.size) finishRx();
    }
  } catch { toast('Bad P2P message', 'error'); }
}
function finishRx() {
  const { meta, parts } = state.rx;
  state.rx = null;
  ingest(state.contact, { mid: meta.mid, ts: meta.ts, type: 'file', mime: meta.mime, name: meta.name, dur: meta.dur }, new Blob(parts), 'p2p');
}
async function p2pSend(m, blob) {
  const p = state.peer;
  if (!p || !p.open) throw new Error('P2P closed');
  if (m.kind === 'text') {
    await p.send(JSON.stringify({ t: 'text', mid: m.mid, ts: m.ts, text: m.text }));
  } else {
    await p.send(JSON.stringify({ t: 'file', mid: m.mid, ts: m.ts, mime: m.mime, name: m.name, size: blob.size, dur: m.dur }));
    for (let o = 0; o < blob.size; o += CHUNK) await p.send(await blob.slice(o, o + CHUNK).arrayBuffer());
  }
}

// ---------------- AUTH ----------------
function showSetup() {
  $('setup-area').classList.remove('hidden');
  $('login-btn').classList.add('hidden');
  $('edit-setup-btn').classList.add('hidden');
  $('client-id-input').value = localStorage.getItem('bee_clientId') || '';
  $('turn-input').value = localStorage.getItem('bee_turn') || '';
}
function saveSetup() {
  const val = $('client-id-input').value.trim();
  if (!val.endsWith('.apps.googleusercontent.com')) return toast('Invalid Client ID format.', 'error');
  const turn = $('turn-input').value.trim();
  if (turn) {
    try { if (!Array.isArray(JSON.parse(turn))) throw 0; }
    catch { return toast('TURN must be a JSON array.', 'error'); }
  }
  localStorage.setItem('bee_clientId', val);
  if (turn) localStorage.setItem('bee_turn', turn); else localStorage.removeItem('bee_turn');
  $('setup-area').classList.add('hidden');
  initAuth();
}
async function initAuth() {
  const preset = NATIVE && window.BEE_NATIVE && window.BEE_NATIVE.clientId;
  if (preset) localStorage.setItem('bee_clientId', preset);
  const cid = localStorage.getItem('bee_clientId');
  if (!cid) return showSetup();
  if (NATIVE) return initNativeAuth();
  tokenClient = google.accounts.oauth2.initTokenClient({
    client_id: cid,
    scope: SCOPES.join(' '),
    callback: onToken,
    error_callback: (e) => {
      if (state.pending) state.pending.reject(e);
      else if (e.type !== 'popup_closed') toast('Sign-in failed: ' + (e.type || 'unknown'), 'error');
    }
  });
  $('edit-setup-btn').classList.remove('hidden');
  try {   // restore a still-valid token for this browser tab session
    const s = JSON.parse(sessionStorage.getItem('bee_tok') || 'null');
    if (s && s.e > Date.now() + 60000) { state.token = s.t; state.tokenExp = s.e; onLoggedIn(); return; }
  } catch { /* ignore */ }
  $('login-btn').classList.remove('hidden');
}
// ---- Android app sign-in: system browser + PKCE (Google blocks web sign-in inside WebViews) ----
const nativeRedirect = (cid) => 'com.googleusercontent.apps.' + cid.replace(/\.apps\.googleusercontent\.com$/, '') + ':/oauth2redirect';
function setTokenFields(access, expiresIn) {
  state.token = access;
  state.tokenExp = Date.now() + Number(expiresIn || 3600) * 1000;
  try { sessionStorage.setItem('bee_tok', JSON.stringify({ t: state.token, e: state.tokenExp })); } catch { /* ignore */ }
  state.expired = false;
  hideBanner();
}
async function initNativeAuth() {
  $('edit-setup-btn').classList.remove('hidden');
  try {
    const s = JSON.parse(sessionStorage.getItem('bee_tok') || 'null');
    if (s && s.e > Date.now() + 60000) { state.token = s.t; state.tokenExp = s.e; return onLoggedIn(); }
  } catch { /* ignore */ }
  if (localStorage.getItem('bee_refresh')) {   // stay signed in across app restarts
    try { await refreshToken(); return onLoggedIn(); } catch (e) { console.warn('Silent sign-in failed', e); }
  }
  $('login-btn').classList.remove('hidden');
}
async function nativeSignIn() {
  const { Browser, App } = CAP();
  if (!Browser || !App) throw new Error('Native plugins missing');
  const cid = localStorage.getItem('bee_clientId');
  const redirect = nativeRedirect(cid);
  const scheme = redirect.split(':')[0] + ':';
  const verifier = b64url(crypto.getRandomValues(new Uint8Array(48)));
  const challenge = b64url(new Uint8Array(await crypto.subtle.digest('SHA-256', utf8.encode(verifier))));
  const st = b64url(crypto.getRandomValues(new Uint8Array(16)));
  const params = {
    client_id: cid, redirect_uri: redirect, response_type: 'code', scope: SCOPES.join(' '),
    code_challenge: challenge, code_challenge_method: 'S256', access_type: 'offline', prompt: 'consent', state: st
  };
  if (state.myEmail) params.login_hint = state.myEmail;

  let resolveCode, rejectCode, done = false;
  const codeP = new Promise((res, rej) => { resolveCode = res; rejectCode = rej; });
  const subs = [];
  const finish = (ok, v) => { if (done) return; done = true; subs.forEach(h => { try { h.remove(); } catch { /* ignore */ } }); ok ? resolveCode(v) : rejectCode(v); };
  subs.push(await App.addListener('appUrlOpen', (ev) => {
    if (!ev.url || !ev.url.startsWith(scheme)) return;
    const q = new URLSearchParams(ev.url.split('?')[1] || '');
    try { Browser.close(); } catch { /* ignore */ }
    if (q.get('error')) return finish(false, new Error(q.get('error')));
    if (q.get('state') !== st) return finish(false, new Error('state mismatch'));
    finish(true, q.get('code'));
  }));
  subs.push(await Browser.addListener('browserFinished', () => setTimeout(() => finish(false, new Error('Sign-in cancelled')), 1500)));
  await Browser.open({ url: 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams(params) });
  const code = await codeP;

  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: cid, code, code_verifier: verifier, redirect_uri: redirect, grant_type: 'authorization_code' })
  });
  const t = await r.json();
  if (!t.access_token) throw new Error(t.error_description || t.error || 'Token exchange failed');
  return t;
}
async function nativeLogin() {
  try {
    const t = await nativeSignIn();
    setTokenFields(t.access_token, t.expires_in);
    if (t.refresh_token) localStorage.setItem('bee_refresh', t.refresh_token);
    if (!state.myEmail) onLoggedIn(); else pullMessages();
  } catch (e) { toast('Sign-in failed: ' + e.message, 'error', 7000); }
}
async function nativeRefresh() {
  const rt = localStorage.getItem('bee_refresh');
  if (!rt) throw new Error('No saved session');
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: localStorage.getItem('bee_clientId'), refresh_token: rt, grant_type: 'refresh_token' })
  });
  const t = await r.json();
  if (!t.access_token) {
    if (t.error === 'invalid_grant') localStorage.removeItem('bee_refresh');
    throw new Error(t.error_description || t.error || 'Refresh failed');
  }
  setTokenFields(t.access_token, t.expires_in);
}
function startLogin() {
  if (NATIVE) return nativeLogin();
  if (!tokenClient) return initAuth();
  tokenClient.requestAccessToken(state.myEmail ? { prompt: '', login_hint: state.myEmail } : {});
}
function onToken(resp) {
  if (resp.error) {
    if (state.pending) state.pending.reject(new Error(resp.error));
    return toast('Auth error: ' + resp.error, 'error');
  }
  if (!google.accounts.oauth2.hasGrantedAllScopes(resp, ...SCOPES)) {
    return toast('Please tick ALL permission boxes on the Google consent screen.', 'error', 6000);
  }
  state.token = resp.access_token;
  state.tokenExp = Date.now() + Number(resp.expires_in || 3600) * 1000;
  try { sessionStorage.setItem('bee_tok', JSON.stringify({ t: state.token, e: state.tokenExp })); } catch { /* ignore */ }
  state.expired = false;
  hideBanner();
  if (state.pending) state.pending.resolve();
  if (!state.myEmail) onLoggedIn();
  else { pullMessages(); }
}
async function onLoggedIn() {
  if (state.myEmail) return;
  try {
    const info = await (await gfetch('https://www.googleapis.com/oauth2/v3/userinfo')).json();
    state.myEmail = String(info.email).toLowerCase();
    state.keyPair = (await DB.get(K('keypair'))) || await createKeys();
    state.myPubB64 = toB64(await crypto.subtle.exportKey('raw', state.keyPair.publicKey));
    state.contacts = (await DB.get(K('contacts'))) || {};
    state.processed = new Set((await DB.get(K('processed'))) || []);
    state.contact = (await DB.get(K('contact'))) || null;

    $('login-screen').classList.add('hidden');
    $('chat-screen').classList.remove('hidden');
    $('my-email').textContent = state.myEmail;
    $('contact-input').value = state.contact || '';
    refreshContactUI();
    await renderAll();
    startPolling();
    pullMessages();
  } catch (e) {
    state.myEmail = null; state.token = null;
    sessionStorage.removeItem('bee_tok');
    $('login-btn').classList.remove('hidden');
    toast('Login failed: ' + e.message, 'error');
  }
}
function logout() {
  try { if (state.token) google.accounts.oauth2.revoke(state.token); } catch { /* ignore */ }
  sessionStorage.removeItem('bee_tok');
  localStorage.removeItem('bee_refresh');
  stopRecording(false);
  stopPolling();
  closePeer();
  Object.assign(state, { token: null, myEmail: null, contact: null, keyPair: null, contacts: {}, keyCache: {}, expired: false });
  hideBanner();
  closeDlg($('settings-dialog'));
  $('chat-screen').classList.add('hidden');
  $('login-screen').classList.remove('hidden');
  $('login-btn').classList.remove('hidden');
}
async function wipeAll() {
  if (!confirm('Delete ALL messages, contacts and your encryption keys from this device?\nYour contacts will see a "key changed" warning if you chat again.')) return;
  try { google.accounts.oauth2.revoke(state.token); } catch { /* ignore */ }
  if (DB.db) DB.db.close();
  indexedDB.deleteDatabase('bee');
  Object.keys(localStorage).filter(k => k.startsWith('bee_')).forEach(k => localStorage.removeItem(k));
  sessionStorage.clear();
  location.reload();
}

// ---------------- CONTACTS ----------------
async function saveContacts() { await DB.set(K('contacts'), state.contacts); }
async function setContact(email) {
  state.contact = email;
  await DB.set(K('contact'), email);
  $('contact-input').value = email;
  refreshContactUI();
  await renderAll();
}
function refreshContactUI() {
  const dl = $('contact-list');
  dl.replaceChildren(...Object.keys(state.contacts).map(e => { const o = document.createElement('option'); o.value = e; return o; }));
  const c = state.contact && state.contacts[state.contact];
  const vb = $('verify-btn');
  vb.classList.toggle('hidden', !c);
  if (c) {
    vb.replaceChildren(icon(c.verified ? 'shield-check' : 'shield'));
    vb.classList.toggle('verified', !!c.verified);
    vb.title = c.verified ? 'Verified — tap to view safety number' : 'Not verified — tap to verify';
  }
  if (!state.peerConnected) setPeerStatus(state.peer ? 'connecting' : 'offline');
}
async function acceptKey(email, pub) {
  try { await crypto.subtle.importKey('raw', fromB64(pub), ECDH, true, []); }
  catch { toast('Invalid key received from ' + email, 'error'); return false; }
  const c = state.contacts[email];
  if (c && c.pub !== pub) {
    if (!confirm(`Warning: the security key of ${email} has CHANGED.\n\nThis happens if they reinstalled or cleared data — or if someone is intercepting. Compare the new safety number with them before trusting.\n\nAccept the new key?`)) return false;
    state.contacts[email] = { pub, verified: false };
  } else if (!c) {
    state.contacts[email] = { pub, verified: false };
  }
  await saveContacts();
  delete state.keyCache[email];
  refreshContactUI();
  return true;
}
async function openVerify() {
  const c = state.contact && state.contacts[state.contact];
  if (!c) return;
  $('verify-who').textContent = `Safety number for you and ${state.contact}`;
  $('safety').textContent = await safetyNumber(c.pub);
  $('verify-ok').classList.toggle('hidden', !!c.verified);
  openDlg($('verify-dialog'));
}
async function markVerified() {
  const c = state.contacts[state.contact];
  if (c) { c.verified = true; await saveContacts(); refreshContactUI(); toast('Contact marked as verified'); }
  closeDlg($('verify-dialog'));
}

// ---------------- CONNECT (signaling over Gmail) ----------------
async function connectContact() {
  ensureNotifPermission();
  const email = $('contact-input').value.trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return toast('Enter a valid email.', 'error');
  if (email === state.myEmail) return toast("You can't connect to yourself.", 'error');
  closePeer();
  if (email !== state.contact) await setContact(email);
  const peer = newPeer();
  state.peer = peer;
  setPeerStatus('connecting');
  try {
    const offer = await peer.createOffer();
    if (state.peer !== peer) return;
    await relaySignal(email, { type: 'offer', sdp: offer.sdp, pubkey: state.myPubB64 });
    toast('Request sent to ' + email + ' — waiting for them to open BEE…');
    setTimeout(() => {
      if (state.peer === peer && !state.peerConnected) {
        setPeerStatus('offline');
        toast('No answer yet. Your contact must have BEE open (checks every ~15s).', 'info', 6000);
      }
    }, 90000);
  } catch (e) {
    if (state.peer === peer) { closePeer(); }
    if (e.code !== 'AUTH') toast('Connect failed: ' + e.message, 'error');
  }
}
async function handleSignal(sender, sig, age) {
  if (!sig || typeof sig.sdp !== 'string' || typeof sig.pubkey !== 'string') return true;
  if (age > SIGNAL_TTL) return true;   // stale handshake
  if (sig.type === 'offer') {
    // both sides offered at once: the lexicographically smaller email keeps its offer
    if (sender === state.contact && state.peer && state.peer.pc.signalingState === 'have-local-offer' && state.myEmail < sender) return true;
    if (sender !== state.contact) {
      if (!confirm(`${sender} wants to start a secure chat with you.\n\nSwitch to this contact?`)) return true;
      closePeer();
      await setContact(sender);
    }
    if (!(await acceptKey(sender, sig.pubkey))) return true;
    closePeer();
    const peer = newPeer();
    state.peer = peer;
    setPeerStatus('connecting');
    const answer = await peer.acceptOffer({ type: 'offer', sdp: sig.sdp });
    await relaySignal(sender, { type: 'answer', sdp: answer.sdp, pubkey: state.myPubB64 });
    toast('Answer sent — connecting…');
    return true;
  }
  if (sig.type === 'answer') {
    if (sender !== state.contact || !state.peer || state.peer.pc.signalingState !== 'have-local-offer') return true;
    if (!(await acceptKey(sender, sig.pubkey))) return true;
    await state.peer.acceptAnswer({ type: 'answer', sdp: sig.sdp });
    return true;
  }
  return true;
}
async function handleEncrypted(sender, bytes) {
  if (!state.contacts[sender] || bytes.length < 12 + 16 + 4) return true;
  const key = await getKey(sender);
  let pt;
  try {
    pt = new Uint8Array(await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: bytes.slice(0, 12), additionalData: aad(sender, state.myEmail) }, key, bytes.slice(12)));
  } catch {
    toast(`Could not decrypt a message from ${sender} (keys changed?)`, 'error');
    return true;
  }
  const hl = new DataView(pt.buffer).getUint32(0);
  if (hl > 8192 || hl > pt.length - 4) return true;
  const h = JSON.parse(dec.decode(pt.subarray(4, 4 + hl)));
  await ingest(sender, h, pt.subarray(4 + hl), 'relay');
  return true;
}

// ---------------- RECEIVE / POLL ----------------
async function listUnprocessed() {
  const q = encodeURIComponent('subject:"BEE Messenger" -from:me');
  const out = [];
  let page = null;
  for (let i = 0; i < 5; i++) {
    const r = await (await gfetch(`${GM}/messages?q=${q}&maxResults=50` + (page ? `&pageToken=${page}` : ''))).json();
    const fresh = (r.messages || []).map(m => m.id).filter(id => !state.processed.has(id));
    out.push(...fresh);
    if (!fresh.length || !r.nextPageToken) break;
    page = r.nextPageToken;
  }
  return out;
}
async function processMessage(meta) {
  const sender = extractEmail(hdr(meta, 'From'));
  if (!sender || sender === state.myEmail) return;
  const full = await (await gfetch(`${GM}/messages/${meta.id}?format=full`)).json();
  const parsed = parseBee(await extractBody(meta.id, full.payload));
  if (!parsed) return;
  if (parsed.kind === 'sig') await handleSignal(sender, parsed.json, Date.now() - Number(meta.internalDate));
  else await handleEncrypted(sender, parsed.bytes);
}
async function pullMessages(manual = false) {
  if (!state.token || !state.myEmail || state.pulling || state.expired) return;
  state.pulling = true;
  try {
    const ids = await listUnprocessed();
    const metas = [];
    for (const id of ids) {
      metas.push(await (await gfetch(`${GM}/messages/${id}?format=metadata&metadataHeaders=From`)).json());
    }
    metas.sort((a, b) => Number(a.internalDate) - Number(b.internalDate));   // oldest first
    for (const m of metas) {
      try { await processMessage(m); }
      catch (e) {
        // transient problems: stop and retry next poll; permanent ones: skip this message
        if (e instanceof TypeError || e.code === 'AUTH' || e.status >= 500 || e.status === 429) throw e;
        console.error('Skipping bad message', m.id, e);
      }
      markProcessed(m.id);
    }
    if (manual && !metas.length) toast('No new messages');
  } catch (e) {
    if (e.code !== 'AUTH' && (manual || navigator.onLine)) toast('Pull error: ' + e.message, 'error');
  } finally { state.pulling = false; }
}
function markProcessed(id) {
  state.processed.add(id);
  const arr = Array.from(state.processed).slice(-1000);
  state.processed = new Set(arr);
  DB.set(K('processed'), arr).catch(() => {});
}
function startPolling() { state.polling = true; schedulePoll(); }
function stopPolling() { state.polling = false; clearTimeout(state.pollTimer); }
function schedulePoll() {
  clearTimeout(state.pollTimer);
  if (!state.polling) return;
  state.pollTimer = setTimeout(async () => { await pullMessages(); schedulePoll(); },
    document.hidden ? POLL_HIDDEN : POLL_VISIBLE);
}

// ---------------- MESSAGES ----------------
async function ingest(from, h, data, via) {
  if (!from) return;
  const conv = convKey(from);
  const mid = String(h.mid || '').slice(0, 64);
  if (!mid) return;
  const id = `${conv}:${mid}`;
  if (await DB.getMsg(id)) return;   // de-duplicate (replays, relay + P2P)
  const ts = Math.min(Number(h.ts) || Date.now(), Date.now() + 60000);
  const m = { id, mid, conv, side: 'them', ts, via, kind: h.type === 'file' ? 'file' : 'text' };
  if (m.kind === 'text') m.text = String(h.text ?? '').slice(0, 20000);
  else {
    m.name = cleanName(h.name);
    m.mime = safeMime(h.mime);
    m.blob = new Blob([data], { type: m.mime });
    m.size = m.blob.size;
    m.dur = Math.min(Number(h.dur) || 0, 3600);
  }
  await DB.putMsg(m);
  if (from === state.contact) renderMessage(m);
  notifyIncoming(from, m);
}
function notifyIncoming(from, m) {
  if (document.hidden || from !== state.contact) {
    state.unread++;
    updateTitle();
    if (document.hidden) {
      const body = m.kind === 'text' ? m.text.slice(0, 100) : (/^audio\//.test(m.mime) ? 'Voice message' : 'Sent you a file');
      showNotif(from, body, 'bee-' + from);
    }
  }
  if (from !== state.contact) toast('New message from ' + from);
}
function updateTitle() { document.title = (state.unread ? `(${state.unread}) ` : '') + 'BEE Messenger'; }
// Android Chrome forbids `new Notification()`; it must go through the service worker.
async function showNotif(title, body, tag) {
  if (NATIVE) {
    try {
      const LN = CAP().LocalNotifications;
      const perm = await LN.checkPermissions();
      if (perm.display !== 'granted') return;
      await LN.schedule({ notifications: [{ id: Math.floor(Math.random() * 2e9), title, body, extra: { tag } }] });
    } catch { /* ignore */ }
    return;
  }
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const opts = { body, tag, icon: 'icon.png', badge: 'icon.png' };
  try {
    const reg = navigator.serviceWorker && await navigator.serviceWorker.getRegistration();
    if (reg) { await reg.showNotification(title, opts); return; }
  } catch { /* fall through */ }
  try { new Notification(title, opts); } catch { /* ignore */ }
}
function ensureNotifPermission() {
  if (NATIVE) {
    const LN = CAP().LocalNotifications;
    if (LN) LN.checkPermissions()
      .then(p => (p.display === 'prompt' || p.display === 'prompt-with-rationale') ? LN.requestPermissions() : null)
      .then(refreshNotifLabel).catch(() => {});
    return;
  }
  if ('Notification' in window && Notification.permission === 'default') {
    try { Notification.requestPermission().then(refreshNotifLabel); } catch { /* ignore */ }
  }
}
function refreshNotifLabel() {
  const l = $('notif-label');
  if (NATIVE) {
    const LN = CAP().LocalNotifications;
    if (!LN) { l.textContent = 'Notifications not supported here'; return; }
    LN.checkPermissions().then(p => {
      l.textContent = p.display === 'granted' ? 'Notifications are on' : p.display === 'denied' ? 'Notifications blocked in Android settings' : 'Enable notifications';
    }).catch(() => {});
    return;
  }
  if (!('Notification' in window)) l.textContent = 'Notifications not supported here';
  else if (Notification.permission === 'granted') l.textContent = 'Notifications are on';
  else if (Notification.permission === 'denied') l.textContent = 'Notifications blocked in browser settings';
  else l.textContent = 'Enable notifications';
}

function withLock(fn) {
  const p = state.sendChain.then(fn, fn);
  state.sendChain = p.catch(() => {});
  return p;
}
function requireContact() {
  if (!state.contact) { toast('Enter a contact email and tap Connect first.', 'error'); $('contact-input').focus(); return false; }
  return true;
}
async function deliver(m, blob) {
  if (state.peerConnected && state.peer && state.peer.open) {
    try { await p2pSend(m, blob); return 'p2p'; } catch { /* fall back to relay */ }
  }
  if (blob && blob.size > MAX_RELAY_MB * 1048576) {
    throw new Error(`Too big for Gmail relay (max ${MAX_RELAY_MB} MB). Connect P2P to send up to ${MAX_P2P_MB} MB.`);
  }
  await relaySend(state.contact, m, blob);
  return 'relay';
}
function baseMsg() {
  const conv = convKey(state.contact);
  const mid = uuid();
  return { id: `${conv}:${mid}`, mid, conv, side: 'me', ts: Date.now() };
}
async function sendText() {
  const input = $('text-input');
  const text = input.value.trim();
  if (!text || !requireContact()) return;
  ensureNotifPermission();
  input.value = '';
  autosize();
  input.focus();
  const m = { ...baseMsg(), kind: 'text', text };
  try {
    m.via = await withLock(() => deliver(m, null));
    await DB.putMsg(m);
    renderMessage(m);
  } catch (e) {
    input.value = text;   // don't lose the draft
    autosize();
    if (e.code !== 'AUTH') toast('Send failed: ' + e.message, 'error', 6000);
  }
}
async function sendFile(file, extra = {}) {
  if (!file || !requireContact()) return;
  if (file.size > MAX_P2P_MB * 1048576) return toast(`File too large (max ${MAX_P2P_MB} MB).`, 'error');
  const mime = safeMime(file.type);
  const blob = new Blob([file], { type: mime });
  const m = { ...baseMsg(), kind: 'file', name: cleanName(file.name), mime, size: blob.size, blob, dur: extra.dur || 0 };
  toast('Sending ' + m.name + ' (' + fmtSize(m.size) + ')…');
  try {
    m.via = await withLock(() => deliver(m, blob));
    await DB.putMsg(m);
    renderMessage(m);
  } catch (e) {
    if (e.code !== 'AUTH') toast('Send failed: ' + e.message, 'error', 6000);
  }
}

// ---------------- ICONS ----------------
const SVGNS = 'http://www.w3.org/2000/svg';
function icon(name, cls = 'ic') {
  const s = document.createElementNS(SVGNS, 'svg');
  s.setAttribute('class', cls);
  const u = document.createElementNS(SVGNS, 'use');
  u.setAttribute('href', '#i-' + name);
  s.append(u);
  return s;
}

// ---------------- RENDERING ----------------
function revokeUrls() { state.urls.forEach(u => URL.revokeObjectURL(u)); state.urls = []; }
function emptyEl(iconName, text) {
  const d = document.createElement('div');
  d.className = 'empty';
  const b = document.createElement('div'); b.className = 'big'; b.append(icon(iconName, 'ic ic-xl'));
  const p = document.createElement('div'); p.textContent = text;
  d.append(b, p);
  return d;
}
function fmtDur(s) {
  s = Math.max(0, Math.round(s));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}
function fmtTime(ts) { return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
function dayLabel(ts) {
  const d = new Date(ts), t = new Date(), y = new Date();
  y.setDate(t.getDate() - 1);
  if (d.toDateString() === t.toDateString()) return 'Today';
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { day: 'numeric', month: 'short', year: d.getFullYear() === t.getFullYear() ? undefined : 'numeric' });
}
async function renderAll() {
  const seq = ++state.renderSeq;
  const box = $('messages');
  closeMenu(true);
  if (curAudio) { curAudio.pause(); curAudio = null; }
  revokeUrls();
  state.lastDay = null;
  box.replaceChildren();
  if (!state.contact) { box.append(emptyEl('user', 'Enter your contact’s Gmail above and tap Connect.')); return; }
  const msgs = (await DB.msgsFor(convKey(state.contact))).sort((a, b) => a.ts - b.ts);
  if (seq !== state.renderSeq) return;
  if (!msgs.length) { box.append(emptyEl('lock', 'No messages yet. Everything here is end-to-end encrypted.')); return; }
  msgs.forEach(m => renderMessage(m, false));
  box.style.scrollBehavior = 'auto';
  box.scrollTop = box.scrollHeight;
  box.style.scrollBehavior = '';
}

let curAudio = null;
function buildVoice(m, url) {
  const wrap = document.createElement('div');
  wrap.className = 'voice';
  const btn = document.createElement('button');
  btn.className = 'vbtn';
  btn.setAttribute('aria-label', 'Play voice note');
  btn.append(icon('play'));
  const track = document.createElement('div'); track.className = 'vtrack';
  const fill = document.createElement('div'); fill.className = 'vfill';
  track.append(fill);
  const time = document.createElement('span'); time.className = 'vtime';
  const audio = new Audio(url);
  audio.preload = 'metadata';
  const total = () => (Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : (m.dur || 0));
  time.textContent = fmtDur(total());
  btn.onclick = () => {
    if (audio.paused) {
      if (curAudio && curAudio !== audio) curAudio.pause();
      curAudio = audio;
      audio.play().catch(() => {});
    } else audio.pause();
  };
  audio.onplay = () => btn.replaceChildren(icon('pause'));
  audio.onpause = () => btn.replaceChildren(icon('play'));
  audio.onended = () => { fill.style.width = '0%'; time.textContent = fmtDur(total()); btn.replaceChildren(icon('play')); };
  audio.ontimeupdate = () => {
    const t = total();
    fill.style.width = t ? Math.min(100, audio.currentTime / t * 100) + '%' : '0%';
    time.textContent = fmtDur(audio.currentTime > 0 ? audio.currentTime : t);
  };
  track.onclick = (e) => {
    const t = total();
    if (!t) return;
    const r = track.getBoundingClientRect();
    audio.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * t;
  };
  wrap.append(btn, track, time);
  return wrap;
}

function renderMessage(m, live = true) {
  const box = $('messages');
  const em = box.querySelector('.empty');
  if (em) em.remove();
  const near = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  const day = new Date(m.ts).toDateString();
  if (day !== state.lastDay) {
    state.lastDay = day;
    const d = document.createElement('div');
    d.className = 'day';
    d.textContent = dayLabel(m.ts);
    box.append(d);
  }
  const div = document.createElement('div');
  div.className = 'msg ' + m.side + (live ? ' pop' : '');
  div._m = m;
  let withMore = false;
  if (m.kind === 'text') {
    div.append(document.createTextNode(m.text));
  } else if (m.blob) {
    const url = URL.createObjectURL(m.blob);
    state.urls.push(url);
    if (/^image\//.test(m.mime)) {
      div.classList.add('media');
      const i = document.createElement('img');
      i.src = url; i.alt = m.name; i.draggable = false; i.decoding = 'async';
      div.append(i);
    } else if (/^video\//.test(m.mime)) {
      div.classList.add('media');
      const v = document.createElement('video');
      v.src = url; v.controls = true; v.preload = 'metadata'; v.playsInline = true;
      div.append(v);
      withMore = true;
    } else if (/^audio\//.test(m.mime)) {
      div.append(buildVoice(m, url));
    } else {
      const f = document.createElement('div'); f.className = 'filebox';
      f.append(icon('file'));
      const t = document.createElement('div');
      const n = document.createElement('div'); n.className = 'fname'; n.textContent = m.name;
      const sz = document.createElement('div'); sz.className = 'fsize'; sz.textContent = fmtSize(m.size || 0);
      t.append(n, sz);
      f.append(t);
      div.append(f);
    }
  }
  const meta = document.createElement('div');
  meta.className = 'meta';
  if (withMore) {
    const b = document.createElement('button');
    b.className = 'more-btn';
    b.setAttribute('aria-label', 'Options');
    b.append(icon('more'));
    meta.append(b);
  }
  const tm = document.createElement('span');
  tm.textContent = fmtTime(m.ts);
  meta.append(tm, icon(m.via === 'p2p' ? 'zap' : 'mail', 'ic ic-sm'));
  div.append(meta);
  box.append(div);
  if (live && (near || m.side === 'me')) box.scrollTop = box.scrollHeight;
}

// ---------------- MESSAGE MENU (tap / long-press a bubble) ----------------
function saveName(m) {
  if (/^voice-note\./.test(m.name)) {
    const d = new Date(m.ts), p = n => String(n).padStart(2, '0');
    return `voice-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${m.name.slice(m.name.lastIndexOf('.'))}`;
  }
  return m.name;
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const t = document.createElement('textarea');
    t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
    document.body.append(t); t.select();
    try { document.execCommand('copy'); } catch { /* ignore */ }
    t.remove();
  }
  toast('Copied');
}
function saveFile(m) {
  if (NATIVE) return nativeSave(m);
  const url = URL.createObjectURL(m.blob);
  const a = document.createElement('a');
  a.href = url; a.download = saveName(m);
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15000);
  toast('Saved to your Downloads');
}
async function nativeSave(m) {
  const { Filesystem } = CAP();
  try {
    await Filesystem.writeFile({ path: 'BEE/' + saveName(m), data: toB64(await m.blob.arrayBuffer()), directory: 'DOCUMENTS', recursive: true });
    toast('Saved to Documents/BEE');
  } catch {
    await nativeShare(m);   // Android refused: use the share sheet ("Save to device", Files, Drive...)
  }
}
async function nativeShare(m) {
  const { Filesystem, Share } = CAP();
  try {
    const w = await Filesystem.writeFile({ path: saveName(m), data: toB64(await m.blob.arrayBuffer()), directory: 'CACHE' });
    await Share.share({ title: saveName(m), files: [w.uri] });
  } catch (e) {
    if (!/cancel/i.test(String(e && e.message))) toast('Could not share: ' + (e && e.message || e), 'error');
  }
}
function shareable(m) {
  try { return !!(navigator.canShare && navigator.canShare({ files: [new File([m.blob], saveName(m), { type: m.mime })] })); }
  catch { return false; }
}
async function shareFile(m) {
  if (NATIVE) return nativeShare(m);
  try { await navigator.share({ files: [new File([m.blob], saveName(m), { type: m.mime })] }); } catch { /* cancelled */ }
}
async function deleteMsg(m) {
  if (!confirm('Delete this message from this device?')) return;
  await DB.delMsg(m.id);
  const el = [...$('messages').querySelectorAll('.msg')].find(e => e._m && e._m.id === m.id);
  if (el) el.remove();
  if (!$('messages').querySelector('.msg')) renderAll();
}
function menuItems(m) {
  const it = [];
  if (m.kind === 'text') it.push({ icon: 'copy', label: 'Copy text', fn: () => copyText(m.text) });
  else if (m.blob) {
    it.push({ icon: 'download', label: 'Save to device', fn: () => saveFile(m) });
    if (NATIVE || shareable(m)) it.push({ icon: 'share', label: 'Share…', fn: () => shareFile(m) });
  }
  it.push({ icon: 'trash', label: 'Delete for me', danger: true, fn: () => deleteMsg(m) });
  return it;
}
function openMenuFor(div) {
  const m = div._m;
  if (!m) return;
  closeMenu(true);
  const menu = $('msg-menu');
  menu.replaceChildren();
  for (const it of menuItems(m)) {
    const b = document.createElement('button');
    b.className = 'menu-item' + (it.danger ? ' danger' : '');
    b.setAttribute('role', 'menuitem');
    b.append(icon(it.icon), document.createTextNode(it.label));
    b.addEventListener('click', () => { closeMenu(); it.fn(); });
    menu.append(b);
  }
  state.menuBubble = div;
  state.menuAt = Date.now();
  div.classList.add('active');
  $('menu-scrim').classList.remove('hidden');
  menu.classList.remove('hidden', 'show');
  const r = div.getBoundingClientRect();
  const mw = menu.offsetWidth, mh = menu.offsetHeight;
  let top = r.top - mh - 8, originY = 'bottom';
  if (top < 60) { top = r.bottom + 8; originY = 'top'; }
  if (top + mh > innerHeight - 8) top = Math.max(8, innerHeight - mh - 8);
  let left = m.side === 'me' ? r.right - mw : r.left;
  left = Math.max(8, Math.min(left, innerWidth - mw - 8));
  menu.style.top = top + 'px';
  menu.style.left = left + 'px';
  menu.style.transformOrigin = `${m.side === 'me' ? 'right' : 'left'} ${originY}`;
  requestAnimationFrame(() => menu.classList.add('show'));
}
function closeMenu(instant) {
  const menu = $('msg-menu');
  if (menu.classList.contains('hidden') && !state.menuBubble) return;
  if (state.menuBubble) { state.menuBubble.classList.remove('active'); state.menuBubble = null; }
  $('menu-scrim').classList.add('hidden');
  menu.classList.remove('show');
  if (instant) { menu.classList.add('hidden'); return; }
  setTimeout(() => { if (!menu.classList.contains('show')) menu.classList.add('hidden'); }, 170);
}

// ---------------- COMPOSER / VOICE NOTES ----------------
const BARS = 36;
function autosize() {
  const ta = $('text-input');
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 140) + 'px';
  updateAction();
}
function updateAction() {
  const has = $('text-input').value.trim().length > 0;
  const b = $('action-btn');
  b.classList.toggle('send-mode', has || !!state.recording);
  b.setAttribute('aria-label', has ? 'Send message' : state.recording ? 'Send voice note' : 'Record voice note');
}
function onAction() {
  if (state.recording) return stopRecording(true);
  if ($('text-input').value.trim()) return sendText();
  ensureNotifPermission();
  startRecording();
}
function createBars() {
  $('rec-bars').replaceChildren(...Array.from({ length: BARS }, () => document.createElement('span')));
}
function drawBars(levels) {
  const spans = $('rec-bars').children;
  for (let i = 0; i < spans.length; i++) spans[i].style.height = Math.max(4, Math.round((levels[i] || 0) * 30)) + 'px';
}
async function startRecording() {
  if (state.recording || state.recStarting || !requireContact()) return;
  state.recStarting = true;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mt = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm', 'audio/ogg'].find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t)) || '';
    const rec = new MediaRecorder(stream, mt ? { mimeType: mt } : {});
    const chunks = [];
    const r = { rec, stream, start: Date.now(), cancel: false, levels: new Array(BARS).fill(0.05), raf: 0, ac: null, timer: 0, fake: 0, auto: 0 };
    state.recording = r;
    rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
    rec.onstop = async () => {
      const dur = (Date.now() - r.start) / 1000;
      cleanupRecording(r);
      if (r.cancel || !chunks.length) return;
      if (dur < 0.7) return toast('Voice note too short');
      const type = (rec.mimeType || mt || 'audio/webm').split(';')[0];
      const ext = type.includes('mp4') ? 'm4a' : type.includes('ogg') ? 'ogg' : 'webm';
      await sendFile(new File([new Blob(chunks, { type })], `voice-note.${ext}`, { type }), { dur });
    };
    rec.start();
    $('input-pill').classList.add('hidden');
    $('rec-bar').classList.remove('hidden');
    $('rec-time').textContent = '0:00';
    drawBars(r.levels);
    updateAction();
    r.timer = setInterval(() => { $('rec-time').textContent = fmtDur((Date.now() - r.start) / 1000); }, 250);
    r.auto = setTimeout(() => stopRecording(true), 120000);
    try {   // live level meter
      const ac = new (window.AudioContext || window.webkitAudioContext)();
      r.ac = ac;
      if (ac.resume) ac.resume();
      const an = ac.createAnalyser();
      an.fftSize = 256;
      ac.createMediaStreamSource(stream).connect(an);
      const buf = new Uint8Array(an.fftSize);
      let last = 0;
      const loop = (t) => {
        if (state.recording !== r) return;
        if (t - last > 70) {
          last = t;
          an.getByteTimeDomainData(buf);
          let sum = 0;
          for (const v of buf) { const x = (v - 128) / 128; sum += x * x; }
          r.levels.push(Math.max(0.06, Math.min(1, Math.sqrt(sum / buf.length) * 4)));
          r.levels.shift();
          drawBars(r.levels);
        }
        r.raf = requestAnimationFrame(loop);
      };
      r.raf = requestAnimationFrame(loop);
    } catch {
      r.fake = setInterval(() => { r.levels.push(0.15 + Math.random() * 0.6); r.levels.shift(); drawBars(r.levels); }, 90);
    }
  } catch (e) {
    toast('Microphone error: ' + e.message, 'error');
  } finally { state.recStarting = false; }
}
function stopRecording(send) {
  const r = state.recording;
  if (!r) return;
  r.cancel = !send;
  if (r.rec.state === 'recording') r.rec.stop(); else cleanupRecording(r);
}
function cleanupRecording(r) {
  clearInterval(r.timer); clearInterval(r.fake); clearTimeout(r.auto); cancelAnimationFrame(r.raf);
  r.stream.getTracks().forEach(t => t.stop());
  try { if (r.ac) r.ac.close(); } catch { /* ignore */ }
  if (state.recording === r) state.recording = null;
  $('rec-bar').classList.add('hidden');
  $('input-pill').classList.remove('hidden');
  updateAction();
}

// ---------------- WIRING ----------------
const THEME_COLORS = { bee: '#0a1634', dark: '#0f1115', light: '#eef1f7' };
function applyTheme(t) {
  if (!THEME_COLORS[t]) t = 'bee';
  document.documentElement.setAttribute('data-theme', t);
  try { localStorage.setItem('bee_theme', t); } catch { /* ignore */ }
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', THEME_COLORS[t]);
  document.querySelectorAll('.theme-opt').forEach(b => {
    const on = b.dataset.theme === t;
    b.classList.toggle('on', on);
    b.setAttribute('aria-checked', String(on));
  });
}
function openDlg(d) { d.classList.remove('closing'); if (!d.open) d.showModal(); }
function closeDlg(d) {
  if (!d || !d.open || d.classList.contains('closing')) return;
  d.classList.add('closing');
  setTimeout(() => { d.close(); d.classList.remove('closing'); }, 170);
}
// shown if icon.png is missing from the site
const BRAND_FALLBACK = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='22' fill='%230a1634'/%3E%3Cpath d='M24 30h52a6 6 0 0 1 6 6v26a6 6 0 0 1-6 6H48L34 80V68h-10a6 6 0 0 1-6-6V36a6 6 0 0 1 6-6z' fill='%23ffc933'/%3E%3C/svg%3E";

function bindUI() {
  $('origin-hint').textContent = location.origin;
  applyTheme(localStorage.getItem('bee_theme') || 'bee');
  createBars();
  if (!NATIVE && 'serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
  document.querySelectorAll('img.brand').forEach(img => {
    const fb = () => { img.src = BRAND_FALLBACK; };
    if (img.complete && img.naturalWidth === 0) fb(); else img.addEventListener('error', fb, { once: true });
  });

  // auth / contact
  $('save-client-btn').addEventListener('click', saveSetup);
  $('login-btn').addEventListener('click', startLogin);
  $('edit-setup-btn').addEventListener('click', showSetup);
  $('connect-btn').addEventListener('click', connectContact);
  $('contact-input').addEventListener('keydown', e => { if (e.key === 'Enter') connectContact(); });
  $('pull-btn').addEventListener('click', () => pullMessages(true));
  $('verify-btn').addEventListener('click', openVerify);
  $('verify-ok').addEventListener('click', markVerified);

  // composer
  const ta = $('text-input');
  ta.addEventListener('input', autosize);
  ta.addEventListener('keydown', (e) => {
    // desktop: Enter sends (Shift+Enter = new line). touch keyboards: Enter = new line, use the button.
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !matchMedia('(pointer:coarse)').matches) {
      e.preventDefault();
      sendText();
    }
  });
  $('action-btn').addEventListener('click', onAction);
  $('rec-cancel').addEventListener('click', () => stopRecording(false));
  $('file-input').addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    sendFile(f);
  });
  updateAction();

  // message bubbles: tap (or long-press / right-click) opens the menu
  const box = $('messages');
  box.addEventListener('click', (e) => {
    if (Date.now() - state.menuAt < 450) return;
    const b = e.target.closest('.msg');
    if (!b || e.target.closest('.vbtn,.vtrack,video')) return;
    openMenuFor(b);
  });
  box.addEventListener('contextmenu', (e) => {
    const b = e.target.closest('.msg');
    if (!b) return;
    e.preventDefault();
    openMenuFor(b);
  });
  box.addEventListener('scroll', () => closeMenu(true), { passive: true });
  $('menu-scrim').addEventListener('click', () => closeMenu());
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });
  window.addEventListener('resize', () => closeMenu(true));

  // dialogs
  document.querySelectorAll('dialog').forEach(d => {
    d.addEventListener('click', (e) => { if (e.target === d) closeDlg(d); });
    d.addEventListener('cancel', (e) => { e.preventDefault(); closeDlg(d); });
  });
  document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => closeDlg(b.closest('dialog'))));
  $('settings-btn').addEventListener('click', () => { refreshNotifLabel(); openDlg($('settings-dialog')); });
  document.querySelectorAll('.theme-opt').forEach(b => b.addEventListener('click', () => applyTheme(b.dataset.theme)));
  $('notif-btn').addEventListener('click', async () => {
    if (NATIVE) {
      const r = await CAP().LocalNotifications.requestPermissions();
      refreshNotifLabel();
      return toast(r.display === 'granted' ? 'Notifications enabled' : 'Notifications blocked. Enable them in Android settings.', r.display === 'granted' ? 'info' : 'error', 5000);
    }
    if (!('Notification' in window)) return toast('Notifications are not supported in this browser.', 'error');
    if (Notification.permission === 'denied') return toast('Notifications are blocked. Enable them in your browser’s site settings.', 'error', 6000);
    const p = await Notification.requestPermission();
    refreshNotifLabel();
    toast(p === 'granted' ? 'Notifications enabled' : 'Notifications not enabled');
  });
  $('clear-chat-btn').addEventListener('click', async () => {
    if (!state.contact || !confirm('Clear this chat on this device?')) return;
    await DB.clearConv(convKey(state.contact));
    closeDlg($('settings-dialog'));
    renderAll();
  });
  $('edit-setup2-btn').addEventListener('click', () => { logout(); showSetup(); });
  $('logout-btn').addEventListener('click', logout);
  $('wipe-btn').addEventListener('click', wipeAll);
}
window.addEventListener('online', () => { toast('Back online'); pullMessages(); });
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) { state.unread = 0; updateTitle(); pullMessages(); }
  schedulePoll();
});
window.addEventListener('load', async () => {
  bindUI();
  try { await DB.open(); }
  catch { return toast('Local storage (IndexedDB) is unavailable — private/incognito mode?', 'error', 10000); }
  if (NATIVE) { initAuth(); return; }
  let tries = 0;
  const wait = setInterval(() => {
    if (window.google && google.accounts && google.accounts.oauth2) { clearInterval(wait); initAuth(); }
    else if (++tries > 50) { clearInterval(wait); toast('Google sign-in library failed to load. Check your connection.', 'error', 8000); }
  }, 200);
});
